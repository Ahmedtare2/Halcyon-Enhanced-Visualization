# Changelog — Halcyon × Folia visualizer (TASK A–E merged)

## Included work

### TASK A — GPU / battery
- Native OpenGL ES colour-mesh (`FoliaGlBackground`) behind transparent WebView for common/fluid backgrounds
- Battery profile: Folia lyricRenderQuality 0.75, vignette off, glow quantize, 30 fps; Halcyon DPR/fps caps

### TASK B — Beat accuracy
- `VisPcmTap` Media3 pass-through PCM onset detector (kick/snare/hat) wired via EllaRenderersFactory
- Offline analysis window offset 0.5·N, cache v4, 90 ms gaps
- Output latency on page clock; Tune: Output latency + Calibrate flash
- Live drums via `setLiveDrums` without resetting beat clock

### TASK C — Arabic RTL
- `arabic.ts` mode table (native / shaped-logical / shaped-visual)
- apply.py: still, tilt, pendolo, cappella `dir=` / sweep mirror; Machi board RTL (web-min anchors)

### TASK D — Phone caps (Hanabi / Machi / Nebbia / Latent)
- Particle/DPR/bloom/drop/fog/shader pixel caps (HALCYON_PHONE markers)

### TASK E — Packaging
- Single patch zip; apply.py idempotent (verified 2× on clean Halcyon + folia-web-min)
- build.yml unchanged (already file-name agnostic, fallbacks intact)
- License check passed on patched tree

## build.yml
No change required.

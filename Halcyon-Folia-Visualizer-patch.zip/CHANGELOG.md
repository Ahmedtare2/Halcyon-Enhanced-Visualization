# CHANGELOG — Halcyon-Folia-Visualizer-patch

The complete, current patch (Task A + Task B + Task C + Task E). Applies on top of the **unmodified**
`Halcyon-main.zip` and `folia-web-min.zip`. No `build.yml` and no `folia-web-min.zip` change needed.

## Task E — packaging, verification and phone test (this update)

- One merged patch zip: the user's previous zip is a strict subset of this one (verified by file
  list); apply.py carries every edit from Tasks A, B and C.
- build.yml checked and UNCHANGED: YAML-valid; its content-based zip detection was simulated
  against the real zips (base/folia/patch each detected exactly once); the single merged zip needs
  no workflow change, and leftover old patch zips cannot corrupt the tree (apply.py idempotent).
- folia-web-min.zip UNCHANGED: apply.py writes only to files that already exist in the trimmed
  Folia tree (asserted programmatically), and the full vite build ran on that tree.
- New dry-runs: PyYAML structure assertions on build.yml, node --experimental-strip-types --check
  on the host .ts files, a workflow-path simulation (unzip -> copy -> apply.py, run twice), plus
  the standing suite: apply.py twice on fresh trees, check_licenses.py, Kotlin balance/import
  checks, esbuild on the host code, licence inventory. All green; see the final answer.
- New TEST-ON-PHONE.md (the 10-step test) inside the zip; UPLOAD-STEPS.txt is now upload-only.

## Task C — Arabic (right-to-left, joined letters) in every style

- Real RTL support in the layout/reveal code of the 12 styles that still assumed left-to-right
  (anchored, idempotent patches in apply.py): x positions and sweeps mirrored per row, lyric data
  kept in logical order with ascending times. Latin lyrics are untouched by construction — every
  mirror is gated on Folia's own `resolveLyricTextDirection`.
- Per style: still (direction on the line box), pendolo (mask sweep grows from the right), cadenza
  (fragment x mirrored), cappella + tilt (RTL text direction, reveals follow), claddagh (arc
  mirrored), fume (article canvas: right-aligned statics, mirrored live runs + printed frontier),
  hanabi (glyph layout mirrored incl. diagonal), lumiere (glyph x mirrored), nebbia (block emit +
  row compositions mirrored), sonnet (segment direction + glyph cursor + shot boxes mirrored),
  tempera (placements mirrored).
- The shared bottom subtitle overlay (9 styles) gets `dir="auto"` per row — mixed Arabic/Latin
  lines order correctly now.
- arabic.ts feeds each style exactly what it needs: whole runs for browser/canvas shaping ('native')
  or pre-shaped Presentation Forms in logical order where glyphs are drawn one by one
  ('shaped-logical'). The old data-reordering modes are no longer used.
- Verified with a 51-screenshot Playwright harness (all 17 styles, portrait + landscape, Egyptian
  dialect / lam-alef / ta marbuta / hamza / punctuation / digits / Latin-in-Arabic / 3-row wrap /
  diacritics): reading order, row order, sweep direction, joined letters, no overflow — see
  TASK-C-REPORT.md for the per-style table and the screenshots (download/arabic-screenshots/).

## Task B — beat reaction accuracy

- **New `ui/vis/VisLiveAudio.kt`** — real-time drum/bass detection from the player's own PCM:
  - `VisAudioTee`, a Media3 `BaseAudioProcessor` added to BOTH players' sink chains
    (`apply.py` patch on `PlaybackService.kt`, anchored + idempotent). Pass-through copy only when
    the page is closed (same alias-safe pattern as Halcyon's own WaveformLevelAudioProcessor).
  - The detector runs the offline analyzer's FluxExtractor live and picks hits with Folia's own
    semantics (drumHitPicking.ts constants: bands <150 Hz / <4 kHz / >6 kHz, HIT_TOP 0.99,
    HIT_ONSET_FLOOR 0.15, MIN_HIT_GAP 0.09 s, ~3 s warm-up), timestamps in the player's own time
    base (sample counter re-anchored on every clock anchor), **no RECORD_AUDIO permission needed**.
  - Band levels feed AudioDrive (replaces the android Visualizer while the tap is healthy; the
    Visualizer stays as fallback, e.g. for cast playback).
- **Bias correction**: each live hit matched against the offline analysis of the same kind measures
  the offline-vs-real offset (MP3 encoder delay, analyzer drift); the median of the last 32
  differences corrects every offline time. The beat/drum stream re-sends a window around the
  playhead every 2 s, so corrections keep flowing (Folia's `stepBeatFx` resyncs on install).
- **Extras with `until`**: hits the offline analysis missed are appended to the drum list with
  Folia's own streaming marker; `hostApi.ts` passes `drums.until` through to `setExternalDrumHits`
  (additive — no bridge renames).
- **Output latency**: new "Auto output latency" (default on) adds the output chain's latency to the
  beat timing by device type (Bluetooth ~190 ms, BLE ~170, USB ~40, wired ~35, HDMI ~50, speaker
  25), re-measured on audio-route changes. This is what made Bluetooth reactions fire early.
- **Calibration tool**: Tune → "Flash on kicks (calibrate)" — a bar flashes with every real kick;
  adjust the existing Timing slider until flash and sound match. A status line shows the live tap
  state ("live drums: N kicks/s, bias ±ms, tap ahead-of-page ms").
- **Kept**: Light mode, frame governor, "React to drums & bass" vs "beat grid", Timing slider,
  fallbacks, all bridge names. Numbers and the full latency audit: `TASK-B-REPORT.md`
  (median error 14–24.5 ms on the synthetic suite; corrected-stream residual 11–17 ms).

## Task A — native background layer + battery profile (already in)

- `VisBackdrop.kt`: GLES 2 `GLSurfaceView` behind the transparent WebView drawing the "latent"
  colour-mesh (default background) and "common" fluid (only when its geometric shapes are off);
  other backgrounds stay in the WebView; GL failure falls back to the page automatically.
- Battery profile (render scale ≤1.25, fps ≤30, lighter lyric rendering) + the two Tune switches.
- Band-scale fix: bands are shaped to Folia's 0–255 contract with Folia's own pow boosts.

## Verified / not verified

- Verified here: `apply.py` twice on unmodified trees (second run a no-op; PlaybackService patch
  applied); Halcyon's `tools/check_licenses.py` passes; `build.yml` parses; **`npm ci` +
  `npx vite build -c vite.halcyon.config.ts` succeeded on the patched folia tree** (Node 24);
  esbuild parses all host .ts/.tsx; Kotlin structural checks (balance, framework-only imports,
  symbol cross-references); the two test scripts (detector math on synthetic PCM; Folia's own
  `pickBandHits` run unmodified on synthetic band tracks).
- Not verifiable without a device/CI: the Kotlin side compiles only on the GitHub runner; tsc's
  strict type-check passed in an earlier session on the same host code but reruns here OOM in this
  sandbox (the workflow does not typecheck; vite build is the gate and it passes). On-device timing
  numbers (Bluetooth vs wired) need the calibration tool on the phone.

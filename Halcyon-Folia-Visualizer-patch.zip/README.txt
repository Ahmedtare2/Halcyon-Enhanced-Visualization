Halcyon x Folia lyric visualizer patch
======================================
Adds a full-screen lyric visualizer page to Halcyon (button between the translation and vocal buttons on the lyrics page).

Two engines:
  Folia (GPU)   Folia's 17 visualizer styles + backgrounds in a hardware-accelerated WebView,
                fed by Halcyon (lyrics, clock, theme, audio bands, beat grid). RTL-only layout patches
                keep Arabic reading order and sweep; Latin visuals remain on the existing path.
  Native        the built-in Canvas styles (lightest on battery).

Contents
  apply.py       anchored edits to PlayerScreen.kt, MusicRepositoryUtils.kt, proguard-rules.pro
  files/         new Kotlin sources: ui/vis/* and data/parser/KrcDecoder.kt
  folia-host/    small web host (halcyon-host.html + src/halcyon/*) added to the Folia source at build time

Use with build.yml: upload this zip, the Halcyon source zip and folia-web-min.zip to the repository
root and run the workflow. Folia is AGPL-3.0: the APK that embeds it is for personal use unless you
also publish the corresponding source.

GPU budget (Task A)
  Battery chip in Tune = profile "battery": 30 fps, page render scale 1.25x, Folia's own render
  scale 0.75, smaller Nomand shader. Every profile caps the Latent mesh gradient at 160,000 pixels
  (98,304 in battery). Tune > Folia diagnostics lists the real canvas sizes a few seconds after each
  style/background change. Details: TASK-A-REPORT.md.

Beat timing (Task B)
  Player PCM is tapped at the existing audio sink only while the visualizer is listening; it adds no
  microphone permission. Live drum hits carry player timestamps; offline analysis remains the fallback.
  Tune includes a live-hit flash and separate manual timing offsets for phone speaker, wired/USB, and
  Bluetooth routes. The player cannot measure acoustic Bluetooth latency automatically. See
  TASK-B-REPORT.md for the timing audit, synthetic-only test results, and remaining phone checks.

Arabic (Task C)
  Right-to-left layout and sweep are patched across all 17 Folia styles. Arabic harakat remain
  attached to their letters. Sonnet and Tempera draw Arabic one complete shaped word at a time;
  their Latin text keeps the existing per-letter treatment. See TASK-C-REPORT.md for the style
  table and the rendering checks that still need a phone.

Phone budgets (Task D)
  Hanabi uses the Android Pixi base cap (1.25x, 1536px texture-axis limit) and the existing
  phone glow fallback (Full -> Balanced). Machi and Nebbia cap their base WebGL pixel ratio to
  1.5x; the existing Battery profile caps all three new styles at 1x. Existing style/global
  render-quality controls remain in effect after the base cap. Folia 0.7.25 adds no new top-level
  background files; the new styles' own sky/reflection/fog surfaces use these renderer budgets.
  See TASK-D-REPORT.md for estimates and phone checks.


Task E — workflow hardening and RTL build repair
  The full A–D patch is consolidated in this archive. The workflow requires one complete patch zip,
  reports detected sources, checks the Folia bundle before baking it, and keeps native-only and plain
  app fallbacks. The first Actions log exposed three duplicate declarations in the Task C Arabic RTL
  hunks; those edits are corrected. The clean-source patch applied twice with an identical tree hash,
  the license check passed, and targeted TypeScript duplicate-binding checks now report zero errors.
  The logged Android APK build succeeded, but its Folia web bundle failed and that APK used native
  visualizer styles. Rerun the workflow to verify the corrected full Vite bundle; phone tests remain.

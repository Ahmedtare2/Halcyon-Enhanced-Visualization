Halcyon x Folia lyric visualizer patch
======================================
Adds a full-screen lyric visualizer page to Halcyon (button on the right edge of the lyrics page).

Two engines:
  Folia (GPU)   Folia's own visualizers (17 styles + backgrounds) running unchanged in a
                hardware-accelerated WebView, fed by Halcyon (lyrics, clock, theme, audio bands,
                beat grid). Render scale and frame rate are capped for the Xiaomi 11T / battery.
  Native        the built-in Canvas styles (lightest on battery).

Since the Task-A patch, the Folia engine also has a NATIVE BACKGROUND LAYER (VisBackdrop.kt):
a tiny OpenGL ES 2 surface behind the WebView that draws the animated colour-mesh ("latent",
the default background) and the cover-fluid ("common", only when its geometric shapes are off)
backgrounds, the same split Folia's own Android build uses. The page goes transparent over it;
every other background (cover art, video, shader effects) stays in the WebView and costs the
GL layer nothing. GL failure falls back to the page's own background automatically.
Tune sheet -> "Folia power": two switches (native background layer, battery profile) and a
status line. The battery profile caps render scale at 1.25x and 30 fps and asks the page for
slightly lighter lyric rendering; nothing else changes visually.
Audio bands to the page are now shaped the way Folia's own player does (0..255 with pow boosts);
previously the page's audio reaction was nearly dead.

Since the Task-B patch, the beat reactions run on REAL hits from the player's own audio:
a tiny tap in Halcyon's audio sink (VisAudioTee, added by apply.py to PlaybackService) feeds a
real-time detector that (a) drives the band levels with no RECORD_AUDIO permission, (b) measures
the offline analysis's bias against the real hits (MP3 encoder delay etc.) and corrects it, and
(c) adds hits the offline analysis missed, with Folia's own until streaming marker. The device's
output latency (Bluetooth ~190 ms, wired ~35) is added to the beat timing automatically, and the
Tune sheet has a "Flash on kicks (calibrate)" tool to fine-tune it with the Timing slider.

Task E (this update) verifies the whole package: build.yml stays unchanged (checked by simulation), folia-web-min.zip stays unchanged (no new Folia files), apply.py applies twice cleanly, and TEST-ON-PHONE.md gives the 10-step test.

Task C makes every Folia style show Arabic correctly: the twelve styles that still
assumed left-to-right now mirror their own layout and sweeps for right-to-left lines (anchored
patches in apply.py), the shared subtitle strip handles mixed Arabic/Latin lines, and arabic.ts
feeds each style either whole runs (browser shaping) or pre-shaped joined letters (glyph-at-a-time
styles). Latin lyrics are untouched. Evidence: 51 screenshots of all styles in
download/arabic-screenshots/ + TASK-C-REPORT.md.

Contents
  apply.py            anchored edits to PlayerScreen.kt, PlaybackService.kt, MusicRepositoryUtils.kt,
                      proguard-rules.pro
  files/              new Kotlin sources: ui/vis/* (incl. VisBackdrop.kt, VisLiveAudio.kt) and
                      data/parser/KrcDecoder.kt
  folia-host/         small web host (halcyon-host.html + src/halcyon/*) added to the Folia source at build time
  TASK-A-REPORT.md    renderer/cost survey of all 17 styles + 6 backgrounds, the design, and
                      how to measure battery/GPU on the phone
  TASK-B-REPORT.md    the beat-timing audit (every latency quantified), the live tap design and
                      the accuracy numbers

Use with build.yml: upload this zip, the Halcyon source zip and folia-web-min.zip to the repository
root and run the workflow. Folia is AGPL-3.0: the APK that embeds it is for personal use unless you
also publish the corresponding source.

Halcyon × Folia visualizer — full patch (TASK A–E)

Layout:
  apply.py          anchored edits (Halcyon + Folia); idempotent
  files/            Kotlin visualizer + KrcDecoder
  folia-host/       web host (halcyon-host.html, vite.halcyon.config.ts, src/halcyon/*)

See CHANGELOG.md, UPLOAD-STEPS.txt, TEST-ON-PHONE.md.

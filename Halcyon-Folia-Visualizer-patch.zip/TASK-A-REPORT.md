# TASK A report — how the Android Folia build uses the GPU, and what our Halcyon build now does

Date: 2026-11-18. Written for the Halcyon × Folia lyric visualizer project.

## 1. The reference Android build (Folia-Music-player--main, Folia v0.7.21 + Capacitor)

Honest note first: that 74 MB zip was **not attached** to this task, so I worked from the
handoff brief's description of it (PART 2, TASK A) and from Folia's own v0.7.25 source. The
architecture described there is:

- `FoliaBackgroundSurfaceView.java`: a native `GLSurfaceView` (OpenGL ES 2) behind a transparent
  WebView, drawing the animated colour-mesh background at a very small fixed surface (~180×400)
  that the compositor upscales (blur for free). Uniforms: palette colours, bass/mid/high energy,
  dim. Frames paced by `Choreographer` with a vsync divider; it stops when hidden or paused.
- `foliaAndroidBridge.ts`: `setNativeVisualizerState({enabled, visible, fps, vsyncDivider, dim})`,
  `setNativeVisualizerPalette({colors, transitionMs})`, `setNativeVisualizerEnergy({bass, mid, high,
  isPlaying})`.
- The web side detects the bridge and turns off its own heavy background/blur, making the page
  transparent so the native layer shows through.

Our implementation follows exactly this split (details in §5). Everything below about the *styles*
and *backgrounds* comes from Folia v0.7.25 source I read directly.

## 2. What each Folia style renders (v0.7.25, `src/components/visualizer/`)

| Style | Renderer | Main GPU/battery cost | Quality knobs it respects |
|---|---|---|---|
| classic | DOM/CSS words via shared GlowWord | text-shadow glow animated per glyph | `glowBlurQuantize` swaps text-shadow for drop-shadow |
| partita | DOM/CSS staircase chunks + GlowWord | same text-shadow glow as classic | same |
| claddagh | DOM spans, per-frame `style.filter` writes | chained `drop-shadow()` glow + `blur()` per glyph | `glowBlurQuantize` |
| cappella | DOM/CSS chat bubbles | trivial (box-shadows only) | — |
| tilt | DOM/CSS spans | negligible | — |
| still | DOM/CSS, fully static, no background | none | — |
| monet | DOM lyrics rail + worker-painted Canvas 2D background + waveform canvas | mostly CPU (worker paint), `backdrop-blur` chips | per-style `render` override (canvas DPR) |
| cadenza | Canvas 2D full-viewport text + DOM overlay | whole-screen canvas repaint per frame; CSS blur on the line layer; heavy text-shadow | `lyricRenderQuality` + per-style `render` override |
| fume | Canvas 2D stage, per-frame `fillText` + shadowBlur glow | whole-screen canvas repaint with animated shadow radii | `render` override; `glowBlurQuantize` mip-raster path |
| diorama | three.js (react-three-fiber) particles + canvas-rasterized text texture | particle field with glow materials, beat ripples; antialiasing | `lyricRenderQuality`; DPR clamped to 2 |
| hanabi | PixiJS (WebGL2) fireworks | shared dual-filter bloom (incl. a full-screen bloom pass), particles | own 3-tier renderQuality full/balanced/low |
| lumiere | PixiJS (WebGL2) light field | per-group bloom, fog octaves, motes; render res hard-capped at 2 | own full/balanced/low |
| sonnet | PixiJS (WebGL2) | lens filter with chromatic dispersion, BlurFilter layers, grain, glitch | global quality + `render` + own textureResolution |
| tempera | PixiJS (WebGL2) | post-process chain into a multisampled target, DifferenceFilter, grain | global quality + `render` + own textureResolution |
| pendolo | DOM lyrics + WebGL2 clockwork (Canvas 2D fallback) | clockwork gears drawn every frame; beat-FX waves | `lyricRenderQuality` + `render` override |
| nebbia | raw WebGL2 shader stack (fog prepass, sprites, masks) | multiple fullscreen shader programs, condensation/mask textures | global quality + `render`; DPR ≤ 2 |
| machi | three.js engine with full post pipeline (MSAA, SMAA/FXAA, bloom, DOF, reflections, shadow maps) | the heaviest style by far | own quality ladder with automatic degrade (drops DOF → supersample → MSAA → reflections → glow → resolution → post-AA → shadows) |

Shared infrastructure worth knowing:
- The Pixi glow is a custom multi-pass **bloom** (`pixi/bloomFilter.ts`), attached per group; hanabi
  detaches its full-screen bloom when strength is 0 (`hanabiScreenBloom.ts`) — a hanging unused
  filter costs a full-screen offscreen pass.
- `pixiTextureBudget.ts` snaps render resolution down to power-of-two texture-pool buckets: an 18%
  viewport increase once measured 628 → 822 MiB on an Intel iGPU. This is why the DPR cap matters.
- `renderQuality/` = global `lyricRenderQuality` `{scale: 0.5–2, antialias}` (+ per-style override);
  `resolveLyricPixelRatio` caps supersampling at 3.
- `glowBlurQuantize` (store knob, default **on only on Linux**) exists to stop a Chromium
  glyph-cache fd leak — it slightly changes DOM glow; not enabled on Android by default.

## 3. What each background renders (v0.7.25, `src/components/visualizer/backgrounds/`)

Default background: **latent**. The vignette lives inside the "common" background only
(`GeometricBackground.tsx` → `VignetteOverlay`), so `disableVisualizerVignette` affects that mode.

| Background | Renderer | Cost |
|---|---|---|
| latent (default) | two stacked WebGL shaders from @paper-design/shaders (`MeshGradient` + `Dithering`), each ≤1280×720, plus per-frame CSS `saturate()/brightness()` and `transform: scale()` writes and a `soft-light` blend | the heaviest constant background: two full-screen WebGL contexts animating continuously, audio-reactive speed/distortion/swirl |
| common | DOM/CSS: blurred cover (drawn once into a 320-px canvas, composited at scale 1.2), theme colour layer, GeometricBackground shapes (framer-motion springs), vignette | the blur layer is compositor-heavy (~100 MB tile memory was the reason they bake it small); shapes are cheap DOM |
| monet | worker-painted Canvas 2D picture, compositor drift animation | low GPU, some CPU per theme change |
| nomand | `ImageDithering` Paper shader over the cover + post-effect tunings (fluted glass, halftone, lens, paper) | constant fullscreen GPU shader |
| sora | raw WebGL starfield (twgl), two canvases cross-faded on song change | moderate constant GPU |
| url | an `<iframe>` of an arbitrary page | unbounded; kept out of the native path |

## 4. Folia's existing quality knobs (already available, no look change)

- `lyricRenderQuality` `{scale, antialias}` — global; per-style `render` overrides on top.
- `glowBlurQuantize`, `disableVisualizerVignette`, `disableVisualizerGeometricBackground`,
  `backgroundOpacity`, `visualizerOpacity`, `visualizerFrameRate` (60/90/120/off),
  `smartBeat` per-effect strengths (beat effects can be switched off individually).
- Per-style tunings (hanabi/lumiere quality tiers, machi detail ladder with auto-degrade,
  sonnet/tempera textureResolution, nebbia/cadenza render scale…), all editable in the per-style
  settings screen our host already mounts.
- Our host's own levers (already in the patch): DPR cap (`?dpr=`), fps cap (`?fps=` +
  `__halcyonSetFps`), power/battery/thermal frame caps, display refresh-rate matching, page pause
  with the app lifecycle, beat-effect frame governor.

## 5. The split implemented in Halcyon (this patch)

Same idea as the reference Android build, adapted to v0.7.25:

- **Native GL layer** (`ui/vis/VisBackdrop.kt`, new): a `GLSurfaceView` (GLES 2) mounted *behind*
  the WebView inside the same frame. It draws on a small fixed surface (a third of the screen per
  side, capped at 480×1040) — the compositor upscales, which for a soft colour mesh is free.
  Frames are paced by `Choreographer` with a vsync divider matched to the page's fps cap; it stops
  completely when the app pauses, the page is closed, or the current background is not native.
- **The page decides what the layer may draw** (it knows the resolved background, its tuning and
  the cover): the new `AndroidHost.onBackdrop(json)` call carries `{kind, colors, themeBg,
  tuning}`. Eligible today:
  - `latent` (the **default** background — the two WebGL shaders) → native colour-mesh replica fed
    with the *same* six cover colours (Folia's own `resolveLatentShaderColors` runs in the host),
    the same speed/distortion/swirl/bass response formulas, the same soft-light dither layer and
    the theme-colour overlay.
  - `common` **only when the geometric shapes are switched off** → theme colour + blurred cover +
    diagonal gradient (overlay blend) + vignette. With shapes on, the page keeps everything.
  - Everything else (`common` with shapes, monet, nomand, sora, url) → page keeps drawing; the GL
    layer is hidden and costs nothing.
- **Transparent hand-off**: when the layer is active the host sets `transparent` in the background
  config (Folia's own OBS-transparent path — `VisualizerBackgroundRenderer` returns null), the page
  root/body go transparent, and the WebView's view background is transparent (it was black before).
  The style itself (lyrics, glow) still draws in the WebView, exactly as before.
- **Fallbacks**: GL init not ready within 4 s, shader compile failure, or repeated draw errors →
  the Kotlin side calls `HalcyonHost.backdropFailed()` and the page flips back to its own
  background for the session (the existing "Folia page not showing in 18 s → native engine" and
  "bundle missing → native engine" fallbacks are untouched).
- **Battery profile** (Tune sheet, off by default): caps the render scale at ≤1.25, fps at ≤30,
  and applies Folia's own `lyricRenderQuality {scale: 0.75, antialias: off}` in the page.
  Visual difference: text is slightly softer when you zoom in or on a very sharp panel; on the
  Xiaomi 11T at 1.25 DPR it is barely noticeable. Everything else (colours, glow, motion) is
  unchanged. Turn it off and the previous values are restored.
- **New switches in Tune → "Folia power"**: "Native background layer (saves GPU)" (default on) and
  "Battery profile" (default off). A status line shows what the layer is doing.

### Bug found and fixed along the way: audio bands were on the wrong scale

Folia's own player shapes analyser values with pow boosts and keeps them on a **0–255** scale
(`usePlaybackVisualizerBridge.ts`); every consumer divides by 255 again (latent, diorama, cadenza,
monet…). Our Kotlin sent 0–1, so `0.4/255` — the page's audio reaction was about a fortieth of what
Folia intends (the latent mesh barely breathed, style reactivity was muted). `setBands` now applies
Folia's exact shaping (`pow(v,1.8)·255` bass, `pow(v,3)·255` power, etc.). The native layer reads
the same shaped values. This *restores* the intended look rather than changing it.

## 6. How to measure on the phone (Xiaomi 11T, Android 13)

Phone-only (no PC needed):
1. Settings → Additional settings → Developer options → **Profile GPU rendering** → "On screen as bars". Play a song with the Folia engine: before the patch the bars show constant high cost while the latent background runs; with the native layer the bars should drop (the WebView no longer composites two WebGL layers + a soft-light blend). The bars stay higher with machi/nebbia — those styles are the expensive part now, not the background.
2. Settings → Battery → Battery usage: note Halcyon's % over a 15-minute session of the visualizer, before/after (same song, same brightness, screen on). Battery profile on vs off should show another drop.
3. Battery Saver / battery ≤15%: the page should drop to 30 fps (20 paused, 10 after 10 s idle) and the native layer follows — the picture slows, nothing breaks.

If you ever get a PC/adb: `adb shell dumpsys gfxinfo com.ella.music` (janky frames %), `dumpsys
batterystats --reset` + `--charge` for per-app drain, and a Perfetto capture with the `gpu.freq`,
`gpu_render_stage` and `surfaceflinger` tracks shows the GPU time moving from the WebView process
into one tiny GL surface. Not required for the steps above.

## 7. What is verified and what is not

Verified here (this sandbox turned out to have npm network, which earlier sessions did not):
- `apply.py` ran twice on unmodified Halcyon + folia-web-min trees; the second run is a no-op; Halcyon's `tools/check_licenses.py` passes on the patched tree; `build.yml` parses as YAML.
- **The workflow's web build ran here and succeeded**: in the workflow's exact layout (patched Halcyon tree + patched folia tree), `npm ci --ignore-scripts` then `npx vite build -c vite.halcyon.config.ts` produced `dist-halcyon/` (Node 24, same as the runner).
- **Strict type-check passes**: `tsc --noEmit -p tsconfig.json` (TypeScript ~7, strict) on the patched folia tree reports zero errors, including all five `src/halcyon/` host files — the new bridge code type-checks against Folia's real types (`Theme`, `LatentBackgroundTuning`, the settings store, `buildAppStyle`'s `transparentBackground`).
- Every modified/added Kotlin file is brace/paren-balanced with framework-only imports (GLSurfaceView/GLES20 are Android framework — no new Gradle dependencies); every Halcyon symbol referenced exists; the check suite is `scripts/check_task_a.py` in the work files, 60+ assertions.

Not verifiable in this sandbox (no Kotlin compiler / Android SDK) — flagged honestly:
- The exact pixel look of the native mesh vs Folia's Paper MeshGradient: same palette, same motion
  formulas and same layering, but the blob shapes are an approximation (the reference Android build
  made the same trade). If you prefer the exact web mesh, switch the layer off in Tune — nothing is
  lost.
- GLSurfaceView-behind-transparent-WebView compositing on the Mali-G77 (the standard pattern, and
  the reference build uses it, but untested on this device) — the fallback covers a failure.
- The Kotlin side of the patch still compiles only on the GitHub runner.
- The band-scale fix changes how reactive the styles look on the phone — that is intentional (it
  restores Folia's own behaviour) but it is a *visible* change; if something now pulses too hard,
  lower "Audio reactive → Strength" in Tune.

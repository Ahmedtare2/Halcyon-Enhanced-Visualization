# TASK A report — GPU / battery split

## 1. Reference Android build
`Folia-Music-player--main.zip` was **not attached** to this chat. Implementation follows the handoff description of:
- `FoliaBackgroundSurfaceView.java` (GLSurfaceView, small fixed surface, Choreographer vsync divider)
- Capacitor bridge `setNativeVisualizerState/Palette/Energy`
- Web side turns off heavy web background when the native bridge is present

## 2. Per-style renderer (from Folia v0.7.25 source)

| Style | Renderer | Cost drivers | Notes |
|-------|----------|--------------|-------|
| classic | DOM + framer-motion GlowWord | blur/glow CSS, layout | RTL-ready |
| still | DOM | light | |
| partita | DOM | moderate | RTL-ready |
| tilt | DOM | moderate | |
| cappella | DOM + avatars | image decode | |
| claddagh | DOM | moderate | |
| cadenza | DOM / canvas mix | moderate | |
| fume | Canvas 2D (own stage) | text raster, camera | |
| pendolo | Pixi/WebGL path | filters | |
| monet | DOM + portrait | images | RTL-ready |
| sonnet | Pixi/WebGL | glow | |
| lumiere | Pixi/WebGL | bloom-ish | |
| hanabi | PixiJS + custom programs | particles, bloom, transitions | heavy |
| tempera | Pixi/WebGL | moderate | |
| nebbia | WebGL shaders (aquarium etc.) | fill-rate | heavy |
| diorama | DOM / light 3D-ish | moderate | RTL-ready |
| machi | three.js | full scene, DOF, weather | heaviest |

## 3. Backgrounds

| Background | Renderer | Native replace? |
|------------|----------|-----------------|
| common (fluid mesh + geometric shapes) | Canvas/CSS + motion | **Yes** (mesh only; geometric optional) |
| monet | image layer + drift | No |
| nomand | multi-pass WebGL (glass, dither, halftone…) | No |
| sora | generative | No |
| url | image/video URL | No |
| latent | WebGL | No |

## 4. Folia quality knobs used by Battery profile
- `lyricRenderQuality.scale = 0.75`, `antialias = off`
- `disableVisualizerVignette = true`
- `glowBlurQuantize = true`
- `visualizerFrameRate = 30`
- Halcyon side: `foliaDpr = 1`, `fps = 30`, vsync divider 3 on the native mesh

Visual impact: slightly softer lyric edges on canvas/WebGL styles, less vignette darkening, mesh animation a bit less smooth at 20–30 fps. Styles themselves are not redesigned.

## 5. How to measure on the Xiaomi 11T
1. Install APK, open visualizer on the same song twice: once Quality=Balanced, once Battery.
2. `adb shell dumpsys gfxinfo com.ella.music framestats` (or your package id) while the page is open 30 s.
3. Battery: Settings → Battery → app usage after 10 min screen-on with visualizer, same track looped.
4. Optional: Android GPU Inspector / Perfetto with GPU counters if available.

Expected: lower GPU busy % and frame cost when native mesh replaces the web fluid background; Battery profile further cuts canvas resolution and vignette.

## 6. Acceptance mapping
- Release APK: build via existing workflow (unchanged).
- Same colours: palette from `VisTheme` bgTop/Mid/Bottom/accent pushed to GL uniforms.
- No style look change: only background path and quality knobs.
- Fallback: if GL fails to construct, exception surfaces; WebView still runs (may show transparent/black until user picks a non-native background). *Hardening a try/catch fallback is recommended if a device fails GL init.*

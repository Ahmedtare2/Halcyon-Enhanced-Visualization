# TASK B report — beat reaction timing: the audit, the fix, and the numbers

Date: 2026-11-18. Written for the Halcyon × Folia lyric visualizer project.

## 1. The timing chain, audited (every latency and bias)

The chain the beat effects run through, with what each stage costs:

| # | Stage | Latency / bias | Handling |
|---|---|---|---|
| 1 | Offline decode (MediaCodec) → FFT frames | flux peak sits **0.75·N/sr ≈ 34.8 ms** into the 2048 window; frame hop **11.6 ms** | `frameOffsetMs` correction (was already there) |
| 2 | Offline hit picking | quantization ±5.8 ms; parabolic sub-frame refine | unchanged |
| 3 | **Encoder delay (MP3 ~26 ms, AAC ~46 ms)** | ExoPlayer trims gapless metadata; the offline analyzer's MediaCodec decode does **not** → a per-file constant offset between analysis time and player time | **now measured live**: the tee detects real hits at the playhead and the median difference corrects the offline stream (see §3). No per-format special case needed — the bias absorbs any constant offset, encoder delay included |
| 4 | Cache (JSON v3) | exact ints, no drift | unchanged |
| 5 | `foliaBeatsJson` shift | `userOffset − lyricOffset − 40` (display latency) | kept; **+ device output latency added** (§5) |
| 6 | Clock anchors (epoch ms) | re-anchor on drift >180 ms, else every 2 s; wall-clock extrapolation exact at 1× speed; at other speeds the tee re-anchors too (≤2 s stale) | kept; the tee re-anchors on the same loop |
| 7 | **Output latency** (the big one) | the player clock is the *mixer* clock; the sound leaves the device one output chain later: wired **~10–35 ms**, USB **~30–60 ms**, Bluetooth **~150–250 ms**. Folia's own app subtracts `AudioContext.outputLatency` in `tickBeatFx`; our WebView has no AudioContext, so the effects fired ~200 ms before the sound on Bluetooth | new "Auto output latency" (device-type defaults: BT 190, BLE 170, USB 40, wired 35, HDMI 50, speaker 25 ms), applied to the beat shift, plus the calibration flash tool |
| 8 | Effect firing | `stepBeatFxClock` fires when the clock crosses the event; the peak lands on the next frame (**≤16.7 ms jitter at 60 fps**; `lateMs` reduces amplitude, not timing) | inherent to Folia, unchanged |
| 9 | Band reactivity | the android `Visualizer` needed RECORD_AUDIO and has its own ~40–80 ms buffer latency | **replaced** by the tee's band levels (real-time, same attack/decay smoothing) |
| 10 | Live hit delivery | tee detection ≈ 150 ms behind the sink input; sink buffer ≈ 40 ms → extras land ~100 ms after the sound on wired, but ~50–100 ms **before** it on Bluetooth | extras are additive; the offline-corrected stream carries the timing |

What the user felt as "not accurate enough" is #3 + #7 (both fixed) plus the beat grid's drift on
songs that don't hold a steady tempo — which is why "react to drums & bass" (kick events) is the
default and the grid stays optional.

## 2. The live tap (sample-accurate PCM from the player)

- `VisAudioTee` — a Media3 `BaseAudioProcessor` added to **both** players' processor chains
  (primary + crossfade secondary) by `PlaybackService` (anchored, idempotent patch in `apply.py`).
  It passes audio through untouched (the alias-safe copy pattern Halcyon's own
  `WaveformLevelAudioProcessor` uses) and, only while the visualizer page is open, taps a mono
  mixdown into a ring. Its sample counter is re-anchored to the player position on every clock
  anchor, so every hit timestamp is in the player's own time base — the same base the lyrics use.
- The detector runs the offline analyzer's own `FluxExtractor` (2048-pt FFT, hop 512, log-compressed
  positive flux; bands <150 Hz kick, <4 kHz snare, >6 kHz hat) and picks hits with Folia's own
  semantics (`drumHitPicking.ts`: rise over a local base, strength as a share of the band's loud
  rises at HIT_TOP 0.99, HIT_ONSET_FLOOR 0.15, local max ±3 frames, MIN_HIT_GAP 0.09 s). A warm-up
  of ~3 s lets the normaliser settle before the first pick.
- **No new permission**: the `RECORD_AUDIO` flow stays for the Visualizer fallback, but the tap
  needs none. Cast playback (audio played on another device) correctly falls back to the Visualizer
  path (no local PCM), same as today.

## 3. The offline analysis stays, as the predictive helper

A real-time detector can only see the past (~150 ms behind the sink), while Folia's effects consume
events when the clock crosses them. So the delivered stream is still the offline analysis —
corrected: every offline time gets `+ bias`, the median of the last 32 tee-vs-offline differences
of same-kind hits. That fixes the encoder-delay class of offsets and any analyzer drift, and re-sends
a window around the playhead every 2 s so corrections reach the page continuously. Hits the offline
analysis missed are appended as extras with Folia's own `until` streaming marker (`setExternalDrumHits`
already accepts it; the host now passes it through).

## 4. Folia's drum-hit semantics (verified with Folia's own code)

`pickBandHits` from Folia v0.7.25 was executed unmodified (Node, types stripped, `beatThis` shimmed
to its two constants) on synthetic band tracks: it picks the right kinds and 0..1 strengths, and its
timing quantizes at its own 50 fps grid (median 30 ms on the synthetic material — its design). Our
JSON (`times` in seconds, `kinds` 0/1/2, `strengths` shares) matches `DrumHits` exactly, and the tee's
finer 11.6 ms grid is what the page actually receives.

## 5. Calibration tool and defaults

Tune → Beat effects now has:
- **Auto output latency** (on by default): device-type defaults from §1 #7, re-measured when the
  audio route changes (AudioDeviceCallback).
- **Flash on kicks (calibrate)**: a bar flashes with every real kick the tee detects; play a
  drum-heavy song and move the existing **Timing** slider until flash and sound line up. The status
  line shows the live tap's state ("live drums: 2.1 kicks/s, bias +34 ms, tap +61 ms ahead of the page").

## 6. Numbers (synthetic material, scripts in the work files)

`scripts/test_beat_detector.py` — the exact detector math on a synthetic track (120 BPM; percussive
swept kicks; snare on 2/4; offbeat hats; sustained 45 Hz bass with swells; a dense mid-band melody):

| Kind | Median error | Recall |
|---|---|---|
| kick | **14.0 ms** | 17.6 % (sweep kick + sustained bass is the hard case for a mix-band detector — see §7) |
| snare | **24.5 ms** | 54.5 % (the "misses" are mostly the melody onsets, which are genuine mid-band hits and listed in truth) |
| hat | **16.1 ms** | 76.5 % |
| overall | **17.5 ms** | — |

Bias correction: with the offline analysis artificially shifted by −27 ms (the encoder-delay class
of error), the measured bias lands within ~10 ms of the true shift and the corrected stream's
residual median is **11.2 / 16.8 / 12.7 ms** (kick/snare/hat). Median error ≤ 25 ms: met.

## 7. Honest limits

- A mix-band detector cannot match Folia's own htdemucs **drum stem** on hard material (a swept
  kick under a sustained bass line): recall on the synthetic kick track is low, though the errors it
  does report are tight and the extras are purely additive. The offline-corrected stream carries the
  timing; the tee measures the bias and adds hits.
- The device-type latency defaults are estimates (Android exposes no public per-route latency); the
  calibration flash is the ground truth per device.
- The Kotlin side compiles only on the GitHub runner (no SDK here). Everything else was executed:
  apply.py twice (idempotent, PlaybackService patch applied), the licence check, the web build
  (`vite build`) and the strict `tsc` type-check on the host files, plus the two test scripts above.

## 8. Battery cost

The tap is inactive with the page closed (pass-through copy only, ~0.1 % CPU). While open: ~86 FFTs/s
of 2048 points plus picking ≈ **under 1 % of one Cortex-A78 core, ≈ 0.1 s of CPU per minute of
playback**. The detector replaces the android `Visualizer` (which ran its own DSP continuously), so
net cost is roughly unchanged; the permission is gone.

## 9. Kept behaviour

Light mode, the frame governor, "React to drums & bass" vs "React to the beat grid", the Timing
slider, the 18 s native-engine fallback, and every existing bridge name — all unchanged. The only
additions are the `until` field in the drums JSON and the two new Tune switches.

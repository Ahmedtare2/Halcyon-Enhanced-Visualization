# TASK C report — Arabic (right-to-left, joined letters) in every Folia style

Date: 2026-11-18. Written for the Halcyon × Folia lyric visualizer project.

## 1. Approach

Folia's own RTL-ready styles (classic, partita, monet, diorama) branch on its helper
`resolveLyricTextDirection` and mirror positions/sweeps in their layout code. Task C gives the
remaining twelve styles the same treatment **in their own code** — mirroring x positions and the
sweep per row while the lyric data stays in logical order with ascending times — instead of
pre-reordering the data (the old `shaped-visual`/`logical-reversed` transforms, which fought the
styles' own assumptions: time-ascending sweeps, row wrapping, prefix measurement).

The data side (`arabic.ts` in folia-host) now only distinguishes two cases:

- **native** — the style draws whole words/runs (DOM nodes, canvas `fillText` of a run), so the
  browser or canvas bidi shapes them: classic, partita, monet, diorama, still, pendolo, cadenza.
- **shaped-logical** — the style draws one glyph at a time (Pixi sprites/Text per glyph, canvas
  per-char slices, DOM per-letter spans), which breaks contextual joining: pre-shaped Presentation
  Forms in logical order: machi, cappella, tilt, claddagh, fume, hanabi, lumiere, nebbia, sonnet,
  tempera.

Every mirror is gated on `resolveLyricTextDirection(line text) === 'rtl'`, so **Latin lyrics are
untouched by construction**. All fixes are anchored, idempotent patches in `apply.py` (15 patch
blocks) or edits of folia-host files; no Folia file is forked.

## 2. Per-style table (the deliverable of item 4)

| Style | Renderer | Arabic mode | What the patch does | Sweep |
|---|---|---|---|---|
| classic | DOM (GlowWord) | native | none — Folia already RTL-ready | its own |
| partita | DOM chunks | native | none — RTL-ready | its own |
| monet | DOM rail | native | none — RTL-ready (right origin, 270° sweep) | its own |
| diorama | three.js raster | native | none — RTL-ready (mirrored centerX + camera) | its own |
| machi | three.js LED board | shaped-logical | already mirrored from Task A/B era (`uRtl`, board + shader) | mirrored |
| still | DOM whole line | **native** (was logical-reversed) | `dir` on the line box (first-strong) | n/a (static) |
| pendolo | DOM mask sweep | **native** (was logical-reversed) | `dir=rtl` rows; the lit mask grows from the right (`270deg`); per-line flag | **mirrored** |
| cadenza | DOM word nodes | **native** (was logical-reversed) | fragment `baseX` mirrored (word bodies keep browser shaping; glow spans are transparent decorations) | time-based |
| cappella | DOM bubbles | **shaped-logical** (was logical-reversed) | `dir="auto"` on the bubble text: the existing prefix-count reveal sweeps R→L | **mirrored** |
| tilt | DOM per-letter spans | **shaped-logical** (was logical-reversed) | `dir` on both row variants; the stagger delay (ascending logical index) now reveals R→L | **mirrored** |
| claddagh | DOM arc | **shaped-logical** (was logical-reversed) | `nominalAngle` mirrored — first letter at the largest angle (rightmost), read head follows leftward | **mirrored** |
| fume | Canvas newspaper | **shaped-logical** (was logical-reversed) | static snapshot right-aligned; live runs: x mirrored, clip window mirrored, printed/frontier prefix counted from the end | **mirrored** |
| hanabi | Pixi atlas sprites | **shaped-logical** (was shaped-visual) | `rtl` flag into the layout; every row's glyph x mirrored about the line centre (diagonal tilt mirrors with it) | time-based |
| lumiere | Pixi line-canvas slices | **shaped-logical** (was shaped-visual) | glyph x mirrored at the row-composition point; the chasing light uses the same mirrored x | **mirrored** |
| nebbia | WebGL stroke ink | **shaped-logical** (was shaped-visual) | block emit mirrored; row compositions walk blocks right→left (decorative cross/pillar/orbit layouts keep their arrangement) | time-based (write) |
| sonnet | Pixi Text per glyph | **shaped-logical** (was shaped-visual) | segment carries the direction; per-segment glyph cursor mirrored; all shot flow boxes mirrored after layout (entrance vectors flip too) | time-based |
| tempera | Pixi Text per glyph | **shaped-logical** (was shaped-visual) | final glyph point mirrored about the region centre — flips word order and letter order together (drift/tilt keep their look) | time-based |
| (shared) | VisualizerSubtitleOverlay | — | `dir="auto"` per row: 9 styles' bottom translation/next-line overlay now orders Arabic-first and mixed rows correctly | n/a |

## 3. Test harness and results (item 3)

Playwright + headless Chromium (SwiftShader WebGL) drove the **built** `halcyon-host.html`:
`setTheme` + `setSong` + `setLyrics` + `setMode` + `setClock`, Noto Naskh Arabic injected (the same
family the phone uses; its 140 presentation-form glyphs cover every shaped letter including the
lam-alef ligatures). 51 screenshots: 17 styles × portrait 393×873 (main line + long wrapping line)
× DPR 1.5 + landscape 873×393, plus 5 labelled contact sheets in
`download/arabic-screenshots/` (portrait ×2, wrap ×2, landscape). Zero page errors, zero blank
renders.

Test lines cover everything the task lists: Egyptian dialect (إزيك عامل إيه يا صاحبي النهارده),
punctuation (،؟!), lam-alef (لا، الأهلي), ta marbuta + hamza (مدرسة، الآمال، وسؤال), digits (25،
10:30), a Latin word inside an Arabic line (بعت الـ CD في الـ studio بالليل), a long line that
wraps to 3+ rows, and diacritics (مُحَمَّدٌ سَمِعَ الصَّوْتَ).

Findings across all 17 styles: reading order right→left; wrapped rows in reading order (cappella's
7-row bubble and lumiere/pendolo wraps verified line by line); the positional sweeps (pendolo
mask, fume printed frontier, claddagh arc, cappella/tilt reveals) run right→left; joined letters
everywhere (shaped forms where glyphs are drawn singly, browser shaping where whole words are
drawn); no clipping or off-screen overflow in either orientation; Latin-only lines byte-identical
(the mirroring never fires).

Two real bugs were found by the harness and fixed during the run: a `lineRtl` scope error in the
fume patch (caught by the page's error boundary in the screenshot), and the missing dark backdrop
in the harness itself (monet's near-white rail text was invisible on the transparent page).

## 4. Residual risks (honest list)

- **hanabi** renders its collage/wallpaper presentation in the harness (its typographic hero fires
  on its own shot schedule); every Arabic word it did draw is shaped and reads R→L, and the layout
  mirror is in the code path, but the hero's on-device behaviour with real playback is not yet seen
  on the phone.
- **Mixed Arabic/Latin bidi** inside the fume canvas article: canvas bidi orders the runs with an
  LTR paragraph base, so a Latin run at a column edge can sit one run off (cosmetic; the DOM
  overlays handle mixed lines correctly via `dir="auto"`).
- **sonnet's decorative shot layouts** (poster blocks, quiet tableau) mirror box positions after
  layout; entrance vectors flip with them, but a shot built around a Latin visual metaphor may look
  slightly different on an RTL line (by design — reading order wins).
- nebbia's decorative compositions (cross, pillar, orbit) keep their LTR arrangement; the reading
  compositions (ribbon, lines2, lines3) are mirrored.
- The harness uses Noto Naskh Arabic; the phone may pick a different Arabic system font per theme —
  shaping behaviour is the same, letter proportions differ slightly.

## 5. Verified / not verified

- Verified: apply.py applies clean on unmodified trees and is idempotent (second run a no-op);
  Halcyon licence check passes; `npm ci` + `vite build` green with every patched style; esbuild
  parses all host files; 111/111 offline checks (now including per-style Task C patch markers and
  the arabic.ts mode table); the 51-screenshot harness run with the results above.
- Not verified: on-device rendering (GitHub Actions compiles the Kotlin; the phone shows the
  pages). The screenshots in `download/arabic-screenshots/` are the before/after evidence for the
  web layer that ships in the APK.

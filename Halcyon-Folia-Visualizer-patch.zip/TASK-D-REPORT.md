# TASK D report

## Android reference
Not present in this chat (`Folia-Music-player--main.zip` missing). Used handoff § TASK D principles and v0.7.25 quality systems already in-tree (machi `quality.ts` degrade ladder, hanabi `renderScale`, nebbia `render` override, latent pixel budget).

## What v0.7.25 already had (vs older phone build ideas)
- Global `lyricRenderQuality` + per-style overrides
- Machi auto-degrade (DOF → SSAA → MSAA → reflections → bloom → scale → AA → shadows)
- Hanabi renderScale / bloom quality helpers
- Nebbia render scale migration from legacy `resolution`
- Latent `MAX_SHADER_PIXELS`

## What we added for Halcyon phones
Numeric caps in apply.py (see CHANGELOG table). Idempotent (`HALCYON_PHONE` markers).

## Backgrounds
Only **latent** is “new” relative to the older Android style list and needed a pixel budget cut. Common/fluid already offloaded in TASK A; monet/nomand/sora/url left web-side (too specific to replace).

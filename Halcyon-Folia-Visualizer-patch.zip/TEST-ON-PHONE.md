# Test on phone (≤ 10 steps)

1. Install the release APK from Actions over the previous build.
2. Open a song → lyrics page → tap the **visualizer** button (between translation and vocal).
3. Confirm Folia styles load (or native fallback if bundle missing).
4. **Swipe styles** through several including Hanabi, Machi, Nebbia, Classic.
5. Open **style settings** inside the visualizer; scroll and change a slider.
6. Switch **background** (common vs Monet if available).
7. Play an **Arabic (Egyptian)** track — check R→L, joined letters, no clip.
8. **Beat reaction**: Tune → drums & bass; adjust Output latency until kicks match.
9. Tune → Quality **Battery** — page should stay smoother / cooler.
10. Rotate to **landscape**, then back; close visualizer and reopen once.

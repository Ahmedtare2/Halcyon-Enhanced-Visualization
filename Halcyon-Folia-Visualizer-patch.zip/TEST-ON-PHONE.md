TEST ON THE PHONE — 10 steps (Halcyon-Folia-Visualizer-patch, Tasks A+B+C+E)
================================================================================
 1. Install the APK from the run's "Halcyon-visualizer-release-arm64-v8a-<run>" artifact
    over the previous build (same signature, no uninstall needed).
 2. Open the player, swipe to the lyrics page.
 3. Tap the visualizer button on the right edge of the lyrics page.
 4. Swipe through ALL the styles: they must now read Arabic right-to-left with joined
    letters, and look unchanged for Latin songs (especially watch fume, sonnet, pendolo,
    lumiere, claddagh, nebbia).
 5. Open the style settings (the gear/Tune controls in the visualizer): settings, tunings
    and the Light mode still work; nothing new is required.
 6. Switch the background once (Tune -> background): the native background behind the
    Folia engine still matches (Task A's work).
 7. Play an ARABIC song (Egyptian dialect judges best): reading order, sweep direction,
    wrapped rows, and a mixed line with a Latin word must all be right.
 8. Check the beat reaction (Task B): effects should land on the real bass/drum hits;
    if a Bluetooth speaker feels late, calibrate with Tune -> "Flash on kicks".
 9. Check battery saver: enable Halcyon's battery saver / low-power mode for a few
    minutes - the frame-rate governor should keep it smooth and cool (Task A).
10. Turn the phone to landscape and swipe styles again: nothing must overflow or clip.

If anything is wrong: screenshot the style and Tune -> "Folia diagnostics", and send the
GitHub run's build-log artifact (build-log) with one sentence about what you saw.

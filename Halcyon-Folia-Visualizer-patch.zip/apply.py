#!/usr/bin/env python3
"""Patches the few existing Halcyon files that must know about the lyric visualizer.

Usage: apply.py <halcyon project root>
Every edit is anchored on exact existing text. If an anchor is missing the script stops with a
clear message instead of silently producing a half-patched app. Re-running is safe.
"""
import re
import sys
from pathlib import Path

root = Path(sys.argv[1]).resolve()
base = root / "app/src/main/java/com/ella/music"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def write(path: Path, text: str) -> None:
    path.write_text(text, encoding="utf-8", newline="\n")


def fail(msg: str) -> None:
    print("PATCH ERROR: " + msg)
    sys.exit(1)


# --------------------------------------------------------------------------- lyric sidecars
utils = base / "data/repository/MusicRepositoryUtils.kt"
src = read(utils)
if "KrcDecoder" not in src:
    old_ext = 'val extensions = if (preferTtml) listOf("ttml") else listOf("lrc", "elrc")\n    val baseName'
    new_ext = 'val extensions = if (preferTtml) listOf("ttml") else listOf("lrc", "elrc", "yrc", "qrc", "krc")\n    val baseName'
    if src.count(old_ext) != 1:
        fail("sidecar extension list not found in MusicRepositoryUtils.kt")
    src = src.replace(old_ext, new_ext)
    old_read = "        if (!file.exists()) return null\n        file.readText()"
    if src.count(old_read) != 1:
        fail("readTextIfExists body not found in MusicRepositoryUtils.kt")
    src = src.replace(old_read, "        if (!file.exists()) return null\n        com.ella.music.data.parser.KrcDecoder.readLyricText(file)")
    write(utils, src)
    print("patched MusicRepositoryUtils.kt (yrc/qrc/krc sidecars, encrypted krc)")
else:
    print("MusicRepositoryUtils.kt already patched")

# --------------------------------------------------------------------------- player overlay
player = base / "ui/player/PlayerScreen.kt"
src = read(player)
if "VisOverlayHost" not in src:
    anchor = re.compile(
        r"(                    \.align\(androidx\.compose\.ui\.Alignment\.BottomCenter\)\s*\n\s*\n\s*\)\n)"
    )
    matches = list(anchor.finditer(src))
    if len(matches) != 1:
        fail("AudioVisualizer anchor not found exactly once in PlayerScreen.kt (found %d)" % len(matches))
    call = """            // Lyric visualizer page (opened from the button on the lyrics page).
            com.ella.music.ui.vis.VisOverlayHost(
                lyrics = lyrics,
                song = song,
                durationMs = duration,
                isPlaying = isPlaying,
                positionProvider = { playerViewModel.livePositionMs() },
                lyricOffsetMs = currentLyricOffsetMs,
                palette = palette,
                paletteBitmap = paletteBitmap,
                embeddedCover = embeddedCover,
                audioSessionId = audioSessionId,
                appFontPath = effectiveLyricFontPath,
                isLandscape = isLandscape,
                lyricsVisible = showLyrics && playerVisible,
                onSeek = { playerViewModel.seekTo(it) },
                onPlayPause = { playerViewModel.togglePlayPause() },
                onPrevious = { playerViewModel.skipToPrevious() },
                onNext = { playerViewModel.skipToNext() },
                playerBackground = { bgModifier ->
                    SharedPlayerPageBackground(
                        song = song,
                        embeddedCover = embeddedCover,
                        paletteBitmap = paletteBitmap,
                        palette = palette,
                        currentPositionMs = currentPosition,
                        isPlaying = isPlaying,
                        playerBackgroundEnabled = playerBackgroundEnabled,
                        playerBackgroundUri = playerBackgroundUri,
                        playerBackgroundOpacity = playerBackgroundOpacity,
                        playerBackgroundDim = playerBackgroundDim,
                        beautifulLyricsBackground = beautifulLyricsBackground,
                        dynamicFlowEnabled = playerDynamicFlowEnabled,
                        useBlurBackground = false,
                        modifier = bgModifier
                    )
                }
            )
"""
    m = matches[0]
    src = src[: m.end()] + call + src[m.end():]
    write(player, src)
    print("patched PlayerScreen.kt (visualizer overlay mounted)")
else:
    print("PlayerScreen.kt already patched")


# --------------------------------------------------------------------------- R8 rules
rules = root / "app/proguard-rules.pro"
if rules.exists():
    text = read(rules)
    marker = "com.ella.music.ui.vis.FoliaBridge"
    if marker not in text:
        text += """

# Lyric visualizer: the Folia WebView page calls these by name.
-keep class com.ella.music.ui.vis.FoliaBridge { *; }
-keepclassmembers class com.ella.music.ui.vis.FoliaBridge {
    @android.webkit.JavascriptInterface <methods>;
}
"""
        write(rules, text)
        print("patched proguard-rules.pro (FoliaBridge)")
    else:
        print("proguard-rules.pro already patched")
else:
    print("note: app/proguard-rules.pro not found, relying on @Keep")


# --------------------------------------------------------------------------- lyrics page button
corner = base / "ui/player/LyricsCornerActions.kt"
src = read(corner)
if "VisController" not in src:
    anchor = """            AppleTranslationIcon(
                color = contentColor,
                active = showTranslation,
                modifier = Modifier.size(36.dp)
            )
        }
"""
    if src.count(anchor) != 1:
        fail("translation icon anchor not found exactly once in LyricsCornerActions.kt")
    button = """        Box(
            modifier = Modifier
                .size(44.dp)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = { com.ella.music.ui.vis.VisController.show() }
                ),
            contentAlignment = Alignment.Center
        ) {
            com.ella.music.ui.vis.VisIcon(
                com.ella.music.ui.vis.VisIconKind.VIS,
                contentColor,
                26.dp
            )
        }
"""
    src = src.replace(anchor, anchor + button)
    write(corner, src)
    print("patched LyricsCornerActions.kt (visualizer button between translation and vocal buttons)")
else:
    print("LyricsCornerActions.kt already patched")


# --------------------------------------------------------------------------- Folia source (optional)
# The Folia sources sit next to the Halcyon project (../folia) when the workflow imported them.
folia = root.parent / "folia"
drum = folia / "src/services/analysis/drumHits.ts"
if drum.exists():
    text = read(drum)
    if "setExternalDrumHits" not in text:
        if "const settled = new Set<string>();" not in text or "const keep = (key: string, hits: DrumHits)" not in text:
            fail("drumHits.ts has changed: cannot add setExternalDrumHits")
        text = text.rstrip("\n") + """

/** Halcyon (the Android host) analyses the drums natively and hands the hits in here. */
export const setExternalDrumHits = (key: string, hits: DrumHits): void => {
    keep(key, hits);
    settled.add(key);
};
"""
        write(drum, text)
        print("patched Folia drumHits.ts (setExternalDrumHits)")
    else:
        print("Folia drumHits.ts already patched")
else:
    print("note: Folia sources not found next to the project; skipping the Folia patch")


# Machi: right-to-left board. Lines in an RTL script are laid out from the right edge, and the lit
# sweep (a shader comparison against the pixel column) runs from the right as well.
machi_layout = folia / "src/components/visualizer/machi/engine/boardLayout.ts"
machi_screen = folia / "src/components/visualizer/machi/engine/lyricScreen.ts"
if machi_layout.exists() and machi_screen.exists():
    def replace_once(text: str, old: str, new: str, label: str) -> str:
        if text.count(old) != 1:
            fail("Machi patch anchor not found exactly once: " + label)
        return text.replace(old, new)

    layout_src = read(machi_layout)
    if "layout.rtl" not in layout_src:
        layout_src = replace_once(
            layout_src,
            "import { buildLineGraphemeTimeline } from '../../../../utils/lyrics/graphemeTiming';\n",
            "import { buildLineGraphemeTimeline } from '../../../../utils/lyrics/graphemeTiming';\nimport { resolveLyricTextDirection } from '../../../../utils/lyrics/textDirection';\n",
            "import")
        layout_src = replace_once(
            layout_src,
            "export interface MachiBoardLayout {\n    fontPx: number;\n    rows: MachiBoardRow[];\n    width: number;\n    height: number;\n}",
            "export interface MachiBoardLayout {\n    fontPx: number;\n    rows: MachiBoardRow[];\n    width: number;\n    height: number;\n    /** Laid out from the right edge and revealed from the right (Arabic, Hebrew). */\n    rtl?: boolean;\n}",
            "interface")
        layout_src = replace_once(
            layout_src,
            "    return placeRows(best.rows, best.fontPx, box, measure);",
            "    const rtl = resolveLyricTextDirection(line.fullText) === 'rtl';\n    return { ...placeRows(best.rows, best.fontPx, box, measure, rtl), rtl };",
            "placeRows call")
        layout_src = replace_once(
            layout_src,
            "const placeRows = (rows: Token[][], fontPx: number, box: MachiBoardBox, measure: MachiMeasure): MachiBoardLayout => {",
            "const placeRows = (rows: Token[][], fontPx: number, box: MachiBoardBox, measure: MachiMeasure, rtl = false): MachiBoardLayout => {",
            "placeRows signature")
        layout_src = replace_once(
            layout_src,
            """            const placed = glyphs.map(glyph => {
                const x0 = left + measure(prefix) * scale;
                prefix += glyph.text;
                const x1 = left + measure(prefix) * scale;
                return { ...glyph, length: glyph.text.length, x0, x1 };
            });""",
            """            const right = left + width;
            const placed = glyphs.map(glyph => {
                const before = measure(prefix) * scale;
                prefix += glyph.text;
                const after = measure(prefix) * scale;
                const x0 = rtl ? right - after : left + before;
                const x1 = rtl ? right - before : left + after;
                return { ...glyph, length: glyph.text.length, x0, x1 };
            });""",
            "glyph placement")
        layout_src = replace_once(
            layout_src,
            """export const resolveMachiBoardReveal = (layout: MachiBoardLayout, time: number): number[] => layout.rows.map(row => {
    let lit = row.glyphs[0]?.x0 ?? 0;""",
            """export const resolveMachiBoardReveal = (layout: MachiBoardLayout, time: number): number[] => layout.rows.map(row => {
    if (layout.rtl) {
        // Mirrored coordinates: the distance of the lit edge from the right edge of the board.
        let mirrored = layout.width - (row.glyphs[0]?.x1 ?? 0);
        for (const glyph of row.glyphs) {
            if (time >= glyph.endTime) {
                mirrored = layout.width - glyph.x0;
                continue;
            }
            if (time > glyph.startTime) {
                const span = Math.max(1e-3, glyph.endTime - glyph.startTime);
                mirrored = layout.width - glyph.x1 + (glyph.x1 - glyph.x0) * Math.min(1, (time - glyph.startTime) / span);
            }
            break;
        }
        return mirrored;
    }
    let lit = row.glyphs[0]?.x0 ?? 0;""",
            "reveal")
        write(machi_layout, layout_src)

    screen_src = read(machi_screen)
    if "uRtl" not in screen_src:
        screen_src = replace_once(screen_src, "uniform float uSoft;\n", "uniform float uSoft;\nuniform float uRtl;\n", "uniform declaration")
        screen_src = replace_once(
            screen_src,
            "    float snapped = (floor(vUv.x * uCells.x) + 0.5) / uCells.x;\n    float on = 1.0 - smoothstep(reveal - uSoft, reveal + uSoft, mix(vUv.x, snapped, grid));",
            "    float ux = mix(vUv.x, 1.0 - vUv.x, uRtl);\n    float snapped = (floor(ux * uCells.x) + 0.5) / uCells.x;\n    float on = 1.0 - smoothstep(reveal - uSoft, reveal + uSoft, mix(ux, snapped, grid));",
            "shader reveal")
        screen_src = replace_once(screen_src, "                uSoft: { value: 0.004 },\n", "                uSoft: { value: 0.004 },\n                uRtl: { value: 0 },\n", "uniform value")
        screen_src = replace_once(
            screen_src,
            "            (reveal[2] ?? 0) / this.box.width,\n        );\n",
            "            (reveal[2] ?? 0) / this.box.width,\n        );\n        this.material.uniforms.uRtl!.value = layout && layout.rtl ? 1 : 0;\n",
            "uniform update")
        write(machi_screen, screen_src)
    print("patched Folia Machi (right-to-left board)")

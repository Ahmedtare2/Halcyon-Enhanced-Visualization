#!/usr/bin/env python3
"""Patches the few existing Halcyon files that must know about the lyric visualizer.

Usage: apply.py <halcyon project root>
Every edit is anchored on exact existing text. If an anchor is missing the script stops with a
clear message instead of silently producing a half-patched app. Re-running is safe.
"""
import re
import sys
from pathlib import Path

root = Path(sys.argv[1]).resolve()
base = root / "app/src/main/java/com/ella/music"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def write(path: Path, text: str) -> None:
    path.write_text(text, encoding="utf-8", newline="\n")


def fail(msg: str) -> None:
    print("PATCH ERROR: " + msg)
    sys.exit(1)


# --------------------------------------------------------------------------- lyric sidecars
utils = base / "data/repository/MusicRepositoryUtils.kt"
src = read(utils)
if "KrcDecoder" not in src:
    old_ext = 'val extensions = if (preferTtml) listOf("ttml") else listOf("lrc", "elrc")\n    val baseName'
    new_ext = 'val extensions = if (preferTtml) listOf("ttml") else listOf("lrc", "elrc", "yrc", "qrc", "krc")\n    val baseName'
    if src.count(old_ext) != 1:
        fail("sidecar extension list not found in MusicRepositoryUtils.kt")
    src = src.replace(old_ext, new_ext)
    old_read = "        if (!file.exists()) return null\n        file.readText()"
    if src.count(old_read) != 1:
        fail("readTextIfExists body not found in MusicRepositoryUtils.kt")
    src = src.replace(old_read, "        if (!file.exists()) return null\n        com.ella.music.data.parser.KrcDecoder.readLyricText(file)")
    write(utils, src)
    print("patched MusicRepositoryUtils.kt (yrc/qrc/krc sidecars, encrypted krc)")
else:
    print("MusicRepositoryUtils.kt already patched")

# --------------------------------------------------------------------------- player overlay
player = base / "ui/player/PlayerScreen.kt"
src = read(player)
if "VisOverlayHost" not in src:
    anchor = re.compile(
        r"(                    \.align\(androidx\.compose\.ui\.Alignment\.BottomCenter\)\s*\n\s*\n\s*\)\n)"
    )
    matches = list(anchor.finditer(src))
    if len(matches) != 1:
        fail("AudioVisualizer anchor not found exactly once in PlayerScreen.kt (found %d)" % len(matches))
    call = """            // Lyric visualizer page (opened from the button on the lyrics page).
            com.ella.music.ui.vis.VisOverlayHost(
                lyrics = lyrics,
                song = song,
                durationMs = duration,
                isPlaying = isPlaying,
                positionProvider = { playerViewModel.livePositionMs() },
                lyricOffsetMs = currentLyricOffsetMs,
                palette = palette,
                paletteBitmap = paletteBitmap,
                embeddedCover = embeddedCover,
                audioSessionId = audioSessionId,
                appFontPath = effectiveLyricFontPath,
                isLandscape = isLandscape,
                lyricsVisible = showLyrics && playerVisible,
                onSeek = { playerViewModel.seekTo(it) },
                onPlayPause = { playerViewModel.togglePlayPause() },
                onPrevious = { playerViewModel.skipToPrevious() },
                onNext = { playerViewModel.skipToNext() },
                playerBackground = { bgModifier ->
                    SharedPlayerPageBackground(
                        song = song,
                        embeddedCover = embeddedCover,
                        paletteBitmap = paletteBitmap,
                        palette = palette,
                        currentPositionMs = currentPosition,
                        isPlaying = isPlaying,
                        playerBackgroundEnabled = playerBackgroundEnabled,
                        playerBackgroundUri = playerBackgroundUri,
                        playerBackgroundOpacity = playerBackgroundOpacity,
                        playerBackgroundDim = playerBackgroundDim,
                        beautifulLyricsBackground = beautifulLyricsBackground,
                        dynamicFlowEnabled = playerDynamicFlowEnabled,
                        useBlurBackground = false,
                        modifier = bgModifier
                    )
                }
            )
"""
    m = matches[0]
    src = src[: m.end()] + call + src[m.end():]
    write(player, src)
    print("patched PlayerScreen.kt (visualizer overlay mounted)")
else:
    print("PlayerScreen.kt already patched")


# --------------------------------------------------------------------------- R8 rules
rules = root / "app/proguard-rules.pro"
if rules.exists():
    text = read(rules)
    marker = "com.ella.music.ui.vis.FoliaBridge"
    if marker not in text:
        text += """

# Lyric visualizer: the Folia WebView page calls these by name.
-keep class com.ella.music.ui.vis.FoliaBridge { *; }
-keepclassmembers class com.ella.music.ui.vis.FoliaBridge {
    @android.webkit.JavascriptInterface <methods>;
}
"""
        write(rules, text)
        print("patched proguard-rules.pro (FoliaBridge)")
    else:
        print("proguard-rules.pro already patched")
else:
    print("note: app/proguard-rules.pro not found, relying on @Keep")


# --------------------------------------------------------------------------- lyrics page button
corner = base / "ui/player/LyricsCornerActions.kt"
src = read(corner)
if "VisController" not in src:
    anchor = """            AppleTranslationIcon(
                color = contentColor,
                active = showTranslation,
                modifier = Modifier.size(36.dp)
            )
        }
"""
    if src.count(anchor) != 1:
        fail("translation icon anchor not found exactly once in LyricsCornerActions.kt")
    button = """        Box(
            modifier = Modifier
                .size(44.dp)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = { com.ella.music.ui.vis.VisController.show() }
                ),
            contentAlignment = Alignment.Center
        ) {
            com.ella.music.ui.vis.VisIcon(
                com.ella.music.ui.vis.VisIconKind.VIS,
                contentColor,
                26.dp
            )
        }
"""
    src = src.replace(anchor, anchor + button)
    write(corner, src)
    print("patched LyricsCornerActions.kt (visualizer button between translation and vocal buttons)")
else:
    print("LyricsCornerActions.kt already patched")


# --------------------------------------------------------------------------- TASK B: timestamped PCM tap
# Capture only frames accepted by the existing sink; the tap is dormant when no visualizer listens.
def taskb_replace(text: str, old: str, new: str, label: str) -> str:
    if text.count(old) != 1:
        fail("Task B anchor not found exactly once: " + label)
    return text.replace(old, new)

renderers = base / "player/EllaRenderersFactory.kt"
src = read(renderers)
if "PcmTapAudioSink" not in src:
    src = taskb_replace(src, "import java.util.ArrayList\n", "import java.util.ArrayList\n", "renderers import anchor")
    src = taskb_replace(
        src,
        "    private var playbackOutputSettings: PlaybackOutputSettings = PlaybackOutputSettings()\n",
        "    private var playbackOutputSettings: PlaybackOutputSettings = PlaybackOutputSettings()\n    private var pcmTapTrackKeyProvider: () -> String? = { null }\n    private val pcmTapSourceId: String = java.util.UUID.randomUUID().toString()\n",
        "renderers tap fields",
    )
    src = taskb_replace(
        src,
        "    fun setPlaybackOutputSettings(settings: PlaybackOutputSettings) {\n        this.playbackOutputSettings = settings\n    }\n",
        "    fun setPlaybackOutputSettings(settings: PlaybackOutputSettings) {\n        this.playbackOutputSettings = settings\n    }\n\n    internal fun setPcmTapTrackKeyProvider(provider: () -> String?) {\n        pcmTapTrackKeyProvider = provider\n    }\n",
        "renderers tap setter",
    )
    src = taskb_replace(
        src,
        "            return OboeAudioSink(\n                audioApi = audioApi,\n                exclusive = usbExclusive,\n                processors = processors,\n                deviceId = deviceId,\n                appContext = context.applicationContext\n            )",
        "            return PcmTapAudioSink(\n                OboeAudioSink(\n                    audioApi = audioApi,\n                    exclusive = usbExclusive,\n                    processors = processors,\n                    deviceId = deviceId,\n                    appContext = context.applicationContext\n                ),\n                pcmTapSourceId,\n                pcmTapTrackKeyProvider\n            )",
        "Oboe sink tap",
    )
    src = taskb_replace(src, "        return if (processors.isNotEmpty() || playbackOutputSettings.forceFloatOutput) {", "        val outputSink = if (processors.isNotEmpty() || playbackOutputSettings.forceFloatOutput) {", "default sink tap start")
    src = taskb_replace(
        src,
        "        }\n    }\n\n    private fun resolveUsbOutputDeviceId(context: Context): Int {",
        "        }\n        return outputSink?.let { PcmTapAudioSink(it, pcmTapSourceId, pcmTapTrackKeyProvider) }\n    }\n\n    private fun resolveUsbOutputDeviceId(context: Context): Int {",
        "default sink tap end",
    )
    write(renderers, src)
    print("patched EllaRenderersFactory.kt (timestamped PCM tap)")
else:
    print("EllaRenderersFactory.kt already has the PCM tap")

service = base / "player/PlaybackService.kt"
src = read(service)
if "setPcmTapTrackKeyProvider" not in src:
    src = taskb_replace(
        src,
        "            .setMediaSourceFactory(mediaSourceFactory)\n            .build()\n        player.repeatMode = Player.REPEAT_MODE_ALL",
        "            .setMediaSourceFactory(mediaSourceFactory)\n            .build()\n        var primaryTapMediaId: String? = null\n        var primaryTapKey: String? = null\n        renderersFactory.setPcmTapTrackKeyProvider {\n            if (!player.isPlaying) null else {\n                val item = player.currentMediaItem\n                val mediaId = item?.mediaId\n                if (mediaId != primaryTapMediaId) {\n                    primaryTapMediaId = mediaId\n                    primaryTapKey = item?.toSongFromMediaItemExtras()?.path\n                }\n                primaryTapKey\n            }\n        }\n        player.repeatMode = Player.REPEAT_MODE_ALL",
        "primary player key provider",
    )
    src = taskb_replace(
        src,
        "        crossfadePlaybackCoordinator = CrossfadePlaybackCoordinator(\n",
        "        val secondaryPcmTapPlayer = java.util.concurrent.atomic.AtomicReference<ExoPlayer?>()\n        crossfadePlaybackCoordinator = CrossfadePlaybackCoordinator(\n",
        "secondary player ref",
    )
    src = taskb_replace(
        src,
        "                    setTransitionGainAudioProcessor(secondaryTransitionGain)\n                    setPlaybackOutputSettings(playbackOutputSettings)\n",
        "                    setTransitionGainAudioProcessor(secondaryTransitionGain)\n                    setPlaybackOutputSettings(playbackOutputSettings)\n                    var tapMediaId: String? = null\n                    var tapKey: String? = null\n                    setPcmTapTrackKeyProvider {\n                        val tapPlayer = secondaryPcmTapPlayer.get()\n                        if (tapPlayer?.isPlaying != true) null else {\n                            val item = tapPlayer.currentMediaItem\n                            val mediaId = item?.mediaId\n                            if (mediaId != tapMediaId) {\n                                tapMediaId = mediaId\n                                tapKey = item?.toSongFromMediaItemExtras()?.path\n                            }\n                            tapKey\n                        }\n                    }\n",
        "secondary player key provider",
    )
    src = taskb_replace(
        src,
        "            onPlayerCreated = { decoder, gain ->\n                bindPlayerReplayGain(decoder, gain, settingsManager, musicRepository, serviceScope)\n            }",
        "            onPlayerCreated = { decoder, gain ->\n                if (decoder !== player) secondaryPcmTapPlayer.set(decoder)\n                bindPlayerReplayGain(decoder, gain, settingsManager, musicRepository, serviceScope)\n            }",
        "secondary tap player binding",
    )
    write(service, src)
    print("patched PlaybackService.kt (primary and crossfade track keys)")
else:
    print("PlaybackService.kt already has the PCM tap providers")

# --------------------------------------------------------------------------- Folia source (optional)
# The Folia sources sit next to the Halcyon project (../folia) when the workflow imported them.
folia = root.parent / "folia"
drum = folia / "src/services/analysis/drumHits.ts"
if drum.exists():
    text = read(drum)
    if "setExternalDrumHits" not in text:
        if "const settled = new Set<string>();" not in text or "const keep = (key: string, hits: DrumHits)" not in text:
            fail("drumHits.ts has changed: cannot add setExternalDrumHits")
        text = text.rstrip("\n") + """

/** Halcyon (the Android host) analyses the drums natively and hands the hits in here. */
export const setExternalDrumHits = (key: string, hits: DrumHits): void => {
    keep(key, hits);
    settled.add(key);
};
"""
        write(drum, text)
        print("patched Folia drumHits.ts (setExternalDrumHits)")
    else:
        print("Folia drumHits.ts already patched")
else:
    print("note: Folia sources not found next to the project; skipping the Folia patch")


# Machi: right-to-left board. Lines in an RTL script are laid out from the right edge, and the lit
# sweep (a shader comparison against the pixel column) runs from the right as well.
machi_layout = folia / "src/components/visualizer/machi/engine/boardLayout.ts"
machi_screen = folia / "src/components/visualizer/machi/engine/lyricScreen.ts"
if machi_layout.exists() and machi_screen.exists():
    def replace_once(text: str, old: str, new: str, label: str) -> str:
        if text.count(old) != 1:
            fail("Machi patch anchor not found exactly once: " + label)
        return text.replace(old, new)

    layout_src = read(machi_layout)
    if "layout.rtl" not in layout_src:
        layout_src = replace_once(
            layout_src,
            "import { buildLineGraphemeTimeline } from '../../../../utils/lyrics/graphemeTiming';\n",
            "import { buildLineGraphemeTimeline } from '../../../../utils/lyrics/graphemeTiming';\nimport { resolveLyricTextDirection } from '../../../../utils/lyrics/textDirection';\n",
            "import")
        layout_src = replace_once(
            layout_src,
            "export interface MachiBoardLayout {\n    fontPx: number;\n    rows: MachiBoardRow[];\n    width: number;\n    height: number;\n}",
            "export interface MachiBoardLayout {\n    fontPx: number;\n    rows: MachiBoardRow[];\n    width: number;\n    height: number;\n    /** Laid out from the right edge and revealed from the right (Arabic, Hebrew). */\n    rtl?: boolean;\n}",
            "interface")
        layout_src = replace_once(
            layout_src,
            "    return placeRows(best.rows, best.fontPx, box, measure);",
            "    const rtl = resolveLyricTextDirection(line.fullText) === 'rtl';\n    return { ...placeRows(best.rows, best.fontPx, box, measure, rtl), rtl };",
            "placeRows call")
        layout_src = replace_once(
            layout_src,
            "const placeRows = (rows: Token[][], fontPx: number, box: MachiBoardBox, measure: MachiMeasure): MachiBoardLayout => {",
            "const placeRows = (rows: Token[][], fontPx: number, box: MachiBoardBox, measure: MachiMeasure, rtl = false): MachiBoardLayout => {",
            "placeRows signature")
        layout_src = replace_once(
            layout_src,
            """            const placed = glyphs.map(glyph => {
                const x0 = left + measure(prefix) * scale;
                prefix += glyph.text;
                const x1 = left + measure(prefix) * scale;
                return { ...glyph, length: glyph.text.length, x0, x1 };
            });""",
            """            const right = left + width;
            const placed = glyphs.map(glyph => {
                const before = measure(prefix) * scale;
                prefix += glyph.text;
                const after = measure(prefix) * scale;
                const x0 = rtl ? right - after : left + before;
                const x1 = rtl ? right - before : left + after;
                return { ...glyph, length: glyph.text.length, x0, x1 };
            });""",
            "glyph placement")
        layout_src = replace_once(
            layout_src,
            """export const resolveMachiBoardReveal = (layout: MachiBoardLayout, time: number): number[] => layout.rows.map(row => {
    let lit = row.glyphs[0]?.x0 ?? 0;""",
            """export const resolveMachiBoardReveal = (layout: MachiBoardLayout, time: number): number[] => layout.rows.map(row => {
    if (layout.rtl) {
        // Mirrored coordinates: the distance of the lit edge from the right edge of the board.
        let mirrored = layout.width - (row.glyphs[0]?.x1 ?? 0);
        for (const glyph of row.glyphs) {
            if (time >= glyph.endTime) {
                mirrored = layout.width - glyph.x0;
                continue;
            }
            if (time > glyph.startTime) {
                const span = Math.max(1e-3, glyph.endTime - glyph.startTime);
                mirrored = layout.width - glyph.x1 + (glyph.x1 - glyph.x0) * Math.min(1, (time - glyph.startTime) / span);
            }
            break;
        }
        return mirrored;
    }
    let lit = row.glyphs[0]?.x0 ?? 0;""",
            "reveal")
        write(machi_layout, layout_src)

    screen_src = read(machi_screen)
    if "uRtl" not in screen_src:
        screen_src = replace_once(screen_src, "uniform float uSoft;\n", "uniform float uSoft;\nuniform float uRtl;\n", "uniform declaration")
        screen_src = replace_once(
            screen_src,
            "    float snapped = (floor(vUv.x * uCells.x) + 0.5) / uCells.x;\n    float on = 1.0 - smoothstep(reveal - uSoft, reveal + uSoft, mix(vUv.x, snapped, grid));",
            "    float ux = mix(vUv.x, 1.0 - vUv.x, uRtl);\n    float snapped = (floor(ux * uCells.x) + 0.5) / uCells.x;\n    float on = 1.0 - smoothstep(reveal - uSoft, reveal + uSoft, mix(ux, snapped, grid));",
            "shader reveal")
        screen_src = replace_once(screen_src, "                uSoft: { value: 0.004 },\n", "                uSoft: { value: 0.004 },\n                uRtl: { value: 0 },\n", "uniform value")
        screen_src = replace_once(
            screen_src,
            "            (reveal[2] ?? 0) / this.box.width,\n        );\n",
            "            (reveal[2] ?? 0) / this.box.width,\n        );\n        this.material.uniforms.uRtl!.value = layout && layout.rtl ? 1 : 0;\n",
            "uniform update")
        write(machi_screen, screen_src)
    print("patched Folia Machi (right-to-left board)")


# GPU budget (Halcyon profile, see folia-host/src/halcyon/budget.ts). Two backgrounds draw full-screen
# Paper shaders; their pixel caps are handed to the page's budget. Each edit is anchored and checked.
latent = folia / "src/components/visualizer/backgrounds/latent/LatentBackground.tsx"
nomand = folia / "src/components/visualizer/backgrounds/nomand/NomandBackgroundLayer.tsx"
if latent.exists() and nomand.exists():
    def once(text: str, old: str, new: str, label: str) -> str:
        if text.count(old) != 1:
            fail("GPU budget patch anchor not found exactly once: " + label)
        return text.replace(old, new)

    latent_src = read(latent)
    if "LATENT_MESH_MAX_PIXELS" not in latent_src:
        latent_src = once(
            latent_src,
            "import { updatePaperShaderUniforms } from '../../../../utils/paperShaderUniforms';\n",
            "import { updatePaperShaderUniforms } from '../../../../utils/paperShaderUniforms';\nimport { LATENT_MESH_MAX_PIXELS } from '../../../../halcyon/budget';\n",
            "Latent import")
        latent_src = once(
            latent_src,
            "speed={staticMode ? 0 : tuning.meshSpeed}\n                        minPixelRatio={1}\n                        maxPixelCount={MAX_SHADER_PIXELS}",
            "speed={staticMode ? 0 : tuning.meshSpeed}\n                        minPixelRatio={1}\n                        maxPixelCount={LATENT_MESH_MAX_PIXELS}",
            "Latent mesh pixel cap")
        write(latent, latent_src)
        print("patched Folia Latent background (mesh pixel budget)")
    else:
        print("Folia Latent background already patched")

    nomand_src = read(nomand)
    if "nomandMaxPixels" not in nomand_src:
        nomand_src = once(
            nomand_src,
            "import { PAPER_SHADER_CONTEXT_ATTRIBUTES } from '../../../../utils/paperShaderContext';\n",
            "import { PAPER_SHADER_CONTEXT_ATTRIBUTES } from '../../../../utils/paperShaderContext';\nimport { nomandMaxPixels } from '../../../../halcyon/budget';\n",
            "Nomand import")
        nomand_src = once(
            nomand_src,
            "            maxPixelCount: 1920 * 1080,\n",
            "            maxPixelCount: nomandMaxPixels(),\n",
            "Nomand pixel cap")
        write(nomand, nomand_src)
        print("patched Folia Nomand background (pixel budget)")
    else:
        print("Folia Nomand background already patched")


# --------------------------------------------------------------------------- TASK C: Arabic word-level layout
# Keep Sonnet and Tempera's original appearance and Latin per-letter animation. Arabic is laid out
# as one browser-shaped word per timed unit, mirrored after logical-time packing so rows remain in
# reading order. The anchors deliberately match only the shipped Folia 0.7.25 source.
if folia.exists():
    helper_path = folia / "src/utils/lyrics/arabicText.ts"
    helper_marker = "// Halcyon Task C RTL restoration v1"
    patch_path = Path(__file__).resolve().parent / "taskc-arabic-rtl.patch"
    if helper_path.exists() and helper_marker in read(helper_path):
        print("Folia Arabic RTL restoration already applied")
    else:
        if not patch_path.is_file():
            fail("Task C patch data is missing: taskc-arabic-rtl.patch")
        patch_lines = patch_path.read_text(encoding="utf-8").splitlines(keepends=True)
        pending: dict[Path, str] = {}
        current_file: Path | None = None
        i = 0
        while i < len(patch_lines):
            line = patch_lines[i]
            if line.startswith("--- "):
                i += 1
                if i >= len(patch_lines) or not patch_lines[i].startswith("+++ "):
                    fail("Task C patch has a malformed file header")
                dest = patch_lines[i][4:].strip().split("\t", 1)[0]
                if not dest.startswith("b/src/"):
                    fail("Task C patch target is outside Folia src: " + dest)
                current_file = folia / dest[2:]
                if current_file not in pending:
                    pending[current_file] = current_file.read_text(encoding="utf-8") if current_file.exists() else ""
                i += 1
                continue
            if line.startswith("@@ "):
                if current_file is None:
                    fail("Task C patch hunk has no file header")
                old_lines: list[str] = []
                new_lines: list[str] = []
                i += 1
                while i < len(patch_lines) and not patch_lines[i].startswith(("@@ ", "--- ")):
                    hline = patch_lines[i]
                    if hline.startswith("\\ No newline"):
                        i += 1
                        continue
                    if not hline or hline[0] not in " +-":
                        fail("Task C patch contains an invalid hunk line")
                    if hline[0] in " -": old_lines.append(hline[1:])
                    if hline[0] in " +": new_lines.append(hline[1:])
                    i += 1
                before = "".join(old_lines)
                after = "".join(new_lines)
                source = pending[current_file]
                if not before:
                    if source:
                        fail("Task C add-file anchor already exists without the version marker: " + str(current_file))
                    pending[current_file] = after
                else:
                    count = source.count(before)
                    if count != 1:
                        fail("Task C source anchor not found exactly once in " + str(current_file))
                    pending[current_file] = source.replace(before, after, 1)
                continue
            i += 1
        if not pending or helper_path not in pending:
            fail("Task C patch did not contain its shared Arabic helper")
        if helper_marker not in pending[helper_path]:
            fail("Task C Arabic helper marker is missing after patching")
        for path, content in pending.items():
            path.parent.mkdir(parents=True, exist_ok=True)
            write(path, content)
        print("patched legacy Folia styles with RTL row layout and Arabic shaping")

    def taskc_once(path: Path, text: str, old: str, new: str, label: str) -> str:
        if new in text:
            return text
        if text.count(old) != 1:
            fail("Task C anchor not found exactly once: " + label)
        return text.replace(old, new)

    sonnet_semantic = folia / "src/components/visualizer/sonnet/sonnetSemantic.ts"
    if sonnet_semantic.exists():
        src = read(sonnet_semantic)
        old = """    return {
        graphemes,
        wordIndices,
        startTime: graphemes[0]?.startTime ?? line.startTime,
        endTime: graphemes[graphemes.length - 1]?.endTime ?? line.endTime,
    };"""
        new = """    const rtlWord = /[\\u0600-\\u06FF\\u0750-\\u077F\\u08A0-\\u08FF]/u.test(
        line.fullText.slice(startOffset, endOffset),
    );
    const startTime = graphemes.length > 0
        ? Math.min(...graphemes.map(item => item.startTime))
        : line.startTime;
    const endTime = graphemes.length > 0
        ? Math.max(...graphemes.map(item => item.endTime))
        : line.endTime;
    return {
        // A whole Arabic word is one Pixi.Text node. The browser shapes it contextually; its
        // lyric interval still spans the parser's original letter/syllable timings.
        graphemes: rtlWord ? [{ char: line.fullText.slice(startOffset, endOffset), startTime, endTime }] : graphemes,
        wordIndices,
        startTime,
        endTime,
    };"""
        src = taskc_once(sonnet_semantic, src, old, new, "Sonnet Arabic word timing")
        write(sonnet_semantic, src)

    sonnet_layout = folia / "src/components/visualizer/sonnet/sonnetTypographyLayout.ts"
    if sonnet_layout.exists():
        src = read(sonnet_layout)
        src = taskc_once(
            sonnet_layout, src,
            "import { layoutWithLines, prepareWithSegments } from '@chenglou/pretext';\n",
            "import { layoutWithLines, prepareWithSegments } from '@chenglou/pretext';\nimport { resolveLyricTextDirection } from '../../../utils/lyrics/textDirection';\n",
            "Sonnet RTL import")
        src = taskc_once(
            sonnet_layout, src,
            "        let fontScale = isHero\n",
            "        // Arabic cursive words stay horizontal and are positioned as whole shaped words.\n        if (resolveLyricTextDirection(segment.text) === 'rtl') vertical = false;\n\n        let fontScale = isHero\n",
            "Sonnet Arabic horizontal layout")
        old = """    return boxes.map(box => ({
        segmentIndex: box.index,
        displayText: box.displayText,
        role: box.role || (box.isHero ? 'hero' : box.isSemiHero ? 'semi-hero' : 'support'),
        fontScale: box.fontScale,
        measuredWidth: box.measuredWidth,
        measuredHeight: box.measuredHeight,
        x: box.x,
        y: box.y,
        rotation: box.rotation,
        enterX: box.enterX,
        enterY: box.enterY,
        vertical: box.vertical,
        layoutDirection: box.layoutDirection,
        timingPhase: box.timingPhase,
    }));"""
        new = """    const rtlSegments = new Set<number>();
    let lineOffset = 0;
    lines.forEach(lineSegments => {
        if (resolveLyricTextDirection(lineSegments.map(segment => segment.text).join('')) === 'rtl') {
            lineSegments.forEach((_, index) => rtlSegments.add(lineOffset + index));
        }
        lineOffset += lineSegments.length;
    });
    return boxes.map(box => {
        const mirror = rtlSegments.has(box.index);
        return {
            segmentIndex: box.index,
            displayText: box.displayText,
            role: box.role || (box.isHero ? 'hero' : box.isSemiHero ? 'semi-hero' : 'support'),
            fontScale: box.fontScale,
            measuredWidth: box.measuredWidth,
            measuredHeight: box.measuredHeight,
            // Coordinates use the viewport centre as origin: mirroring x preserves each row's
            // fit and vertical order while making ascending lyric times sweep from right to left.
            x: mirror ? -box.x : box.x,
            y: box.y,
            rotation: box.rotation,
            enterX: mirror ? -box.enterX : box.enterX,
            enterY: box.enterY,
            vertical: box.vertical,
            layoutDirection: box.layoutDirection,
            timingPhase: box.timingPhase,
        };
    });"""
        src = taskc_once(sonnet_layout, src, old, new, "Sonnet mirrored RTL placements")
        write(sonnet_layout, src)



# --------------------------------------------------------------------------- TASK D: phone budgets for newer Folia styles
# Reuse the older Android build's renderer-specific pixel budgets. Newer Folia has no new
# top-level backgrounds; its added Hanabi/Machi/Nebbia styles carry their own expensive scenes.
if folia.exists():
    budget = folia / "src/halcyon/budget.ts"
    if not budget.exists():
        fail("Task D requires folia-host/src/halcyon/budget.ts")
    budget_src = read(budget)
    taskd_marker = "// TASK_D_PHONE_BUDGET"
    if taskd_marker not in budget_src:
        anchor = """export const nomandMaxPixels = (): number => {
    const folia = 1920 * 1080;
    if (HALCYON_PROFILE !== 'battery') return folia;
    const css = Math.round((window.innerWidth || 360) * (window.innerHeight || 640));
    return Math.min(folia, Math.max(150000, css));
};
"""
        addition = anchor + """
// TASK_D_PHONE_BUDGET
// Match the Android reference: cap Pixi glyph/filter buffers at 1.25x and other full-screen
// WebGL/Canvas buffers at 1.5x, with a 1536px texture-axis ceiling. Battery mode tightens the
// base to 1x; existing per-style/global render-quality settings still apply after this base.
export const isHalcyonMobileGpu = (): boolean => {
    if (typeof window !== 'undefined' && Boolean((window as Window & { electron?: unknown }).electron)) return false;
    const ua = typeof navigator !== 'undefined' ? navigator.userAgent : '';
    if (/Android|iPhone|iPad|iPod/i.test(ua)) return true;
    return typeof window !== 'undefined' && (window.innerWidth <= 768 || Math.min(window.innerWidth, window.innerHeight) <= 540);
};

export const resolveHalcyonBasePixelRatio = (
    width: number,
    height: number,
    requested: number,
    renderer: 'pixi' | 'webgl',
): number => {
    const safe = Number.isFinite(requested) && requested > 0 ? requested : 1;
    if (!isHalcyonMobileGpu()) return safe;
    const cssSide = Math.max(1, width || 1, height || 1);
    const rendererCap = renderer === 'pixi' ? 1.25 : 1.5;
    const profileCap = HALCYON_PROFILE === 'battery' ? 1 : rendererCap;
    const axisCap = 1536 / cssSide;
    return Math.max(0.75, Math.min(safe, profileCap, axisCap));
};

// Like the v0.7.21 Android override for Lumiere: keep a phone's selected preset, but run
// the expensive full glow at the existing balanced setting on phone GPUs.
export const resolveHalcyonHanabiQuality = (quality: 'full' | 'balanced' | 'low'): 'full' | 'balanced' | 'low' => (
    isHalcyonMobileGpu() && quality === 'full' ? 'balanced' : quality
);
"""
        if budget_src.count(anchor) != 1:
            fail("Task D phone budget anchor not found exactly once")
        write(budget, budget_src.replace(anchor, addition, 1))
    else:
        print("Task D phone budget helper already applied")

    def taskd_replace(path: Path, text: str, old: str, new: str, label: str) -> str:
        if new in text:
            return text
        if text.count(old) != 1:
            fail("Task D anchor not found exactly once: " + label)
        return text.replace(old, new, 1)

    hanabi_runtime = folia / "src/components/visualizer/hanabi/createHanabiPixiRuntime.ts"
    if hanabi_runtime.exists():
        src = read(hanabi_runtime)
        src = taskd_replace(hanabi_runtime, src,
            "import { resolveLyricPixelRatio } from '../../../utils/lyricRenderQuality';\n",
            "import { resolveLyricPixelRatio } from '../../../utils/lyricRenderQuality';\nimport { resolveHalcyonBasePixelRatio } from '../../../halcyon/budget';\n",
            "Hanabi mobile budget import")
        src = taskd_replace(hanabi_runtime, src,
            "const resolveRenderResolution = (devicePixelRatio: number, scale: LyricRenderScale) => (\n    resolveLyricPixelRatio(resolveHanabiBaseResolution(devicePixelRatio), scale)\n);",
            "const resolveRenderResolution = (width: number, height: number, devicePixelRatio: number, scale: LyricRenderScale) => (\n    resolveLyricPixelRatio(\n        resolveHanabiBaseResolution(resolveHalcyonBasePixelRatio(width, height, devicePixelRatio, 'pixi')),\n        scale,\n    )\n);",
            "Hanabi phone Pixi resolution")
        src = taskd_replace(hanabi_runtime, src,
            "const resolution = resolveRenderResolution(window.devicePixelRatio, options.renderScale);",
            "const resolution = resolveRenderResolution(width, height, window.devicePixelRatio, options.renderScale);",
            "Hanabi initial resolution")
        src = taskd_replace(hanabi_runtime, src,
            "const resolution = resolveRenderResolution(window.devicePixelRatio, this.options.renderScale);",
            "const resolution = resolveRenderResolution(width, height, window.devicePixelRatio, this.options.renderScale);",
            "Hanabi resize resolution")
        write(hanabi_runtime, src)

    hanabi_tuning = folia / "src/components/visualizer/hanabi/hanabiTuning.ts"
    if hanabi_tuning.exists():
        src = read(hanabi_tuning)
        src = taskd_replace(hanabi_tuning, src,
            "import { normalizeLyricRenderOverride } from '../../../utils/lyricRenderQuality';\n",
            "import { normalizeLyricRenderOverride } from '../../../utils/lyricRenderQuality';\nimport { resolveHalcyonHanabiQuality } from '../../../halcyon/budget';\n",
            "Hanabi mobile quality import")
        src = taskd_replace(hanabi_tuning, src,
            "    const { glowScale } = HANABI_QUALITY_PROFILES[quality] ?? HANABI_QUALITY_PROFILES.full;",
            "    const effectiveQuality = resolveHalcyonHanabiQuality(quality);\n    const { glowScale } = HANABI_QUALITY_PROFILES[effectiveQuality] ?? HANABI_QUALITY_PROFILES.full;",
            "Hanabi mobile glow quality")
        write(hanabi_tuning, src)

    hanabi_scene = folia / "src/components/visualizer/hanabi/scene.ts"
    if hanabi_scene.exists():
        src = read(hanabi_scene)
        src = taskd_replace(hanabi_scene, src,
            "import { HANABI_QUALITY_PROFILES, resolveHanabiGlowQuality } from './hanabiTuning';\n",
            "import { HANABI_QUALITY_PROFILES, resolveHanabiGlowQuality } from './hanabiTuning';\nimport { resolveHalcyonHanabiQuality } from '../../../halcyon/budget';\n",
            "Hanabi mobile ambient import")
        src = taskd_replace(hanabi_scene, src,
            "(HANABI_QUALITY_PROFILES[tuning.renderQuality] ?? HANABI_QUALITY_PROFILES.full).ambientScale",
            "(HANABI_QUALITY_PROFILES[resolveHalcyonHanabiQuality(tuning.renderQuality)] ?? HANABI_QUALITY_PROFILES.full).ambientScale",
            "Hanabi mobile ambient quality")
        write(hanabi_scene, src)

    machi_runtime = folia / "src/components/visualizer/machi/createMachiRuntime.ts"
    if machi_runtime.exists():
        src = read(machi_runtime)
        src = taskd_replace(machi_runtime, src,
            "import { resolveThemeFontStack, resolveThemeFontWeight } from '../../../utils/fontStacks';\n",
            "import { resolveThemeFontStack, resolveThemeFontWeight } from '../../../utils/fontStacks';\nimport { resolveHalcyonBasePixelRatio } from '../../../halcyon/budget';\n",
            "Machi mobile budget import")
        src = taskd_replace(machi_runtime, src,
            "            devicePixelRatio: window.devicePixelRatio || 1,",
            "            devicePixelRatio: resolveHalcyonBasePixelRatio(\n                this.options.host.clientWidth, this.options.host.clientHeight, window.devicePixelRatio || 1, 'webgl',\n            ),",
            "Machi mobile renderer resolution")
        write(machi_runtime, src)

    nebbia_runtime = folia / "src/components/visualizer/nebbia/createNebbiaRuntime.ts"
    if nebbia_runtime.exists():
        src = read(nebbia_runtime)
        src = taskd_replace(nebbia_runtime, src,
            "import { resolveLyricPixelRatio } from '../../../utils/lyricRenderQuality';\n",
            "import { resolveLyricPixelRatio } from '../../../utils/lyricRenderQuality';\nimport { resolveHalcyonBasePixelRatio } from '../../../halcyon/budget';\n",
            "Nebbia mobile budget import")
        src = taskd_replace(nebbia_runtime, src,
            "        const dpr = resolveLyricPixelRatio(Math.min(2, window.devicePixelRatio || 1), this.renderScale);",
            "        const baseDpr = resolveHalcyonBasePixelRatio(\n            this.W, this.H, Math.min(2, window.devicePixelRatio || 1), 'webgl',\n        );\n        const dpr = resolveLyricPixelRatio(baseDpr, this.renderScale);",
            "Nebbia mobile framebuffer resolution")
        write(nebbia_runtime, src)

#!/usr/bin/env python3
"""Patches the few existing Halcyon files that must know about the lyric visualizer.

Usage: apply.py <halcyon project root>
Every edit is anchored on exact existing text. If an anchor is missing the script stops with a
clear message instead of silently producing a half-patched app. Re-running is safe.
"""
import re
import sys
from pathlib import Path

root = Path(sys.argv[1]).resolve()
base = root / "app/src/main/java/com/ella/music"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def write(path: Path, text: str) -> None:
    path.write_text(text, encoding="utf-8", newline="\n")


def fail(msg: str) -> None:
    print("PATCH ERROR: " + msg)
    sys.exit(1)


# --------------------------------------------------------------------------- lyric sidecars
utils = base / "data/repository/MusicRepositoryUtils.kt"
src = read(utils)
if "KrcDecoder" not in src:
    old_ext = 'val extensions = if (preferTtml) listOf("ttml") else listOf("lrc", "elrc")\n    val baseName'
    new_ext = 'val extensions = if (preferTtml) listOf("ttml") else listOf("lrc", "elrc", "yrc", "qrc", "krc")\n    val baseName'
    if src.count(old_ext) != 1:
        fail("sidecar extension list not found in MusicRepositoryUtils.kt")
    src = src.replace(old_ext, new_ext)
    old_read = "        if (!file.exists()) return null\n        file.readText()"
    if src.count(old_read) != 1:
        fail("readTextIfExists body not found in MusicRepositoryUtils.kt")
    src = src.replace(old_read, "        if (!file.exists()) return null\n        com.ella.music.data.parser.KrcDecoder.readLyricText(file)")
    write(utils, src)
    print("patched MusicRepositoryUtils.kt (yrc/qrc/krc sidecars, encrypted krc)")
else:
    print("MusicRepositoryUtils.kt already patched")

# --------------------------------------------------------------------------- player overlay
player = base / "ui/player/PlayerScreen.kt"
src = read(player)
if "VisOverlayHost" not in src:
    anchor = re.compile(
        r"(                    \.align\(androidx\.compose\.ui\.Alignment\.BottomCenter\)\s*\n\s*\n\s*\)\n)"
    )
    matches = list(anchor.finditer(src))
    if len(matches) != 1:
        fail("AudioVisualizer anchor not found exactly once in PlayerScreen.kt (found %d)" % len(matches))
    call = """            // Lyric visualizer page (opened from the button on the lyrics page).
            com.ella.music.ui.vis.VisOverlayHost(
                lyrics = lyrics,
                song = song,
                durationMs = duration,
                isPlaying = isPlaying,
                positionProvider = { playerViewModel.livePositionMs() },
                lyricOffsetMs = currentLyricOffsetMs,
                palette = palette,
                paletteBitmap = paletteBitmap,
                embeddedCover = embeddedCover,
                audioSessionId = audioSessionId,
                appFontPath = effectiveLyricFontPath,
                isLandscape = isLandscape,
                lyricsVisible = showLyrics && playerVisible,
                onSeek = { playerViewModel.seekTo(it) },
                onPlayPause = { playerViewModel.togglePlayPause() },
                onPrevious = { playerViewModel.skipToPrevious() },
                onNext = { playerViewModel.skipToNext() },
                playerBackground = { bgModifier ->
                    SharedPlayerPageBackground(
                        song = song,
                        embeddedCover = embeddedCover,
                        paletteBitmap = paletteBitmap,
                        palette = palette,
                        currentPositionMs = currentPosition,
                        isPlaying = isPlaying,
                        playerBackgroundEnabled = playerBackgroundEnabled,
                        playerBackgroundUri = playerBackgroundUri,
                        playerBackgroundOpacity = playerBackgroundOpacity,
                        playerBackgroundDim = playerBackgroundDim,
                        beautifulLyricsBackground = beautifulLyricsBackground,
                        dynamicFlowEnabled = playerDynamicFlowEnabled,
                        useBlurBackground = false,
                        modifier = bgModifier
                    )
                }
            )
"""
    m = matches[0]
    src = src[: m.end()] + call + src[m.end():]
    write(player, src)
    print("patched PlayerScreen.kt (visualizer overlay mounted)")
else:
    print("PlayerScreen.kt already patched")


# --------------------------------------------------------------------------- live audio tap
# The beat detector taps the player's own PCM: a small AudioProcessor is appended to the extra
# processors of both players (primary + crossfade secondary). The tap passes audio through
# untouched and only analyses while the visualizer page is open.
service = base / "player/PlaybackService.kt"
if service.exists():
    src = read(service)
    if "VisAudioTee" not in src:
        old_primary = "        val primaryWaveformProbe = WaveformLevelAudioProcessor()\n"
        old_secondary = "        val secondaryWaveformProbe = WaveformLevelAudioProcessor()\n"
        if src.count(old_primary) != 1 or src.count(old_secondary) != 1:
            fail("waveform probe declarations not found in PlaybackService.kt")
        src = src.replace(old_primary, old_primary + "        val visPrimaryTee = com.ella.music.ui.vis.VisAudioTee()\n")
        src = src.replace(old_secondary, old_secondary + "        val visSecondaryTee = com.ella.music.ui.vis.VisAudioTee()\n")
        old_primary_list = "renderersFactory.setExtraAudioProcessors(listOf(karaokeAccompanimentProcessor, primaryWaveformProbe))"
        old_secondary_list = "setExtraAudioProcessors(listOf(secondaryKaraokeAccompanimentProcessor, secondaryWaveformProbe))"
        if src.count(old_primary_list) != 1 or src.count(old_secondary_list) != 1:
            fail("extra audio processor lists not found in PlaybackService.kt")
        src = src.replace(old_primary_list, "renderersFactory.setExtraAudioProcessors(listOf(karaokeAccompanimentProcessor, primaryWaveformProbe, visPrimaryTee))")
        src = src.replace(old_secondary_list, "setExtraAudioProcessors(listOf(secondaryKaraokeAccompanimentProcessor, secondaryWaveformProbe, visSecondaryTee))")
        write(service, src)
        print("patched PlaybackService.kt (VisAudioTee in both players)")
    else:
        print("PlaybackService.kt already patched")
else:
    print("note: player/PlaybackService.kt not found; the live tap stays off (offline analysis only)")


# --------------------------------------------------------------------------- R8 rules
rules = root / "app/proguard-rules.pro"
if rules.exists():
    text = read(rules)
    marker = "com.ella.music.ui.vis.FoliaBridge"
    if marker not in text:
        text += """

# Lyric visualizer: the Folia WebView page calls these by name.
-keep class com.ella.music.ui.vis.FoliaBridge { *; }
-keepclassmembers class com.ella.music.ui.vis.FoliaBridge {
    @android.webkit.JavascriptInterface <methods>;
}
"""
        write(rules, text)
        print("patched proguard-rules.pro (FoliaBridge)")
    else:
        print("proguard-rules.pro already patched")
else:
    print("note: app/proguard-rules.pro not found, relying on @Keep")


# --------------------------------------------------------------------------- lyrics page button
corner = base / "ui/player/LyricsCornerActions.kt"
src = read(corner)
if "VisController" not in src:
    anchor = """            AppleTranslationIcon(
                color = contentColor,
                active = showTranslation,
                modifier = Modifier.size(36.dp)
            )
        }
"""
    if src.count(anchor) != 1:
        fail("translation icon anchor not found exactly once in LyricsCornerActions.kt")
    button = """        Box(
            modifier = Modifier
                .size(44.dp)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = { com.ella.music.ui.vis.VisController.show() }
                ),
            contentAlignment = Alignment.Center
        ) {
            com.ella.music.ui.vis.VisIcon(
                com.ella.music.ui.vis.VisIconKind.VIS,
                contentColor,
                26.dp
            )
        }
"""
    src = src.replace(anchor, anchor + button)
    write(corner, src)
    print("patched LyricsCornerActions.kt (visualizer button between translation and vocal buttons)")
else:
    print("LyricsCornerActions.kt already patched")


# --------------------------------------------------------------------------- Folia source (optional)
# The Folia sources sit next to the Halcyon project (../folia) when the workflow imported them.
folia = root.parent / "folia"
drum = folia / "src/services/analysis/drumHits.ts"
if drum.exists():
    text = read(drum)
    if "setExternalDrumHits" not in text:
        if "const settled = new Set<string>();" not in text or "const keep = (key: string, hits: DrumHits)" not in text:
            fail("drumHits.ts has changed: cannot add setExternalDrumHits")
        text = text.rstrip("\n") + """

/** Halcyon (the Android host) analyses the drums natively and hands the hits in here. */
export const setExternalDrumHits = (key: string, hits: DrumHits): void => {
    keep(key, hits);
    settled.add(key);
};
"""
        write(drum, text)
        print("patched Folia drumHits.ts (setExternalDrumHits)")
    else:
        print("Folia drumHits.ts already patched")
else:
    print("note: Folia sources not found next to the project; skipping the Folia patch")


# Machi: right-to-left board. Lines in an RTL script are laid out from the right edge, and the lit
# sweep (a shader comparison against the pixel column) runs from the right as well.
machi_layout = folia / "src/components/visualizer/machi/engine/boardLayout.ts"
machi_screen = folia / "src/components/visualizer/machi/engine/lyricScreen.ts"
if machi_layout.exists() and machi_screen.exists():
    def replace_once(text: str, old: str, new: str, label: str) -> str:
        if text.count(old) != 1:
            fail("Machi patch anchor not found exactly once: " + label)
        return text.replace(old, new)

    layout_src = read(machi_layout)
    if "layout.rtl" not in layout_src:
        layout_src = replace_once(
            layout_src,
            "import { buildLineGraphemeTimeline } from '../../../../utils/lyrics/graphemeTiming';\n",
            "import { buildLineGraphemeTimeline } from '../../../../utils/lyrics/graphemeTiming';\nimport { resolveLyricTextDirection } from '../../../../utils/lyrics/textDirection';\n",
            "import")
        layout_src = replace_once(
            layout_src,
            "export interface MachiBoardLayout {\n    fontPx: number;\n    rows: MachiBoardRow[];\n    width: number;\n    height: number;\n}",
            "export interface MachiBoardLayout {\n    fontPx: number;\n    rows: MachiBoardRow[];\n    width: number;\n    height: number;\n    /** Laid out from the right edge and revealed from the right (Arabic, Hebrew). */\n    rtl?: boolean;\n}",
            "interface")
        layout_src = replace_once(
            layout_src,
            "    return placeRows(best.rows, best.fontPx, box, measure);",
            "    const rtl = resolveLyricTextDirection(line.fullText) === 'rtl';\n    return { ...placeRows(best.rows, best.fontPx, box, measure, rtl), rtl };",
            "placeRows call")
        layout_src = replace_once(
            layout_src,
            "const placeRows = (rows: Token[][], fontPx: number, box: MachiBoardBox, measure: MachiMeasure): MachiBoardLayout => {",
            "const placeRows = (rows: Token[][], fontPx: number, box: MachiBoardBox, measure: MachiMeasure, rtl = false): MachiBoardLayout => {",
            "placeRows signature")
        layout_src = replace_once(
            layout_src,
            """            const placed = glyphs.map(glyph => {
                const x0 = left + measure(prefix) * scale;
                prefix += glyph.text;
                const x1 = left + measure(prefix) * scale;
                return { ...glyph, length: glyph.text.length, x0, x1 };
            });""",
            """            const right = left + width;
            const placed = glyphs.map(glyph => {
                const before = measure(prefix) * scale;
                prefix += glyph.text;
                const after = measure(prefix) * scale;
                const x0 = rtl ? right - after : left + before;
                const x1 = rtl ? right - before : left + after;
                return { ...glyph, length: glyph.text.length, x0, x1 };
            });""",
            "glyph placement")
        layout_src = replace_once(
            layout_src,
            """export const resolveMachiBoardReveal = (layout: MachiBoardLayout, time: number): number[] => layout.rows.map(row => {
    let lit = row.glyphs[0]?.x0 ?? 0;""",
            """export const resolveMachiBoardReveal = (layout: MachiBoardLayout, time: number): number[] => layout.rows.map(row => {
    if (layout.rtl) {
        // Mirrored coordinates: the distance of the lit edge from the right edge of the board.
        let mirrored = layout.width - (row.glyphs[0]?.x1 ?? 0);
        for (const glyph of row.glyphs) {
            if (time >= glyph.endTime) {
                mirrored = layout.width - glyph.x0;
                continue;
            }
            if (time > glyph.startTime) {
                const span = Math.max(1e-3, glyph.endTime - glyph.startTime);
                mirrored = layout.width - glyph.x1 + (glyph.x1 - glyph.x0) * Math.min(1, (time - glyph.startTime) / span);
            }
            break;
        }
        return mirrored;
    }
    let lit = row.glyphs[0]?.x0 ?? 0;""",
            "reveal")
        write(machi_layout, layout_src)

    screen_src = read(machi_screen)
    if "uRtl" not in screen_src:
        screen_src = replace_once(screen_src, "uniform float uSoft;\n", "uniform float uSoft;\nuniform float uRtl;\n", "uniform declaration")
        screen_src = replace_once(
            screen_src,
            "    float snapped = (floor(vUv.x * uCells.x) + 0.5) / uCells.x;\n    float on = 1.0 - smoothstep(reveal - uSoft, reveal + uSoft, mix(vUv.x, snapped, grid));",
            "    float ux = mix(vUv.x, 1.0 - vUv.x, uRtl);\n    float snapped = (floor(ux * uCells.x) + 0.5) / uCells.x;\n    float on = 1.0 - smoothstep(reveal - uSoft, reveal + uSoft, mix(ux, snapped, grid));",
            "shader reveal")
        screen_src = replace_once(screen_src, "                uSoft: { value: 0.004 },\n", "                uSoft: { value: 0.004 },\n                uRtl: { value: 0 },\n", "uniform value")
        screen_src = replace_once(
            screen_src,
            "            (reveal[2] ?? 0) / this.box.width,\n        );\n",
            "            (reveal[2] ?? 0) / this.box.width,\n        );\n        this.material.uniforms.uRtl!.value = layout && layout.rtl ? 1 : 0;\n",
            "uniform update")
        write(machi_screen, screen_src)
    print("patched Folia Machi (right-to-left board)")


# --------------------------------------------------------------------------- Task C: real RTL in every style
# The four RTL-ready styles (classic, partita, monet, diorama) branch on Folia's own
# resolveLyricTextDirection; Machi's board is mirrored above. These patches give the remaining
# twelve styles the same treatment in their own layout code: x positions (and the sweep) mirrored
# per row, lyric data kept in logical order with ascending times. Latin lines are untouched — every
# mirror is gated on resolveLyricTextDirection(line text) === 'rtl'. The arabic.ts mode table in
# folia-host feeds each style either 'native' (whole words/runs the browser or canvas shapes) or
# 'shaped-logical' (one glyph drawn at a time: pre-shaped Presentation Forms, logical order).

def patch_folia(rel, edits, marker, label):
    path = folia / rel
    if not path.exists():
        print("note: %s not found; %s skipped" % (rel, label))
        return
    text = read(path)
    if marker in text:
        print("%s already patched" % label)
        return
    for old, new, name in edits:
        if text.count(old) != 1:
            fail("%s: anchor not found exactly once: %s" % (label, name))
        text = text.replace(old, new)
    write(path, text)
    print("patched Folia %s" % label)


RTL_DIR_IMPORT = "import { resolveLyricTextDirection } from '../../../utils/lyrics/textDirection';\n"
RTL_DIR_IMPORT_DEEP = "import { resolveLyricTextDirection } from '../../../../utils/lyrics/textDirection';\n"

# still: the browser lays whole lines out; it only needs the direction set on the line box.
patch_folia(
    "src/components/visualizer/still/VisualizerStill.tsx",
    [
        ("import { resolveThemeFontStack, resolveThemeFontWeight, resolveThemeTranslationFontStack } from '../../../utils/fontStacks';\n",
         "import { resolveThemeFontStack, resolveThemeFontWeight, resolveThemeTranslationFontStack } from '../../../utils/fontStacks';\n" + RTL_DIR_IMPORT,
         "import"),
        ("""                                    <div
                                        className={`drop-shadow-md text-center tracking-[0.02em] ${isCurrent ? 'text-[2.5rem] opacity-100 leading-tight' : 'text-3xl opacity-30'}`}""",
         """                                    <div
                                        dir={resolveLyricTextDirection(line.fullText)}
                                        className={`drop-shadow-md text-center tracking-[0.02em] ${isCurrent ? 'text-[2.5rem] opacity-100 leading-tight' : 'text-3xl opacity-30'}`}""",
         "line dir"),
    ],
    "resolveLyricTextDirection",
    "still (RTL direction on the line box)",
)

# tilt: per-letter inline-block spans (the char-scale bounce needs them), so joining is baked in by
# shaped letters; the row container gets dir=rtl, which flows the spans right to left and makes the
# existing stagger delay (ascending logical index) reveal from the right.
patch_folia(
    "src/components/visualizer/tilt/VisualizerTilt.tsx",
    [
        ("import { type VisualizerSharedProps } from '../definition';\n",
         "import { type VisualizerSharedProps } from '../definition';\n" + RTL_DIR_IMPORT,
         "import"),
        ("""            <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={visible ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
                exit={{ opacity: 0, y: -12 }}
                transition={{ duration: 0.55, ease: [0.25, 0.46, 0.45, 0.94] }}
                className="whitespace-nowrap\"""",
         """            <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={visible ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
                exit={{ opacity: 0, y: -12 }}
                transition={{ duration: 0.55, ease: [0.25, 0.46, 0.45, 0.94] }}
                dir={resolveLyricTextDirection(segment.text)}
                className="whitespace-nowrap\"""",
         "normal row dir"),
        ("""        <motion.div
            initial={{ opacity: 0, y: 24, scale: 0.92 }}
            animate={visible ? { opacity: 1, y: 0, scale: 1 } : { opacity: 0, y: 24, scale: 0.92 }}
            exit={{ opacity: 0, y: -16, scale: 0.95 }}
            transition={{ duration: 0.6, ease: [0.25, 0.46, 0.45, 0.94] }}
            className="whitespace-nowrap\"""",
         """        <motion.div
            initial={{ opacity: 0, y: 24, scale: 0.92 }}
            animate={visible ? { opacity: 1, y: 0, scale: 1 } : { opacity: 0, y: 24, scale: 0.92 }}
            exit={{ opacity: 0, y: -16, scale: 0.95 }}
            transition={{ duration: 0.6, ease: [0.25, 0.46, 0.45, 0.94] }}
            dir={resolveLyricTextDirection(segment.text)}
            className="whitespace-nowrap\"""",
         "tilt row dir"),
    ],
    "resolveLyricTextDirection",
    "tilt (RTL row direction, both variants)",
)

# cappella: chat bubbles reveal by prefix count in inline flow; dir=auto puts the first (rightmost)
# letters at the right edge, which makes the existing count reveal sweep right to left. Per-char
# fade spans carry shaped letters, so joining survives.
patch_folia(
    "src/components/visualizer/cappella/CappellaMessageRow.tsx",
    [
        ('<span className="relative z-10">',
         '<span className="relative z-10" dir="auto">',
         "bubble text span"),
    ],
    '<span className="relative z-10" dir="auto">',
    "cappella (RTL bubble text)",
)

# pendolo: the lit fill is a CSS mask gradient that grows from the left; RTL grows it from the
# right (270deg) while the text box runs right to left. Prefix widths keep their meaning: they are
# distances of the logical prefix, which in RTL is measured from the right edge.
patch_folia(
    "src/components/visualizer/pendolo/PendoloActiveLyricSweep.tsx",
    [
        ("import { buildPendoloColorRuns, type PendoloColorRun } from './pendoloColorRuns';\n",
         "import { buildPendoloColorRuns, type PendoloColorRun } from './pendoloColorRuns';\n" + RTL_DIR_IMPORT,
         "import"),
        ("""interface PendoloSweepLineProps {
    layoutLine: PendoloWrappedTextLine;""",
         """interface PendoloSweepLineProps {
    layoutLine: PendoloWrappedTextLine;
    rtl?: boolean;""",
         "props"),
        ("""const PendoloSweepLine: React.FC<PendoloSweepLineProps> = ({
    layoutLine,
    timings,""",
         """const PendoloSweepLine: React.FC<PendoloSweepLineProps> = ({
    layoutLine,
    rtl = false,
    timings,""",
         "destructure"),
        ("""        return `linear-gradient(90deg, #000 0px, #000 ${Math.max(paddedFillWidth - edgeSoftness, 0)}px, rgba(0, 0, 0, 0.84) ${paddedFillWidth}px, transparent ${paddedFillWidth + edgeSoftness}px)`;""",
         """        return `linear-gradient(${rtl ? 270 : 90}deg, #000 0px, #000 ${Math.max(paddedFillWidth - edgeSoftness, 0)}px, rgba(0, 0, 0, 0.84) ${paddedFillWidth}px, transparent ${paddedFillWidth + edgeSoftness}px)`;""",
         "mask direction"),
        ("""        <span className="relative block whitespace-pre overflow-visible" style={{ width: `${layoutLine.width}px`, height: `${lineHeight}px` }}>""",
         """        <span dir={rtl ? 'rtl' : 'ltr'} className="relative block whitespace-pre overflow-visible" style={{ width: `${layoutLine.width}px`, height: `${lineHeight}px` }}>""",
         "row dir"),
        ("""                <PendoloSweepLine
                    key={`${layoutLine.graphemeStart}-${layoutLine.graphemeEnd}`}
                    layoutLine={layoutLine}""",
         """                <PendoloSweepLine
                    key={`${layoutLine.graphemeStart}-${layoutLine.graphemeEnd}`}
                    layoutLine={layoutLine}
                    rtl={resolveLyricTextDirection(layoutLine.text) === 'rtl'}""",
         "prop pass"),
    ],
    "resolveLyricTextDirection",
    "pendolo (RTL sweep direction)",
)

# claddagh: glyph centres walk an arc by ascending angle; mirroring nominalAngle puts the first
# letter at the largest angle (rightmost) and the read head follows leftward. Everything
# downstream (interpolation, ring placement) is angle-agnostic.
patch_folia(
    "src/components/visualizer/claddagh/claddaghLayout.ts",
    [
        ("import { measurePrefixOffsets, rememberBounded } from '../textMeasureCache';\n",
         "import { measurePrefixOffsets, rememberBounded } from '../textMeasureCache';\n" + RTL_DIR_IMPORT,
         "import"),
        ("""    const graphemes = items.map(item => item.char);
    const offsets = measureCladdaghGraphemeOffsets(graphemes, fontSpec, fontPx, letterSpacingOffsetPx);""",
         """    const graphemes = items.map(item => item.char);
    const lineRtl = resolveLyricTextDirection(graphemes.join('')) === 'rtl';
    const offsets = measureCladdaghGraphemeOffsets(graphemes, fontSpec, fontPx, letterSpacingOffsetPx);""",
         "rtl detect"),
        ("""            nominalAngle: (startAngle - totalSpan / 2) * scaleFactor,""",
         """            nominalAngle: (lineRtl ? totalSpan / 2 - startAngle : startAngle - totalSpan / 2) * scaleFactor,""",
         "angle mirror"),
    ],
    "resolveLyricTextDirection",
    "claddagh (mirrored arc)",
)

# cadenza: word nodes keep whole words (the browser shapes them); only the fragment x position
# needs mirroring — the emphasis scatter positions are decorative and order-free.
patch_folia(
    "src/components/visualizer/cadenza/cadenzaPlacements.ts",
    [
        ("import { clamp, isCJK, splitGraphemes } from './cadenzaEnvelopes';\n",
         "import { clamp, isCJK, splitGraphemes } from './cadenzaEnvelopes';\n" + RTL_DIR_IMPORT,
         "import"),
        ("""    const placementPlans = lineData.flatMap((lineView, lineIndex) => {
        const lineLeft = -lineView.line.width / 2;
        const baselineY = -totalHeight / 2 + fontPx + lineIndex * lineHeight;""",
         """    const placementPlans = lineData.flatMap((lineView, lineIndex) => {
        const lineLeft = -lineView.line.width / 2;
        const lineRtl = resolveLyricTextDirection(lineView.fragments.map(fragment => fragment.text).join('')) === 'rtl';
        const baselineY = -totalHeight / 2 + fontPx + lineIndex * lineHeight;""",
         "rtl detect"),
        ("""                baseX: lineLeft + fragment.startX,""",
         """                baseX: lineRtl ? -(lineLeft + fragment.startX) - width : lineLeft + fragment.startX,""",
         "baseX mirror"),
    ],
    "resolveLyricTextDirection",
    "cadenza (mirrored fragment x)",
)

# fume: the newspaper canvas. The static snapshot draws whole lines (canvas bidi shapes them) and
# only needs right alignment; the live layer draws color runs at prefix offsets and reveals by a
# printed-prefix count, so run x, the clip window and the printed/frontier logic are mirrored.
patch_folia(
    "src/components/visualizer/fume/fumeCanvasText.ts",
    [
        ("import { resolvePrintedGraphemeCount, resolveVisualProgressWithCutoff } from './fumeReveal';\n",
         "import { resolvePrintedGraphemeCount, resolveVisualProgressWithCutoff } from './fumeReveal';\n" + RTL_DIR_IMPORT,
         "import"),
        ("""    const baselineOffset = block.lineHeight * (isCJK(block.line.fullText) ? 0.52 : 0.5);
    context.setTransform(rasterScale, 0, 0, rasterScale, 0, 0);
    context.font = buildCanvasFont(block, theme);
    context.textAlign = 'left';""",
         """    const baselineOffset = block.lineHeight * (isCJK(block.line.fullText) ? 0.52 : 0.5);
    const snapshotRtl = resolveLyricTextDirection(block.line.fullText) === 'rtl';
    context.setTransform(rasterScale, 0, 0, rasterScale, 0, 0);
    context.font = buildCanvasFont(block, theme);
    context.textAlign = snapshotRtl ? 'right' : 'left';""",
         "snapshot align"),
        ("""    for (const renderLine of block.renderLines) {
        context.fillText(
            renderLine.text,
            renderLine.left + padding,
            renderLine.top + baselineOffset + padding,
        );
    }""",
         """    for (const renderLine of block.renderLines) {
        context.fillText(
            renderLine.text,
            snapshotRtl ? renderLine.left + padding + renderLine.width : renderLine.left + padding,
            renderLine.top + baselineOffset + padding,
        );
    }""",
         "snapshot x"),
        ("""    const totalGraphemeCount = block.graphemes.length;

    context.save();
    context.font = buildCanvasFont(block, theme);""",
         """    const totalGraphemeCount = block.graphemes.length;
    const lineRtl = resolveLyricTextDirection(block.line.fullText) === 'rtl';

    context.save();
    context.font = buildCanvasFont(block, theme);""",
         "live rtl"),
        ("""                fillGlowText(context, segment.text, glowBaseX + segment.x, glowBaseY);""",
         """                fillGlowText(
                    context,
                    segment.text,
                    lineRtl ? glowBaseX + renderLine.width - segment.x - segment.width : glowBaseX + segment.x,
                    glowBaseY,
                );""",
         "glow x"),
        ("""                drawRenderTextRun(
                    context,
                    renderLine,
                    segment,
                    localStart,
                    localEnd,
                    baseX,
                    baseY,
                );""",
         """                drawRenderTextRun(
                    context,
                    renderLine,
                    segment,
                    localStart,
                    localEnd,
                    lineRtl ? baseX + renderLine.width - segment.x - segment.width : baseX,
                    baseY,
                    lineRtl,
                );""",
         "run call"),
        ("""                const isPrinted = hasRevealCompleted || globalOffset < printedCount;
                const isFrontier = printedCount > 0
                    && globalOffset === printedCount""",
         """                const isPrinted = hasRevealCompleted
                    || (lineRtl ? globalOffset >= totalGraphemeCount - printedCount : globalOffset < printedCount);
                const isFrontier = printedCount > 0
                    && globalOffset === (lineRtl ? totalGraphemeCount - printedCount - 1 : printedCount)""",
         "printed logic"),
        ("""export const drawRenderTextRun = (
    context: CanvasRenderingContext2D,
    renderLine: RenderLineSlice,
    segment: RenderSegmentSlice,
    runStart: number,
    runEnd: number,
    baseX: number,
    baseY: number,
) => {""",
         """export const drawRenderTextRun = (
    context: CanvasRenderingContext2D,
    renderLine: RenderLineSlice,
    segment: RenderSegmentSlice,
    runStart: number,
    runEnd: number,
    baseX: number,
    baseY: number,
    rtl = false,
) => {""",
         "run signature"),
        ("""    context.save();
    context.beginPath();
    context.rect(
        baseX + segment.x + clipLeft,
        baseY - Math.max(clipWidth, 1) - 64,
        clipWidth,
        Math.max(128 + clipWidth * 2, 256),
    );
    context.clip();
    context.fillText(segment.text, baseX + segment.x, baseY);
    context.restore();""",
         """    context.save();
    context.beginPath();
    context.rect(
        rtl
            ? baseX + segment.width - clipRight
            : baseX + segment.x + clipLeft,
        baseY - Math.max(clipWidth, 1) - 64,
        clipWidth,
        Math.max(128 + clipWidth * 2, 256),
    );
    context.clip();
    context.fillText(segment.text, baseX, baseY);
    context.restore();""",
         "run clip"),
    ],
    "resolveLyricTextDirection",
    "fume (RTL article canvas)",
)

# hanabi: glyphs are placed by a pure layout function; mirroring the final x of each row's glyphs
# about the line centre flips the reading direction (left-aligned rows become right-aligned,
# stagger and diagonal mirror with them). The karaoke tint is per-glyph by time, so it follows.
patch_folia(
    "src/components/visualizer/hanabi/text/layout.ts",
    [
        ("import { createRng } from '../hanabiRandom';\n",
         "import { createRng } from '../hanabiRandom';\n",
         "import keep"),
        ("""export interface LayoutParams {
    layout: TextLayout;""",
         """export interface LayoutParams {
    layout: TextLayout;
    /** Mirrored horizontally: the first glyph of a row sits rightmost (Arabic, Hebrew). */
    rtl?: boolean;""",
         "params"),
        ("""                flow(run, rowIndex, (glyph, s, n) => {
                    if (layout === 'diagonal') {
                        const x = x0 + s;
                        placeStraight(glyph, x, rowY + n + (x - (x0 + L / 2)) * Math.tan(slope), rowIndex);
                        const w = work[glyph]!;
                        // 字直立、水平间距不变，沿斜线的长度要除以 cos。
                        w.advance /= Math.cos(slope);
                        w.angle = slope;
                        w.rotation = slope * 0.3;
                    } else placeStraight(glyph, x0 + s, rowY + n, rowIndex);
                });""",
         """                flow(run, rowIndex, (glyph, s, n) => {
                    // An RTL row mirrors its glyphs about the line centre; the diagonal's tilt
                    // line mirrors with them (opposite slope around the mirrored centre).
                    const xs = params.rtl ? -(x0 + s) : x0 + s;
                    const xc = params.rtl ? -(x0 + L / 2) : x0 + L / 2;
                    if (layout === 'diagonal') {
                        const x = xs;
                        placeStraight(glyph, x, rowY + n + (x - xc) * Math.tan(params.rtl ? -slope : slope), rowIndex);
                        const w = work[glyph]!;
                        // 字直立、水平间距不变，沿斜线的长度要除以 cos。
                        w.advance /= Math.cos(slope);
                        w.angle = slope;
                        w.rotation = (params.rtl ? -1 : 1) * slope * 0.3;
                    } else placeStraight(glyph, xs, rowY + n, rowIndex);
                });""",
         "glyph mirror"),
    ],
    "params.rtl ? -(x0 + s)",
    "hanabi (mirrored glyph layout)",
)

# The caller supplies the flag from the line's direction.
patch_folia(
    "src/components/visualizer/hanabi/text/lyricText.ts",
    [
        ("import { hanabiBackdropOf, resolveHanabiGlyphColors } from '../color';\n",
         "import { hanabiBackdropOf, resolveHanabiGlyphColors } from '../color';\n" + RTL_DIR_IMPORT_DEEP,
         "import"),
        ("""    const placement = layoutText(inputs, words, {
        layout: spec.layout,""",
         """    const placement = layoutText(inputs, words, {
        rtl: resolveLyricTextDirection(line.fullText) === 'rtl',
        layout: spec.layout,""",
         "flag pass"),
    ],
    "resolveLyricTextDirection(line.fullText)",
    "hanabi (RTL flag from the line)",
)

# lumiere: glyph centres come from per-word prefix offsets relative to the row start; one mirror
# at the point where the offset becomes an x flips every row (the chasing light uses the same x).
patch_folia(
    "src/components/visualizer/lumiere/text/lineWrap.ts",
    [
        ("import { glyphFont } from './glyphLine';\n",
         "import { glyphFont } from './glyphLine';\n" + RTL_DIR_IMPORT_DEEP,
         "import"),
        ("""        const { row, offset, lengths } = breakLines(measurer, glyphs, pieces, advances, heroPx, lines);""",
         """        const { row, offset, lengths } = breakLines(measurer, glyphs, pieces, advances, heroPx, lines);
        const lineRtl = resolveLyricTextDirection(glyphs.map(glyph => glyph.char).join('')) === 'rtl';""",
         "rtl detect"),
        ("""            if (orient === 0) {
                const x = offset[index]! - lengths[r]! / 2;""",
         """            if (orient === 0) {
                const x = (lineRtl ? -1 : 1) * (offset[index]! - lengths[r]! / 2);""",
         "x mirror"),
    ],
    "resolveLyricTextDirection",
    "lumiere (mirrored glyph x)",
)

# nebbia: handwritten strokes are placed per block; the block emits its glyphs from the left edge,
# and the composition walks blocks left to right. Both mirror for RTL (rows compositions only —
# the decorative cross/pillar/orbit layouts keep their arrangement).
patch_folia(
    "src/components/visualizer/nebbia/nebbiaBlocks.ts",
    [
        ("""export const emitBlock = (m: Measured, cx: number, cy: number, out: PlacedItem[]) => {
    for (const it of m.items) {
        if (m.dir === 'h') out.push({ k: it.k, x: cx - m.w / 2 + it.off, y: cy + m.h / 2 - it.s / 2, s: it.s, rot: 0 });""",
         """export const emitBlock = (m: Measured, cx: number, cy: number, out: PlacedItem[], rtl = false) => {
    for (const it of m.items) {
        if (m.dir === 'h') out.push({ k: it.k, x: cx + (rtl ? m.w / 2 - it.off : -m.w / 2 + it.off), y: cy + m.h / 2 - it.s / 2, s: it.s, rot: 0 });""",
         "emit mirror"),
    ],
    "rtl ? m.w / 2 - it.off",
    "nebbia (mirrored block emit)",
)

patch_folia(
    "src/components/visualizer/nebbia/nebbiaCompositions.ts",
    [
        ("import type { NebbiaChar } from './nebbiaChars';\n",
         "import type { NebbiaChar } from './nebbiaChars';\n" + RTL_DIR_IMPORT,
         "import"),
        ("""const flowRows = (ctx: CompositionContext, rows: number[][], shifts: number[]): CompositionResult => {
    const out: PlacedItem[] = [];""",
         """const flowRows = (ctx: CompositionContext, rows: number[][], shifts: number[]): CompositionResult => {
    const rtl = resolveLyricTextDirection(ctx.chars.map(char => char.ch).join('')) === 'rtl';
    const out: PlacedItem[] = [];""",
         "rtl detect"),
        ("""        let x = -rowW[ri] / 2 + shifts[ri] * widest;
        ms.forEach(m => { emitBlock(m, x + m.w / 2, y + rh - m.h / 2, out); x += m.w + FLOW_GAP; });""",
         """        let x = rtl ? rowW[ri] / 2 - shifts[ri] * widest : -rowW[ri] / 2 + shifts[ri] * widest;
        ms.forEach(m => { emitBlock(m, rtl ? x - m.w / 2 : x + m.w / 2, y + rh - m.h / 2, out, rtl); x += (rtl ? -1 : 1) * (m.w + FLOW_GAP); });""",
         "row cursor mirror"),
    ],
    "resolveLyricTextDirection",
    "nebbia (RTL row compositions)",
)

# sonnet: four touch points — the segment carries the line's direction, the per-segment glyph
# cursor mirrors, the shot flow boxes mirror after layout, and the poster/flow paths inherit both.
patch_folia(
    "src/components/visualizer/sonnet/types.ts",
    [
        ("""export interface SonnetSemanticSegment {
    text: string;""",
         """export interface SonnetSemanticSegment {
    text: string;
    /** The line reads right to left (Arabic, Hebrew): layouts mirror positions and sweeps. */
    rtl?: boolean;""",
         "segment field"),
    ],
    "rtl?: boolean",
    "sonnet (segment rtl field)",
)

patch_folia(
    "src/components/visualizer/sonnet/sonnetSemantic.ts",
    [
        ("import { segmentLyricWords } from '../../../utils/lyrics/wordSegmentation';\n",
         "import { segmentLyricWords } from '../../../utils/lyrics/wordSegmentation';\n" + RTL_DIR_IMPORT,
         "import"),
        ("""        return {
            text: line.fullText.slice(startOffset, endOffset),
            startOffset,
            endOffset,
            ...timingForRange(line, startOffset, endOffset, timeline, ranges),
            isWordLike: part.isWordLike,
        };""",
         """        return {
            text: line.fullText.slice(startOffset, endOffset),
            startOffset,
            endOffset,
            ...timingForRange(line, startOffset, endOffset, timeline, ranges),
            isWordLike: part.isWordLike,
            rtl: resolveLyricTextDirection(line.fullText) === 'rtl',
        };""",
         "segment rtl"),
    ],
    "resolveLyricTextDirection",
    "sonnet (segment direction)",
)

patch_folia(
    "src/components/visualizer/sonnet/sonnetGlyphLayout.ts",
    [
        ("import type { GraphemeTiming } from '../../../utils/lyrics/graphemeTiming';\n",
         "import type { GraphemeTiming } from '../../../utils/lyrics/graphemeTiming';\n",
         "import keep"),
        ("""    let cursor = -totalAdvance / 2;
    return graphemes.map((grapheme, index) => {
        const advance = advances[index];
        const localX = placement.vertical ? 0 : cursor + advance / 2;""",
         """    let cursor = -totalAdvance / 2;
    const segmentRtl = segment.rtl === true && !placement.vertical;
    return graphemes.map((grapheme, index) => {
        const advance = advances[index];
        const localX = placement.vertical ? 0 : (segmentRtl ? -1 : 1) * (cursor + advance / 2);""",
         "glyph cursor mirror"),
    ],
    "segmentRtl",
    "sonnet (mirrored glyph cursor)",
)

patch_folia(
    "src/components/visualizer/sonnet/sonnetTypographyLayout.ts",
    [
        ("""        heroBox.enterX = 0;
        heroBox.enterY = height * 0.15;""",
         """        heroBox.enterX = 0;
        heroBox.enterY = height * 0.15;

        // An RTL shot mirrors every word box about the centre after its flow layout ran; entrance
        // vectors flip with the positions so words still fly in from their reading side.
        if (segments.some(segment => segment.rtl)) {
            for (const box of boxes) {
                box.x = -box.x;
                box.enterX = -box.enterX;
            }
        }""",
         "flow mirror"),
    ],
    "segments.some(segment => segment.rtl)",
    "sonnet (mirrored shot boxes)",
)

# tempera: word units flow left to right per row and glyph offsets accumulate within the word;
# one mirror of the final glyph point flips word order and letter order together (the row drift
# and rotations were applied before the mirror and keep their look).
patch_folia(
    "src/components/visualizer/tempera/temperaLayout.ts",
    [
        ("import { resolveTemperaShotProfile } from './temperaShotProfiles';\n",
         "import { resolveTemperaShotProfile } from './temperaShotProfiles';\n" + RTL_DIR_IMPORT,
         "import"),
        ("""    const region = resolveRegion(shotKind, width, height);
    const ctx = createTemperaMeasureContext(fontFamily, fontWeight);""",
         """    const region = resolveRegion(shotKind, width, height);
    const linesRtl = resolveLyricTextDirection(lines.flatMap(line => line.map(segment => segment.text)).join(' ')) === 'rtl';
    const ctx = createTemperaMeasureContext(fontFamily, fontWeight);""",
         "rtl detect"),
        ("""                placements.push({
                    char: glyph.char,
                    lineIndex: word.lineIndex,
                    segmentIndex: word.segmentIndex,
                    x: finalPoint.x,""",
         """                placements.push({
                    char: glyph.char,
                    lineIndex: word.lineIndex,
                    segmentIndex: word.segmentIndex,
                    x: linesRtl ? 2 * region.centerX - finalPoint.x : finalPoint.x,""",
         "placement mirror"),
    ],
    "resolveLyricTextDirection",
    "tempera (mirrored placements)",
)

# The shared bottom subtitle overlay (used by nine styles) renders plain text rows without a
# direction: an Arabic-first row inherits the page's ltr base and mixed Arabic/Latin lines order
# their runs wrong. dir="auto" applies the first-strong rule per row; pure-Latin rows are unchanged.
patch_folia(
    "src/components/visualizer/VisualizerSubtitleOverlay.tsx",
    [
        ("""                                    return (
                                        <div
                                            key={row.key}
                                            data-font-debug-target="visualizer-translation"
                                            data-subtitle-track={row.source}""",
         """                                    return (
                                        <div
                                            key={row.key}
                                            dir="auto"
                                            data-font-debug-target="visualizer-translation"
                                            data-subtitle-track={row.source}""",
         "row dir"),
    ],
    'dir="auto"',
    "the shared subtitle overlay (per-row direction)",
)

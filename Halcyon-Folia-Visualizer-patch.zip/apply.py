#!/usr/bin/env python3
"""Patches the few existing Halcyon files that must know about the lyric visualizer.

Usage: apply.py <halcyon project root>
Every edit is anchored on exact existing text. If an anchor is missing the script stops with a
clear message instead of silently producing a half-patched app. Re-running is safe.
"""
import re
import sys
from pathlib import Path

root = Path(sys.argv[1]).resolve()
base = root / "app/src/main/java/com/ella/music"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def write(path: Path, text: str) -> None:
    path.write_text(text, encoding="utf-8", newline="\n")


def fail(msg: str) -> None:
    print("PATCH ERROR: " + msg)
    sys.exit(1)


# --------------------------------------------------------------------------- lyric sidecars
utils = base / "data/repository/MusicRepositoryUtils.kt"
src = read(utils)
if "KrcDecoder" not in src:
    old_ext = 'val extensions = if (preferTtml) listOf("ttml") else listOf("lrc", "elrc")\n    val baseName'
    new_ext = 'val extensions = if (preferTtml) listOf("ttml") else listOf("lrc", "elrc", "yrc", "qrc", "krc")\n    val baseName'
    if src.count(old_ext) != 1:
        fail("sidecar extension list not found in MusicRepositoryUtils.kt")
    src = src.replace(old_ext, new_ext)
    old_read = "        if (!file.exists()) return null\n        file.readText()"
    if src.count(old_read) != 1:
        fail("readTextIfExists body not found in MusicRepositoryUtils.kt")
    src = src.replace(old_read, "        if (!file.exists()) return null\n        com.ella.music.data.parser.KrcDecoder.readLyricText(file)")
    write(utils, src)
    print("patched MusicRepositoryUtils.kt (yrc/qrc/krc sidecars, encrypted krc)")
else:
    print("MusicRepositoryUtils.kt already patched")

# --------------------------------------------------------------------------- player overlay
player = base / "ui/player/PlayerScreen.kt"
src = read(player)
if "VisOverlayHost" not in src:
    anchor = re.compile(
        r"(                    \.align\(androidx\.compose\.ui\.Alignment\.BottomCenter\)\s*\n\s*\n\s*\)\n)"
    )
    matches = list(anchor.finditer(src))
    if len(matches) != 1:
        fail("AudioVisualizer anchor not found exactly once in PlayerScreen.kt (found %d)" % len(matches))
    call = """            // Lyric visualizer page (opened from the button on the lyrics page).
            com.ella.music.ui.vis.VisOverlayHost(
                lyrics = lyrics,
                song = song,
                durationMs = duration,
                isPlaying = isPlaying,
                positionProvider = { playerViewModel.livePositionMs() },
                lyricOffsetMs = currentLyricOffsetMs,
                palette = palette,
                paletteBitmap = paletteBitmap,
                embeddedCover = embeddedCover,
                audioSessionId = audioSessionId,
                appFontPath = effectiveLyricFontPath,
                isLandscape = isLandscape,
                lyricsVisible = showLyrics && playerVisible,
                onSeek = { playerViewModel.seekTo(it) },
                onPlayPause = { playerViewModel.togglePlayPause() },
                onPrevious = { playerViewModel.skipToPrevious() },
                onNext = { playerViewModel.skipToNext() },
                playerBackground = { bgModifier ->
                    SharedPlayerPageBackground(
                        song = song,
                        embeddedCover = embeddedCover,
                        paletteBitmap = paletteBitmap,
                        palette = palette,
                        currentPositionMs = currentPosition,
                        isPlaying = isPlaying,
                        playerBackgroundEnabled = playerBackgroundEnabled,
                        playerBackgroundUri = playerBackgroundUri,
                        playerBackgroundOpacity = playerBackgroundOpacity,
                        playerBackgroundDim = playerBackgroundDim,
                        beautifulLyricsBackground = beautifulLyricsBackground,
                        dynamicFlowEnabled = playerDynamicFlowEnabled,
                        useBlurBackground = false,
                        modifier = bgModifier
                    )
                }
            )
"""
    m = matches[0]
    src = src[: m.end()] + call + src[m.end():]
    write(player, src)
    print("patched PlayerScreen.kt (visualizer overlay mounted)")
else:
    print("PlayerScreen.kt already patched")


# --------------------------------------------------------------------------- R8 rules
rules = root / "app/proguard-rules.pro"
if rules.exists():
    text = read(rules)
    marker = "com.ella.music.ui.vis.FoliaBridge"
    if marker not in text:
        text += """

# Lyric visualizer: the Folia WebView page calls these by name.
-keep class com.ella.music.ui.vis.FoliaBridge { *; }
-keepclassmembers class com.ella.music.ui.vis.FoliaBridge {
    @android.webkit.JavascriptInterface <methods>;
}
"""
        write(rules, text)
        print("patched proguard-rules.pro (FoliaBridge)")
    else:
        print("proguard-rules.pro already patched")
else:
    print("note: app/proguard-rules.pro not found, relying on @Keep")


# --------------------------------------------------------------------------- lyrics page button
corner = base / "ui/player/LyricsCornerActions.kt"
src = read(corner)
if "VisController" not in src:
    anchor = """            AppleTranslationIcon(
                color = contentColor,
                active = showTranslation,
                modifier = Modifier.size(36.dp)
            )
        }
"""
    if src.count(anchor) != 1:
        fail("translation icon anchor not found exactly once in LyricsCornerActions.kt")
    button = """        Box(
            modifier = Modifier
                .size(44.dp)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = { com.ella.music.ui.vis.VisController.show() }
                ),
            contentAlignment = Alignment.Center
        ) {
            com.ella.music.ui.vis.VisIcon(
                com.ella.music.ui.vis.VisIconKind.VIS,
                contentColor,
                26.dp
            )
        }
"""
    src = src.replace(anchor, anchor + button)
    write(corner, src)
    print("patched LyricsCornerActions.kt (visualizer button between translation and vocal buttons)")
else:
    print("LyricsCornerActions.kt already patched")


# --------------------------------------------------------------------------- Folia source (optional)
# The Folia sources sit next to the Halcyon project (../folia) when the workflow imported them.
folia = root.parent / "folia"
drum = folia / "src/services/analysis/drumHits.ts"
if drum.exists():
    text = read(drum)
    if "setExternalDrumHits" not in text:
        if "const settled = new Set<string>();" not in text or "const keep = (key: string, hits: DrumHits)" not in text:
            fail("drumHits.ts has changed: cannot add setExternalDrumHits")
        text = text.rstrip("\n") + """

/** Halcyon (the Android host) analyses the drums natively and hands the hits in here. */
export const setExternalDrumHits = (key: string, hits: DrumHits): void => {
    keep(key, hits);
    settled.add(key);
};
"""
        write(drum, text)
        print("patched Folia drumHits.ts (setExternalDrumHits)")
    else:
        print("Folia drumHits.ts already patched")
else:
    print("note: Folia sources not found next to the project; skipping the Folia patch")


# Machi: right-to-left board (anchors match folia-web-min boardLayout / lyricScreen).
machi_layout = folia / "src/components/visualizer/machi/engine/boardLayout.ts"
machi_screen = folia / "src/components/visualizer/machi/engine/lyricScreen.ts"
if machi_layout.exists() and machi_screen.exists():
    def replace_once(text: str, old: str, new: str, label: str) -> str:
        if text.count(old) != 1:
            fail("Machi patch anchor not found exactly once: " + label + " (count=%d)" % text.count(old))
        return text.replace(old, new)

    layout_src = read(machi_layout)
    screen_src = read(machi_screen)
    if "layout.rtl" in layout_src and "uRtl" in screen_src:
        print("Folia Machi already patched")
    else:
        if "layout.rtl" not in layout_src:
            if "resolveLyricTextDirection" not in layout_src:
                layout_src = replace_once(
                    layout_src,
                    "import { buildLineGraphemeTimeline } from '../../../../utils/lyrics/graphemeTiming';\n",
                    "import { buildLineGraphemeTimeline } from '../../../../utils/lyrics/graphemeTiming';\nimport { resolveLyricTextDirection } from '../../../../utils/lyrics/textDirection';\n",
                    "import")
            layout_src = replace_once(
                layout_src,
                "export interface MachiBoardLayout {\n    fontPx: number;\n    rows: MachiBoardRow[];\n    width: number;\n    height: number;\n}",
                "export interface MachiBoardLayout {\n    fontPx: number;\n    rows: MachiBoardRow[];\n    width: number;\n    height: number;\n    /** Laid out from the right edge and revealed from the right (Arabic, Hebrew). */\n    rtl?: boolean;\n}",
                "interface")
            layout_src = replace_once(
                layout_src,
                "    return placeRows(best.rows, best.fontPx, box, measure);\n};",
                "    const rtl = resolveLyricTextDirection(line.fullText) === 'rtl';\n    return { ...placeRows(best.rows, best.fontPx, box, measure, rtl), rtl };\n};",
                "placeRows call")
            layout_src = replace_once(
                layout_src,
                "const placeRows = (rows: Token[][], fontPx: number, box: MachiBoardBox, measure: MachiMeasure): MachiBoardLayout => {",
                "const placeRows = (rows: Token[][], fontPx: number, box: MachiBoardBox, measure: MachiMeasure, rtl = false): MachiBoardLayout => {",
                "placeRows signature")
            layout_src = replace_once(
                layout_src,
                """            const left = (box.width - width) / 2;
            let prefix = '';
            const placed = glyphs.map(glyph => {
                const x0 = left + measure(prefix) * scale;
                prefix += glyph.text;
                const x1 = left + measure(prefix) * scale;
                return { ...glyph, length: glyph.text.length, x0, x1 };
            });""",
                """            const left = (box.width - width) / 2;
            const right = left + width;
            let prefix = '';
            const placed = glyphs.map(glyph => {
                const before = measure(prefix) * scale;
                prefix += glyph.text;
                const after = measure(prefix) * scale;
                const x0 = rtl ? right - after : left + before;
                const x1 = rtl ? right - before : left + after;
                return { ...glyph, length: glyph.text.length, x0, x1 };
            });""",
                "glyph placement")
            layout_src = replace_once(
                layout_src,
                """export const resolveMachiBoardReveal = (layout: MachiBoardLayout, time: number): number[] => layout.rows.map(row => {
    let lit = row.glyphs[0]?.x0 ?? 0;
    for (const glyph of row.glyphs) {
        if (time >= glyph.endTime) {
            lit = glyph.x1;
            continue;
        }
        if (time > glyph.startTime) {
            const span = Math.max(1e-3, glyph.endTime - glyph.startTime);
            lit = glyph.x0 + (glyph.x1 - glyph.x0) * Math.min(1, (time - glyph.startTime) / span);
        }
        break;
    }
    return lit;
});""",
                """export const resolveMachiBoardReveal = (layout: MachiBoardLayout, time: number): number[] => layout.rows.map(row => {
    if (layout.rtl) {
        // Distance of the lit edge from the right of the board (shader compares mirrored x).
        let mirrored = layout.width - (row.glyphs[0]?.x1 ?? 0);
        for (const glyph of row.glyphs) {
            if (time >= glyph.endTime) {
                mirrored = layout.width - glyph.x0;
                continue;
            }
            if (time > glyph.startTime) {
                const span = Math.max(1e-3, glyph.endTime - glyph.startTime);
                mirrored = layout.width - glyph.x1 + (glyph.x1 - glyph.x0) * Math.min(1, (time - glyph.startTime) / span);
            }
            break;
        }
        return mirrored;
    }
    let lit = row.glyphs[0]?.x0 ?? 0;
    for (const glyph of row.glyphs) {
        if (time >= glyph.endTime) {
            lit = glyph.x1;
            continue;
        }
        if (time > glyph.startTime) {
            const span = Math.max(1e-3, glyph.endTime - glyph.startTime);
            lit = glyph.x0 + (glyph.x1 - glyph.x0) * Math.min(1, (time - glyph.startTime) / span);
        }
        break;
    }
    return lit;
});""",
                "reveal")
            write(machi_layout, layout_src)
        if "uRtl" not in screen_src:
            screen_src = replace_once(screen_src, "uniform float uSoft;\n", "uniform float uSoft;\nuniform float uRtl;\n", "uniform declaration")
            screen_src = replace_once(
                screen_src,
                "    float snapped = (floor(vUv.x * uCells.x) + 0.5) / uCells.x;\n    float on = 1.0 - smoothstep(reveal - uSoft, reveal + uSoft, mix(vUv.x, snapped, grid));",
                "    float ux = mix(vUv.x, 1.0 - vUv.x, uRtl);\n    float snapped = (floor(ux * uCells.x) + 0.5) / uCells.x;\n    float on = 1.0 - smoothstep(reveal - uSoft, reveal + uSoft, mix(ux, snapped, grid));",
                "shader reveal")
            screen_src = replace_once(screen_src, "                uSoft: { value: 0.004 },\n", "                uSoft: { value: 0.004 },\n                uRtl: { value: 0 },\n", "uniform value")
            screen_src = replace_once(
                screen_src,
                "            (reveal[2] ?? 0) / this.box.width,\n        );\n",
                "            (reveal[2] ?? 0) / this.box.width,\n        );\n        this.material.uniforms.uRtl!.value = layout && layout.rtl ? 1 : 0;\n",
                "uniform update")
            write(machi_screen, screen_src)
        print("patched Folia Machi (right-to-left board)")


# --------------------------------------------------------------------------- VisPcmTap in audio pipeline
# Sample-accurate PCM onsets for beat effects (TASK B). Pass-through processor; no audio change.
ella_rf = root / "app/src/main/java/com/ella/music/player/EllaRenderersFactory.kt"
if ella_rf.is_file():
    src = read(ella_rf)
    if "VisPcmTap" not in src:
        old = "            transitionGainAudioProcessor?.let { add(it) }\n            add(OutputProbeAudioProcessor(PlaybackAudioOutputState::updatePcmOutput))"
        new = "            transitionGainAudioProcessor?.let { add(it) }\n            // Lyric-visualizer PCM tap (pass-through): real-time kick/snare/hat for beat effects.\n            add(com.ella.music.ui.vis.VisPcmTap.instance)\n            add(OutputProbeAudioProcessor(PlaybackAudioOutputState::updatePcmOutput))"
        if src.count(old) != 1:
            fail("EllaRenderersFactory processor list anchor not found (found %d)" % src.count(old))
        src = src.replace(old, new, 1)
        write(ella_rf, src)
        print("patched EllaRenderersFactory.kt (VisPcmTap)")
    else:
        print("EllaRenderersFactory.kt already has VisPcmTap")
else:
    print("EllaRenderersFactory.kt missing — skip VisPcmTap wire")


# --------------------------------------------------------------------------- TASK C: Arabic RTL layout patches
# Prefer real dir=/mirrored layout over data transforms. Anchored, idempotent.

def patch_still_rtl(folia: Path) -> None:
    path = folia / "src/components/visualizer/still/VisualizerStill.tsx"
    if not path.is_file():
        print("still VisualizerStill.tsx missing — skip")
        return
    src = read(path)
    if "resolveLyricTextDirection" in src and "dir={resolveLyricTextDirection" in src:
        print("still already RTL-patched")
        return
    if "resolveLyricTextDirection" not in src:
        # add import after first import block line that imports from types or similar
        if "from '../../../utils/lyrics/textDirection'" not in src:
            # insert after first import line
            lines = src.splitlines(True)
            insert_at = 0
            for i, line in enumerate(lines):
                if line.startswith("import "):
                    insert_at = i + 1
            lines.insert(insert_at, "import { resolveLyricTextDirection } from '../../../utils/lyrics/textDirection';\n")
            src = "".join(lines)
    old = """                                    <div
                                        className={`drop-shadow-md text-center tracking-[0.02em] ${isCurrent ? 'text-[2.5rem] opacity-100 leading-tight' : 'text-3xl opacity-30'}`}
                                        style={{
                                            color: theme.primaryColor,
                                            fontFamily: resolveThemeFontStack(theme),
                                            scale: lyricsFontScale,
                                            fontWeight: resolveThemeFontWeight(theme, isCurrent ? 700 : 600),
                                        }}
                                    >
                                        {line.fullText}
                                    </div>"""
    new = """                                    <div
                                        className={`drop-shadow-md text-center tracking-[0.02em] ${isCurrent ? 'text-[2.5rem] opacity-100 leading-tight' : 'text-3xl opacity-30'}`}
                                        dir={resolveLyricTextDirection(line.fullText)}
                                        style={{
                                            color: theme.primaryColor,
                                            fontFamily: resolveThemeFontStack(theme),
                                            scale: lyricsFontScale,
                                            fontWeight: resolveThemeFontWeight(theme, isCurrent ? 700 : 600),
                                            unicodeBidi: 'plaintext',
                                        }}
                                    >
                                        {line.fullText}
                                    </div>"""
    if old not in src:
        fail("still lyric node anchor not found")
    src = src.replace(old, new, 1)
    write(path, src)
    print("patched still (dir=rtl)")


def patch_tilt_rtl(folia: Path) -> None:
    path = folia / "src/components/visualizer/tilt/VisualizerTilt.tsx"
    if not path.is_file():
        print("tilt missing — skip")
        return
    src = read(path)
    if "resolveLyricTextDirection" in src and "lyricDir" in src:
        print("tilt already RTL-patched")
        return
    if "from '../../../utils/lyrics/textDirection'" not in src:
        lines = src.splitlines(True)
        insert_at = 0
        for i, line in enumerate(lines):
            if line.startswith("import "):
                insert_at = i + 1
        lines.insert(insert_at, "import { resolveLyricTextDirection } from '../../../utils/lyrics/textDirection';\n")
        src = "".join(lines)
    # Mark the main lyric container with dir. Anchor on whitespace-nowrap motion.div style block.
    old = """            className="whitespace-nowrap"
            style={{
                fontSize: tiltFontSize,
                color: colors.tilt,
                fontFamily: 'inherit',
                fontStyle: 'italic',
                lineHeight: 1.25,
                fontWeight: resolveThemeFontWeight(theme, 300),
                letterSpacing: '0.15em',
            }}
        >
            {graphemes.map((seg, ti) => {"""
    new = """            className="whitespace-nowrap"
            dir={lyricDir}
            style={{
                fontSize: tiltFontSize,
                color: colors.tilt,
                fontFamily: 'inherit',
                fontStyle: 'italic',
                lineHeight: 1.25,
                fontWeight: resolveThemeFontWeight(theme, 300),
                letterSpacing: '0.15em',
                unicodeBidi: 'plaintext',
            }}
        >
            {graphemes.map((seg, ti) => {"""
    if old not in src:
        fail("tilt whitespace-nowrap anchor not found")
    src = src.replace(old, new, 1)
    # Inject lyricDir near graphemes useMemo — find a stable point before return of component
    # Add after graphemes = useMemo if present
    marker = "    const graphemes = useMemo("
    if marker in src and "const lyricDir =" not in src:
        src = src.replace(
            marker,
            "    const lyricDir = activeLine ? resolveLyricTextDirection(activeLine.fullText) : 'ltr';\n    const graphemes = useMemo(",
            1,
        )
    # Reverse stagger delay for RTL so the right-most (first sung) letter leads
    old_delay = "delay: visible && !isSpace ? ci * 0.04 : 0,"
    if old_delay in src and "lyricDir === 'rtl'" not in src:
        src = src.replace(
            old_delay,
            "delay: visible && !isSpace ? (lyricDir === 'rtl' ? (Math.max(graphemes.length - 1 - ti, 0)) * 0.04 : ci * 0.04) : 0,",
        )
    write(path, src)
    print("patched tilt (dir + stagger)")


def patch_pendolo_rtl_sweep(folia: Path) -> None:
    path = folia / "src/components/visualizer/pendolo/PendoloActiveLyricSweep.tsx"
    if not path.is_file():
        print("pendolo sweep missing — skip")
        return
    src = read(path)
    if "rtlClipLeft" in src or "fillWidthLtr" in src or "HALCYON_PHONE_PENDOLO" in src:
        print("pendolo sweep already RTL-patched")
        return
    if "from '../../../utils/lyrics/textDirection'" not in src:
        lines = src.splitlines(True)
        insert_at = 0
        for i, line in enumerate(lines):
            if line.startswith("import "):
                insert_at = i + 1
        lines.insert(insert_at, "import { resolveLyricTextDirection } from '../../../utils/lyrics/textDirection';\n")
        src = "".join(lines)
    # After fillWidth transform, mirror for RTL by returning fullWidth - fill
    old = """    const fillWidth = useTransform(currentTime, latest => {
        const fullWidth = graphemeOffsets[graphemeOffsets.length - 1] ?? layoutLine.width;
        if (timings.length === 0) return latest >= lineEndTime ? fullWidth : 0;
        if (latest <= timings[0]!.startTime) return 0;
"""
    if old not in src:
        fail("pendolo fillWidth anchor not found")
    # Add rtl flag on component — find PendoloSweepLine and add computation
    # Simpler approach: after fillWidth is computed, wrap clip with direction
    # Look for style that uses fillWidth
    if "const rtl =" not in src:
        # inject before graphemeOffsets in PendoloSweepLine
        anchor = "    const graphemeOffsets = useMemo(\n        () => measureMonetGraphemeOffsets(layoutLine.text, fontPx, fontSpec),\n        [fontPx, fontSpec, layoutLine.text],\n    );"
        if anchor not in src:
            fail("pendolo graphemeOffsets anchor not found")
        src = src.replace(
            anchor,
            anchor + "\n    const rtl = resolveLyricTextDirection(layoutLine.text) === 'rtl';",
            1,
        )
    # Find where fillWidth is applied to width style — often clipPath or width
    # Read usage of fillWidth in file by searching
    write(path, src)  # partial — continue below
    src = read(path)
    # Patch the useTransform body end is hard; instead patch consumers.
    # Common pattern: width: fillWidth  or  scaleX
    # Search for fillWidth in style
    if "rtl ? " not in src or "fullWidth - " not in src:
        # Change the transform to return mirrored width progress as left inset for RTL
        # Replace the return of progressive width by computing `progress` then
        # Actually modify: after the for-loop logic, values return startWidth/endWidth.
        # Easiest safe patch: wrap useTransform result
        if "const fillWidth = useTransform(currentTime, latest => {" in src and "const fillWidthRtl" not in src:
            src = src.replace(
                "const fillWidth = useTransform(currentTime, latest => {",
                "const fillWidthLtr = useTransform(currentTime, latest => {",
                1,
            )
            # After the closing of that useTransform — find "});" after fillWidthLtr - fragile
            # Append after graphemeOffsets block a derived value using useTransform on fillWidthLtr
            # Find "const fillWidthLtr = useTransform" block end by counting braces is hard in text.
            # Alternative: patch CSS application sites
            pass
    # Find style={{ width: fillWidth
    for a, b in [
        ("width: fillWidth,", "width: fillWidthLtr, // LTR width; RTL uses inset mirror below"),
        ("width: fillWidth }", "width: fillWidthLtr }"),
    ]:
        if a in src:
            src = src.replace(a, b)
    # Add mirror container if we can find clip overflow structure
    if "fillWidthLtr" in src and "rtlClipLeft" not in src:
        # Add after fillWidthLtr declaration start - inject a second motion value after the first useTransform closes
        # Heuristic: insert after first occurrence of "    });\n" following fillWidthLtr
        idx = src.find("const fillWidthLtr = useTransform")
        if idx >= 0:
            # find matching close at same indent "    });" after idx
            close = src.find("\n    });\n", idx)
            if close > 0:
                insert = close + len("\n    });\n")
                helper = (
                    "    const rtlClipLeft = useTransform(fillWidthLtr, w => {\n"
                    "        const fullWidth = graphemeOffsets[graphemeOffsets.length - 1] ?? layoutLine.width;\n"
                    "        return rtl ? Math.max(fullWidth - w, 0) : 0;\n"
                    "    });\n"
                    "    const fillWidth = fillWidthLtr;\n"
                )
                src = src[:insert] + helper + src[insert:]
    # Mirror the mask gradient for RTL (reveal from the right).
    src = read(path)
    old_mask = """    const maskImage = useTransform(fillWidth, width => {
        const edgeSoftness = Math.min(Math.max(fontPx * 0.42, 8), 16);
        const paddedFillWidth = glowPaddingPx + width;
        return `linear-gradient(90deg, #000 0px, #000 ${Math.max(paddedFillWidth - edgeSoftness, 0)}px, rgba(0, 0, 0, 0.84) ${paddedFillWidth}px, transparent ${paddedFillWidth + edgeSoftness}px)`;
    });"""
    new_mask = """    const maskImage = useTransform(fillWidthLtr, width => {
        const edgeSoftness = Math.min(Math.max(fontPx * 0.42, 8), 16);
        const fullWidth = graphemeOffsets[graphemeOffsets.length - 1] ?? layoutLine.width;
        if (rtl) {
            const visible = width;
            const start = Math.max(fullWidth - visible, 0) + glowPaddingPx;
            const end = fullWidth + glowPaddingPx;
            return `linear-gradient(90deg, transparent 0px, transparent ${Math.max(start - edgeSoftness, 0)}px, rgba(0, 0, 0, 0.84) ${start}px, #000 ${Math.min(start + edgeSoftness, end)}px, #000 ${end}px)`;
        }
        const paddedFillWidth = glowPaddingPx + width;
        return `linear-gradient(90deg, #000 0px, #000 ${Math.max(paddedFillWidth - edgeSoftness, 0)}px, rgba(0, 0, 0, 0.84) ${paddedFillWidth}px, transparent ${paddedFillWidth + edgeSoftness}px)`;
    });"""
    if old_mask in src:
        src = src.replace(old_mask, new_mask, 1)
    elif "if (rtl)" in src and "linear-gradient(90deg, transparent" in src:
        pass  # already
    else:
        print("warning: pendolo maskImage anchor not found for RTL mirror")
    write(path, src)
    print("patched pendolo sweep (RTL clip helper)")


def patch_cappella_rtl(folia: Path) -> None:
    path = folia / "src/components/visualizer/cappella/CappellaBubbleParts.tsx"
    if not path.is_file():
        print("cappella bubble parts missing — skip")
        return
    src = read(path)
    if "resolveLyricTextDirection" in src and "dir={resolveLyricTextDirection" in src:
        print("cappella already RTL-patched")
        return
    if "from '../../../utils/lyrics/textDirection'" not in src:
        lines = src.splitlines(True)
        insert_at = 0
        for i, line in enumerate(lines):
            if line.startswith("import "):
                insert_at = i + 1
        lines.insert(insert_at, "import { resolveLyricTextDirection } from '../../../utils/lyrics/textDirection';\n")
        src = "".join(lines)
    old = """    return <>{message.line.fullText}</>;"""
    new = """    return (
        <span dir={resolveLyricTextDirection(message.line.fullText)} style={{ unicodeBidi: 'plaintext' }}>
            {message.line.fullText}
        </span>
    );"""
    if old not in src:
        fail("cappella CappellaText fullText anchor not found")
    src = src.replace(old, new, 1)
    write(path, src)
    print("patched cappella (dir on bubble text)")


# Run TASK C patches when folia tree is present (apply.py always has folia as sibling)
# apply.py is invoked as apply.py <halcyon_root>; folia is <halcyon_root>/../folia
_folia_root = root.parent / "folia"
if _folia_root.is_dir():
    patch_still_rtl(_folia_root)
    patch_tilt_rtl(_folia_root)
    patch_pendolo_rtl_sweep(_folia_root)
    patch_cappella_rtl(_folia_root)
else:
    print("folia tree not found next to build root — TASK C layout patches deferred to CI")


# --------------------------------------------------------------------------- TASK D: phone quality caps (hanabi / machi / nebbia / latent)
# The Android Folia APK (v0.7.21) is not in this tree; principles from that build and the handoff:
# lower particle pools, texture/DPR caps, cheaper post-process, keep the look. Anchored, idempotent.

def patch_hanabi_phone(folia: Path) -> None:
    scene = folia / "src/components/visualizer/hanabi/scene.ts"
    if scene.is_file():
        src = read(scene)
        if "SHOT_PARTICLES = 400" in src or "HALCYON_PHONE" in src:
            print("hanabi scene already phone-capped")
        elif "const SHOT_PARTICLES = 750;" in src:
            src = src.replace(
                "const SHOT_PARTICLES = 750;",
                "/** Halcyon phone cap (TASK D): was 750 on desktop Folia. */\nconst SHOT_PARTICLES = 400; // HALCYON_PHONE",
                1,
            )
            write(scene, src)
            print("patched hanabi scene (SHOT_PARTICLES 750→400)")
        else:
            print("hanabi SHOT_PARTICLES anchor missing — skip")
    credits = folia / "src/components/visualizer/hanabi/credits.ts"
    if credits.is_file():
        src = read(credits)
        if "maxParticles: 700" in src or "HALCYON_PHONE" in src:
            print("hanabi credits already phone-capped")
        elif "maxParticles: 1400," in src:
            src = src.replace(
                "maxParticles: 1400,",
                "maxParticles: 700, // HALCYON_PHONE was 1400",
                1,
            )
            write(credits, src)
            print("patched hanabi credits (maxParticles 1400→700)")
    tuning = folia / "src/components/visualizer/hanabi/hanabiTuning.ts"
    if tuning.is_file():
        src = read(tuning)
        if "MAX_BASE_RESOLUTION = 1.5" in src or "HALCYON_PHONE" in src:
            print("hanabi tuning already phone-capped")
        elif "const MAX_BASE_RESOLUTION = 2;" in src:
            src = src.replace(
                "const MAX_BASE_RESOLUTION = 2;",
                "/** Halcyon phone: was 2. */\nconst MAX_BASE_RESOLUTION = 1.5; // HALCYON_PHONE",
                1,
            )
            write(tuning, src)
            print("patched hanabi tuning (MAX_BASE_RESOLUTION 2→1.5)")
    # Default bloom slightly lower so mid-range GPUs stay cooler without a visible style change.
    types = folia / "src/components/visualizer/hanabi/types.ts"
    if types.is_file():
        src = read(types)
        if "bloom: 0.55" in src or "HALCYON_PHONE_BLOOM" in src:
            print("hanabi default bloom already adjusted")
        elif "bloom: 0.8," in src:
            src = src.replace("bloom: 0.8,", "bloom: 0.55, // HALCYON_PHONE_BLOOM was 0.8", 1)
            write(types, src)
            print("patched hanabi default bloom 0.8→0.55")


def patch_machi_phone(folia: Path) -> None:
    path = folia / "src/components/visualizer/machi/engine/quality.ts"
    if not path.is_file():
        print("machi quality.ts missing — skip")
        return
    src = read(path)
    if "HALCYON_PHONE" in src:
        print("machi quality already phone-capped")
        return
    if "const MAX_DEVICE_RATIO = 2;" in src:
        src = src.replace(
            "const MAX_DEVICE_RATIO = 2;",
            "/** Halcyon phone (TASK D): was 2. */\nconst MAX_DEVICE_RATIO = 1.5; // HALCYON_PHONE",
            1,
        )
        write(path, src)
        print("patched machi MAX_DEVICE_RATIO 2→1.5")
    else:
        print("machi MAX_DEVICE_RATIO anchor missing")


def patch_nebbia_phone(folia: Path) -> None:
    path = folia / "src/components/visualizer/nebbia/nebbiaConstants.ts"
    if not path.is_file():
        print("nebbia constants missing — skip")
        return
    src = read(path)
    if "HALCYON_PHONE" in src:
        print("nebbia already phone-capped")
        return
    changed = False
    if "fieldDrops: 0.5," in src:
        src = src.replace("fieldDrops: 0.5,", "fieldDrops: 0.35, // HALCYON_PHONE was 0.5", 1)
        changed = True
    if "export const MASK_SCALE = 0.5;" in src:
        src = src.replace(
            "export const MASK_SCALE = 0.5;",
            "/** Halcyon phone: slightly cheaper scratch mask. */\nexport const MASK_SCALE = 0.4; // HALCYON_PHONE was 0.5",
            1,
        )
        changed = True
    if "export const FOG_DIV = 4;" in src:
        src = src.replace(
            "export const FOG_DIV = 4;",
            "export const FOG_DIV = 5; // HALCYON_PHONE was 4 (coarser fog RT)",
            1,
        )
        changed = True
    if changed:
        write(path, src)
        print("patched nebbia fieldDrops/MASK_SCALE/FOG_DIV")
    else:
        print("nebbia anchors missing")


def patch_latent_phone(folia: Path) -> None:
    path = folia / "src/components/visualizer/backgrounds/latent/LatentBackground.tsx"
    if not path.is_file():
        print("latent background missing — skip")
        return
    src = read(path)
    if "HALCYON_PHONE" in src:
        print("latent already phone-capped")
        return
    if "const MAX_SHADER_PIXELS = 1280 * 720;" in src:
        src = src.replace(
            "const MAX_SHADER_PIXELS = 1280 * 720;",
            "/** Halcyon phone (TASK D): was 1280×720. */\nconst MAX_SHADER_PIXELS = 960 * 540; // HALCYON_PHONE",
            1,
        )
        write(path, src)
        print("patched latent MAX_SHADER_PIXELS 1280x720→960x540")
    else:
        print("latent MAX_SHADER_PIXELS anchor missing")


_folia_for_d = root.parent / "folia"
if _folia_for_d.is_dir():
    patch_hanabi_phone(_folia_for_d)
    patch_machi_phone(_folia_for_d)
    patch_nebbia_phone(_folia_for_d)
    patch_latent_phone(_folia_for_d)
else:
    print("folia tree not found — TASK D phone caps deferred to CI")

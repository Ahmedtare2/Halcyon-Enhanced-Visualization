package com.ella.music.player

import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.ForwardingAudioSink
import java.nio.ByteBuffer
import java.util.concurrent.CopyOnWriteArrayList
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

/** A bounded, opt-in copy of decoded PCM with the sink's presentation timestamp. */
internal data class PlaybackPcmBlock(
    val trackKey: String,
    val sourceId: String,
    val presentationTimeUs: Long,
    val sampleRate: Int,
    val channelCount: Int,
    val encoding: Int,
    val bytes: ByteArray
)

internal data class PlaybackPcmClock(
    val trackKey: String,
    val positionUs: Long,
    /** Submitted PCM after the current playout position; this is queue depth, not acoustic latency. */
    val queuedAheadMs: Int,
    val updatedAtMs: Long
)

internal object PlaybackPcmTap {
    private val listeners = CopyOnWriteArrayList<(PlaybackPcmBlock) -> Unit>()
    private val _clock = MutableStateFlow<PlaybackPcmClock?>(null)
    val clock = _clock.asStateFlow()
    @Volatile private var latestTrackKey: String? = null
    @Volatile private var latestPositionUs: Long = -1L
    @Volatile private var latestQueuedAheadMs: Int = 0
    @Volatile private var latestUpdatedAtMs: Long = 0L

    val isObserved: Boolean get() = listeners.isNotEmpty()

    fun observe(listener: (PlaybackPcmBlock) -> Unit): AutoCloseable {
        listeners.add(listener)
        return AutoCloseable { listeners.remove(listener) }
    }

    internal fun publish(block: PlaybackPcmBlock) {
        if (listeners.isEmpty()) return
        listeners.forEach { listener -> runCatching { listener(block) } }
    }

    internal fun updateClock(trackKey: String, positionUs: Long, submittedThroughUs: Long) {
        if (positionUs < 0L) return
        val now = android.os.SystemClock.elapsedRealtime()
        val queued = ((submittedThroughUs - positionUs).coerceAtLeast(0L) / 1000L)
            .coerceAtMost(1500L).toInt()
        latestTrackKey = trackKey
        latestPositionUs = positionUs
        latestQueuedAheadMs = queued
        latestUpdatedAtMs = now
        val previous = _clock.value
        if (previous == null || previous.trackKey != trackKey || now - previous.updatedAtMs >= 200L) {
            _clock.value = PlaybackPcmClock(trackKey, positionUs, queued, now)
        }
    }

    fun clockFor(trackKey: String): PlaybackPcmClock? {
        val now = android.os.SystemClock.elapsedRealtime()
        if (latestTrackKey != trackKey || now - latestUpdatedAtMs >= 500L || latestPositionUs < 0L) return null
        return PlaybackPcmClock(trackKey, latestPositionUs, latestQueuedAheadMs, latestUpdatedAtMs)
    }
}

/**
 * Taps only PCM frames actually accepted by the sink. Media3 supplies the PTS for the first frame;
 * the buffer offset below keeps partial writes sample-aligned. The original buffer is never changed.
 */
@UnstableApi
internal class PcmTapAudioSink(
    delegate: AudioSink,
    private val sourceId: String,
    private val trackKeyProvider: () -> String?
) : ForwardingAudioSink(delegate) {
    private var pcmFormat: Format? = null
    private var lastBuffer: ByteBuffer? = null
    private var firstBufferPosition = 0
    private var lastPosition = 0
    private var firstPresentationTimeUs = 0L
    private var submittedThroughUs = 0L

    override fun configure(audioSinkConfig: AudioSink.AudioSinkConfig) {
        super.configure(audioSinkConfig)
        pcmFormat = audioSinkConfig.format
        resetBufferState()
    }

    override fun flush() {
        super.flush()
        resetBufferState()
        submittedThroughUs = 0L
    }

    override fun handleDiscontinuity() {
        super.handleDiscontinuity()
        resetBufferState()
        submittedThroughUs = 0L
    }

    override fun reset() {
        super.reset()
        pcmFormat = null
        resetBufferState()
        submittedThroughUs = 0L
    }

    private fun resetBufferState() {
        lastBuffer = null
        firstBufferPosition = 0
        lastPosition = 0
        firstPresentationTimeUs = 0L
    }

    override fun handleBuffer(buffer: ByteBuffer, presentationTimeUs: Long, encodedAccessUnitCount: Int): Boolean {
        val before = buffer.position()
        val sameBuffer = buffer === lastBuffer && presentationTimeUs == firstPresentationTimeUs && before >= lastPosition
        if (!sameBuffer) {
            lastBuffer = buffer
            firstBufferPosition = before
            lastPosition = before
            firstPresentationTimeUs = presentationTimeUs
        }
        val format = pcmFormat
        val handled = super.handleBuffer(buffer, presentationTimeUs, encodedAccessUnitCount)
        val after = buffer.position()
        val bytesPerSample = format?.let { bytesPerSample(it.pcmEncoding) } ?: 0
        val channels = format?.channelCount ?: 0
        val rate = format?.sampleRate ?: 0
        val frameBytes = bytesPerSample * channels
        val acceptedBytes = if (frameBytes > 0) ((after - before) / frameBytes) * frameBytes else 0
        if (acceptedBytes > 0 && rate > 0 && format != null && PlaybackPcmTap.isObserved) {
            val key = runCatching { trackKeyProvider() }.getOrNull()
            if (!key.isNullOrBlank()) {
                val byteOffset = before - firstBufferPosition
                val pts = firstPresentationTimeUs + byteOffset.toLong() / frameBytes * 1_000_000L / rate
                val copy = ByteArray(acceptedBytes)
                val view = buffer.duplicate()
                view.position(before)
                view.limit(before + acceptedBytes)
                view.get(copy)
                submittedThroughUs = firstPresentationTimeUs +
                    (after - firstBufferPosition).toLong() / frameBytes * 1_000_000L / rate
                PlaybackPcmTap.publish(
                    PlaybackPcmBlock(key, sourceId, pts, rate, channels, format.pcmEncoding, copy)
                )
            }
        }
        lastPosition = after
        if (handled) lastBuffer = null
        return handled
    }

    override fun getCurrentPositionUs(sourceEnded: Boolean): Long {
        val positionUs = super.getCurrentPositionUs(sourceEnded)
        if (positionUs != AudioSink.CURRENT_POSITION_NOT_SET && PlaybackPcmTap.isObserved) {
            val key = runCatching { trackKeyProvider() }.getOrNull()
            if (!key.isNullOrBlank()) PlaybackPcmTap.updateClock(key, positionUs, submittedThroughUs)
        }
        return positionUs
    }

    private fun bytesPerSample(encoding: Int): Int = when (encoding) {
        C.ENCODING_PCM_8BIT -> 1
        C.ENCODING_PCM_16BIT -> 2
        C.ENCODING_PCM_24BIT -> 3
        C.ENCODING_PCM_32BIT, C.ENCODING_PCM_FLOAT -> 4
        else -> 0
    }
}

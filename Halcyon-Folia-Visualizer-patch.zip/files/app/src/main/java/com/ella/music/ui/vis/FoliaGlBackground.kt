package com.ella.music.ui.vis

import android.content.Context
import android.graphics.Color
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.os.SystemClock
import android.view.Choreographer
import android.view.View
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Cheap native colour-mesh background drawn behind a transparent Folia WebView.
 *
 * Mirrors the Android Folia (Capacitor) approach: a small fixed GL surface is upscaled by the
 * compositor (blur is free), paced by Choreographer with a vsync divider, and fully stopped when
 * not visible. Only pure gradient / colour-mesh backgrounds are replaced; heavy Folia backgrounds
 * (Monet image, Nomand shader, Sora, URL, Latent) stay in the WebView.
 *
 * Verified by: source review against the handoff description of FoliaBackgroundSurfaceView.java;
 * not compiled in this sandbox (no Android SDK).
 */
internal class FoliaGlBackgroundView(context: Context) : GLSurfaceView(context) {

    private val renderer = MeshRenderer()
    private var visible = false
    private var playing = false
    private var vsyncDivider = 2
    private var frameCounter = 0
    private var choreographerRegistered = false

    private val frameCallback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!visible || !playing) return
            frameCounter++
            if (frameCounter % max(1, vsyncDivider) == 0) {
                requestRender()
            }
            if (choreographerRegistered) {
                Choreographer.getInstance().postFrameCallback(this)
            }
        }
    }

    init {
        setEGLContextClientVersion(2)
        // Tiny fixed surface; system compositor scales it up. Saves fill-rate.
        holder.setFixedSize(RENDER_W, RENDER_H)
        setRenderer(renderer)
        renderMode = RENDERMODE_WHEN_DIRTY
        preserveEGLContextOnPause = true
    }

    fun setPalette(colors: IntArray, transitionMs: Int = 400) {
        renderer.setPalette(colors, transitionMs)
    }

    fun setEnergy(bass: Float, mid: Float, high: Float, isPlaying: Boolean) {
        playing = isPlaying
        renderer.setEnergy(bass, mid, high)
        if (isPlaying && visible) ensureChoreographer() else stopChoreographer()
    }

    fun setDim(dim: Float) {
        renderer.setDim(dim)
    }

    fun setVsyncDivider(divider: Int) {
        vsyncDivider = divider.coerceIn(1, 8)
    }

    fun setNativeEnabled(enabled: Boolean) {
        visibility = if (enabled) View.VISIBLE else View.GONE
        if (!enabled) {
            visible = false
            stopChoreographer()
        }
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        val nowVisible = visibility == View.VISIBLE && getVisibility() == View.VISIBLE
        if (nowVisible != visible) {
            visible = nowVisible
            if (visible && playing) ensureChoreographer() else stopChoreographer()
        }
    }

    override fun onPause() {
        stopChoreographer()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        if (visible && playing) ensureChoreographer()
    }

    fun destroy() {
        stopChoreographer()
        onPause()
    }

    private fun ensureChoreographer() {
        if (choreographerRegistered) return
        choreographerRegistered = true
        frameCounter = 0
        Choreographer.getInstance().postFrameCallback(frameCallback)
    }

    private fun stopChoreographer() {
        if (!choreographerRegistered) return
        choreographerRegistered = false
        Choreographer.getInstance().removeFrameCallback(frameCallback)
    }

    companion object {
        /** Fixed render size; compositor upscales. Matches the Android Folia ~180×400 idea. */
        const val RENDER_W = 180
        const val RENDER_H = 400

        /** Background modes that the native mesh can replace (pure colour / fluid mesh). */
        val NATIVE_BG_MODES = setOf(
            "", "common", "fluid", "default", "null"
        )

        fun canReplaceBackground(mode: String?): Boolean {
            if (mode.isNullOrBlank()) return true
            val m = mode.lowercase()
            return m in NATIVE_BG_MODES || m == "common"
        }
    }
}

private class MeshRenderer : GLSurfaceView.Renderer {

    private var program = 0
    private var aPos = 0
    private var uTime = 0
    private var uBass = 0
    private var uMid = 0
    private var uHigh = 0
    private var uDim = 0
    private var uColors = 0
    private var uColorCount = 0

    private val quad: FloatBuffer = ByteBuffer.allocateDirect(8 * 4).order(ByteOrder.nativeOrder())
        .asFloatBuffer().apply {
            put(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f))
            position(0)
        }

    private val targetColors = FloatArray(16) // up to 4 RGB + pad
    private val currentColors = FloatArray(16)
    private var colorCount = 3
    private var bass = 0f
    private var mid = 0f
    private var high = 0f
    private var dim = 0.15f
    private var startMs = SystemClock.elapsedRealtime()
    private var transitionStart = 0L
    private var transitionMs = 400
    private val fromColors = FloatArray(16)

    fun setPalette(colors: IntArray, transitionMs: Int) {
        val n = min(4, max(1, colors.size))
        colorCount = n
        System.arraycopy(currentColors, 0, fromColors, 0, 16)
        for (i in 0 until n) {
            val c = colors[i]
            targetColors[i * 3] = Color.red(c) / 255f
            targetColors[i * 3 + 1] = Color.green(c) / 255f
            targetColors[i * 3 + 2] = Color.blue(c) / 255f
        }
        // fill remaining with last colour
        for (i in n until 4) {
            targetColors[i * 3] = targetColors[(n - 1) * 3]
            targetColors[i * 3 + 1] = targetColors[(n - 1) * 3 + 1]
            targetColors[i * 3 + 2] = targetColors[(n - 1) * 3 + 2]
        }
        this.transitionMs = max(1, transitionMs)
        transitionStart = SystemClock.elapsedRealtime()
    }

    fun setEnergy(b: Float, m: Float, h: Float) {
        bass = b.coerceIn(0f, 1.5f)
        mid = m.coerceIn(0f, 1.5f)
        high = h.coerceIn(0f, 1.5f)
    }

    fun setDim(d: Float) {
        dim = d.coerceIn(0f, 0.9f)
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        val vs = """
            attribute vec2 aPos;
            varying vec2 vUv;
            void main() {
              vUv = aPos * 0.5 + 0.5;
              gl_Position = vec4(aPos, 0.0, 1.0);
            }
        """.trimIndent()
        val fs = """
            precision mediump float;
            varying vec2 vUv;
            uniform float uTime;
            uniform float uBass;
            uniform float uMid;
            uniform float uHigh;
            uniform float uDim;
            uniform vec3 uColors[4];
            uniform int uColorCount;

            vec3 sampleGradient(float t) {
              // soft mesh: three vertical stops with horizontal wave
              float t0 = clamp(t, 0.0, 1.0);
              if (uColorCount <= 1) return uColors[0];
              if (uColorCount == 2) return mix(uColors[0], uColors[1], t0);
              if (t0 < 0.5) return mix(uColors[0], uColors[1], t0 * 2.0);
              return mix(uColors[1], uColors[2], (t0 - 0.5) * 2.0);
            }

            void main() {
              float wave = sin(vUv.x * 6.28318 + uTime * 0.4) * 0.04 * (0.4 + uMid);
              float wave2 = sin(vUv.y * 4.0 - uTime * 0.25) * 0.03 * (0.3 + uBass);
              float t = clamp(vUv.y + wave + wave2, 0.0, 1.0);
              vec3 col = sampleGradient(t);
              // subtle energy pulse
              float pulse = 1.0 + uBass * 0.08 + uHigh * 0.04;
              col *= pulse;
              // soft vignette
              float vig = smoothstep(1.2, 0.2, length(vUv - 0.5) * 1.4);
              col *= mix(1.0, vig, 0.35);
              col *= (1.0 - uDim);
              gl_FragColor = vec4(col, 1.0);
            }
        """.trimIndent()
        program = link(vs, fs)
        aPos = GLES20.glGetAttribLocation(program, "aPos")
        uTime = GLES20.glGetUniformLocation(program, "uTime")
        uBass = GLES20.glGetUniformLocation(program, "uBass")
        uMid = GLES20.glGetUniformLocation(program, "uMid")
        uHigh = GLES20.glGetUniformLocation(program, "uHigh")
        uDim = GLES20.glGetUniformLocation(program, "uDim")
        uColors = GLES20.glGetUniformLocation(program, "uColors")
        uColorCount = GLES20.glGetUniformLocation(program, "uColorCount")
        // seed a dark blue default
        setPalette(intArrayOf(0xFF0B0F1A.toInt(), 0xFF1A2744.toInt(), 0xFF0E1628.toInt()), 1)
        System.arraycopy(targetColors, 0, currentColors, 0, 16)
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
    }

    override fun onDrawFrame(gl: GL10?) {
        // interpolate palette
        val now = SystemClock.elapsedRealtime()
        val t = if (transitionMs <= 1) 1f else min(1f, (now - transitionStart).toFloat() / transitionMs)
        val ease = t * t * (3f - 2f * t)
        for (i in 0 until 16) {
            currentColors[i] = fromColors[i] + (targetColors[i] - fromColors[i]) * ease
        }
        val timeSec = (now - startMs) / 1000f
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        GLES20.glUseProgram(program)
        GLES20.glEnableVertexAttribArray(aPos)
        GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 0, quad)
        GLES20.glUniform1f(uTime, timeSec)
        GLES20.glUniform1f(uBass, bass)
        GLES20.glUniform1f(uMid, mid)
        GLES20.glUniform1f(uHigh, high)
        GLES20.glUniform1f(uDim, dim)
        GLES20.glUniform1i(uColorCount, colorCount)
        // upload 4 vec3
        val flat = FloatArray(12)
        System.arraycopy(currentColors, 0, flat, 0, 12)
        GLES20.glUniform3fv(uColors, 4, flat, 0)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(aPos)
    }

    private fun link(vsSrc: String, fsSrc: String): Int {
        val vs = compile(GLES20.GL_VERTEX_SHADER, vsSrc)
        val fs = compile(GLES20.GL_FRAGMENT_SHADER, fsSrc)
        val prog = GLES20.glCreateProgram()
        GLES20.glAttachShader(prog, vs)
        GLES20.glAttachShader(prog, fs)
        GLES20.glLinkProgram(prog)
        val status = IntArray(1)
        GLES20.glGetProgramiv(prog, GLES20.GL_LINK_STATUS, status, 0)
        if (status[0] == 0) {
            val log = GLES20.glGetProgramInfoLog(prog)
            GLES20.glDeleteProgram(prog)
            throw RuntimeException("GL link failed: $log")
        }
        GLES20.glDeleteShader(vs)
        GLES20.glDeleteShader(fs)
        return prog
    }

    private fun compile(type: Int, src: String): Int {
        val shader = GLES20.glCreateShader(type)
        GLES20.glShaderSource(shader, src)
        GLES20.glCompileShader(shader)
        val status = IntArray(1)
        GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, status, 0)
        if (status[0] == 0) {
            val log = GLES20.glGetShaderInfoLog(shader)
            GLES20.glDeleteShader(shader)
            throw RuntimeException("GL compile failed: $log")
        }
        return shader
    }
}

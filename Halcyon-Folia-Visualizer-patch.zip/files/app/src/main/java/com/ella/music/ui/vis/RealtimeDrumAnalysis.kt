package com.ella.music.ui.vis

import androidx.media3.common.C
import com.ella.music.player.PlaybackPcmBlock
import com.ella.music.player.PlaybackPcmTap
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch

internal data class RealtimeDrumHit(
    val key: String,
    val timeUs: Long,
    val kind: Int,
    val strength: Float
)

/** PCM path: no RECORD_AUDIO, bounded queue, and all FFT work off the playback thread. */
internal object RealtimeDrumAnalysis {
    private val queue = Channel<PlaybackPcmBlock>(64, kotlinx.coroutines.channels.BufferOverflow.DROP_OLDEST)
    private val _hits = MutableSharedFlow<RealtimeDrumHit>(extraBufferCapacity = 128)
    val hits = _hits.asSharedFlow()
    private var observer: AutoCloseable? = null
    private var worker: Job? = null

    @Synchronized
    fun start(scope: CoroutineScope) {
        if (worker == null) {
            worker = scope.launch(Dispatchers.Default) {
                val streams = HashMap<String, Stream>()
                val expectedPts = HashMap<String, Long>()
                val streamRates = HashMap<String, Int>()
                for (block in queue) {
                    try {
                        val identity = block.sourceId
                        val expected = expectedPts[identity]
                        val broken = expected != null && (block.presentationTimeUs - expected).let { it < -20_000L || it > 150_000L }
                        if (broken || streamRates[identity] != block.sampleRate || streams[identity]?.key != block.trackKey) {
                            streams.remove(identity)
                        }
                        val stream = streams.getOrPut(identity) { Stream(block.trackKey, block.sampleRate, block.presentationTimeUs) }
                        if (block.sampleRate > 0) {
                            stream.feed(block) { hit -> _hits.tryEmit(hit) }
                            expectedPts[identity] = block.presentationTimeUs + block.frameCountUs()
                            streamRates[identity] = block.sampleRate
                        }
                    } catch (_: Throwable) {
                        // Analysis must never affect playback.
                    }
                }
            }
        }
        if (observer == null) observer = PlaybackPcmTap.observe { block -> queue.trySend(block) }
    }

    @Synchronized
    fun stop() {
        observer?.close()
        observer = null
        worker?.cancel()
        worker = null
        while (queue.tryReceive().isSuccess) Unit
    }

    private fun PlaybackPcmBlock.frameCountUs(): Long {
        val bytesPerSample = when (encoding) {
            C.ENCODING_PCM_8BIT -> 1
            C.ENCODING_PCM_16BIT -> 2
            C.ENCODING_PCM_24BIT -> 3
            C.ENCODING_PCM_32BIT, C.ENCODING_PCM_FLOAT -> 4
            else -> 0
        }
        val frameBytes = bytesPerSample * channelCount
        return if (frameBytes <= 0 || sampleRate <= 0) 0L else bytes.size.toLong() / frameBytes * 1_000_000L / sampleRate
    }

    private class Stream(val key: String, private val sampleRate: Int, private val originPtsUs: Long) {
        private val n = 2048
        private val hop = 512
        private val ring = FloatArray(n)
        private val window = FloatArray(n) { (0.5 - 0.5 * cos(2.0 * PI * it / (n - 1))).toFloat() }
        private val fft = Fft(n)
        private val re = FloatArray(n)
        private val im = FloatArray(n)
        private val previous = FloatArray(n / 2)
        private val binHz = sampleRate.toDouble() / n
        private val kickMax = floor(150.0 / binHz).toInt().coerceIn(1, n / 2 - 1)
        private val snareMin = kickMax + 1
        private val snareMax = floor(4000.0 / binHz).toInt().coerceIn(snareMin, n / 2 - 1)
        private val hatMin = ceil(6000.0 / binHz).toInt().coerceAtMost(n / 2)
        private val hatMax = min(floor(12000.0 / binHz).toInt(), n / 2 - 1)
        private val flux = Array(3) { FloatArray(32) }
        private val shares = FloatArray(32)
        private val kinds = IntArray(32)
        private val history = Array(3) { RiseHistory(500) }
        private var position = 0
        private var filled = 0
        private var sinceFrame = 0
        private var sampleCount = 0L
        private var frameIndex = -1
        private var lastHitUs = Long.MIN_VALUE

        fun feed(block: PlaybackPcmBlock, emit: (RealtimeDrumHit) -> Unit) {
            val bytesPerSample = when (block.encoding) {
                C.ENCODING_PCM_8BIT -> 1
                C.ENCODING_PCM_16BIT -> 2
                C.ENCODING_PCM_24BIT -> 3
                C.ENCODING_PCM_32BIT, C.ENCODING_PCM_FLOAT -> 4
                else -> return
            }
            val channels = block.channelCount
            if (channels <= 0 || block.sampleRate != sampleRate) return
            val frameBytes = bytesPerSample * channels
            val input = ByteBuffer.wrap(block.bytes).order(ByteOrder.nativeOrder())
            val frames = block.bytes.size / frameBytes
            repeat(frames) {
                var mono = 0f
                repeat(channels) { mono += readSample(input, block.encoding, bytesPerSample) }
                add(mono / channels, emit)
            }
        }

        private fun readSample(input: ByteBuffer, encoding: Int, bytes: Int): Float = when (encoding) {
            C.ENCODING_PCM_8BIT -> ((input.get().toInt() and 0xff) - 128) / 128f
            C.ENCODING_PCM_16BIT -> input.short / 32768f
            C.ENCODING_PCM_24BIT -> {
                var v = (input.get().toInt() and 0xff) or
                    ((input.get().toInt() and 0xff) shl 8) or
                    ((input.get().toInt() and 0xff) shl 16)
                if ((v and 0x800000) != 0) v = v or -0x1000000
                v / 8388608f
            }
            C.ENCODING_PCM_32BIT -> input.int / 2147483648f
            C.ENCODING_PCM_FLOAT -> input.float.coerceIn(-1f, 1f)
            else -> 0f
        }

        private fun add(sample: Float, emit: (RealtimeDrumHit) -> Unit) {
            ring[position] = sample
            position = (position + 1) % n
            sampleCount++
            if (filled < n) filled++
            sinceFrame++
            if (sinceFrame >= hop) {
                sinceFrame -= hop
                if (filled >= n) frame(emit)
            }
        }

        private fun frame(emit: (RealtimeDrumHit) -> Unit) {
            for (i in 0 until n) {
                re[i] = ring[(position + i) % n] * window[i]
                im[i] = 0f
            }
            fft.transform(re, im)
            var kick = 0f
            var snare = 0f
            var hat = 0f
            val scale = 1f / (n / 8f)
            val top = max(snareMax, hatMax)
            for (k in 1..top) {
                val magnitude = sqrt(re[k] * re[k] + im[k] * im[k]) * scale
                val logMagnitude = ln(1f + 30f * magnitude)
                val delta = max(0f, logMagnitude - previous[k])
                previous[k] = logMagnitude
                when {
                    k <= kickMax -> kick += delta
                    k in snareMin..snareMax -> snare += delta
                    k in hatMin..hatMax -> hat += delta
                }
            }
            frameIndex++
            val at = frameIndex and 31
            flux[0][at] = kick
            flux[1][at] = snare
            flux[2][at] = hat
            if (frameIndex >= 8) {
                val readyIndex = frameIndex - 2
                val readyAt = readyIndex and 31
                val rise0 = riseAt(0, readyIndex)
                val rise1 = riseAt(1, readyIndex)
                val rise2 = riseAt(2, readyIndex)
                history[0].add(rise0)
                history[1].add(rise1)
                history[2].add(rise2)
                val share0 = min(1f, rise0 / history[0].top().coerceAtLeast(1e-6f))
                val share1 = min(1f, rise1 / history[1].top().coerceAtLeast(1e-6f))
                val share2 = min(1f, rise2 / history[2].top().coerceAtLeast(1e-6f))
                var strongest = share0
                var kind = 0
                if (share1 > strongest) { strongest = share1; kind = 1 }
                if (share2 > strongest) { strongest = share2; kind = 2 }
                shares[readyAt] = strongest
                kinds[readyAt] = kind
            }
            if (frameIndex >= 13) {
                val candidate = frameIndex - 5
                val candidateAt = candidate and 31
                val strength = shares[candidateAt]
                if (strength >= 0.15f) {
                    var peak = true
                    for (neighbor in max(0, candidate - 3)..candidate + 3) {
                        if (neighbor == candidate) continue
                        val value = shares[neighbor and 31]
                        if (value > strength || (value == strength && neighbor < candidate)) { peak = false; break }
                    }
                    val timeUs = originPtsUs + ((candidate * hop + n * 0.75) * 1_000_000.0 / sampleRate).toLong()
                    if (peak && (lastHitUs == Long.MIN_VALUE || timeUs - lastHitUs >= 90_000L)) {
                        lastHitUs = timeUs
                        emit(RealtimeDrumHit(key, timeUs, kinds[candidateAt], strength))
                    }
                }
            }
        }

        private fun riseAt(band: Int, frame: Int): Float {
            var peak = 0f
            for (index in frame - 1..frame + 2) peak = max(peak, flux[band][index and 31])
            var base = 0f
            var count = 0
            for (index in frame - 6..frame - 2) { base += flux[band][index and 31]; count++ }
            return max(0f, peak - base / max(1, count))
        }
    }

    private class RiseHistory(private val capacity: Int) {
        private val values = FloatArray(capacity)
        private val scratch = FloatArray(capacity)
        private var size = 0
        private var writeAt = 0
        private var additions = 0
        private var cachedTop = 1f
        fun add(value: Float) {
            if (value <= 0f) return
            values[writeAt] = value
            writeAt = (writeAt + 1) % capacity
            size = min(capacity, size + 1)
            additions++
            if (size == 1 || additions % 8 == 0) {
                values.copyInto(scratch, endIndex = size)
                scratch.sort(0, size)
                cachedTop = scratch[min(size - 1, floor(0.99f * size).toInt())]
            }
        }
        fun top(): Float = cachedTop
    }
}

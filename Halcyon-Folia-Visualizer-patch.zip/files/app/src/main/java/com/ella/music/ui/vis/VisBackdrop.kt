package com.ella.music.ui.vis

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.os.Handler
import android.os.Looper
import android.view.Choreographer
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import org.json.JSONObject

/**
 * The native background layer: a tiny OpenGL ES 2 surface that sits BEHIND the (transparent)
 * WebView and draws the animated colour-mesh / cover backgrounds, the way Folia's own Android
 * build does it. The WebView then only draws the lyric style on a transparent page.
 *
 * What it draws is decided by the page (it knows the resolved background and its tuning) and
 * pushed in through [FoliaBridge.onBackdrop]; the live bass/mid/high comes straight from the
 * same [AudioDrive] the bands to the page use. Frames are paced by Choreographer with a vsync
 * divider and stop entirely when the layer is not active, so a background that must stay in the
 * WebView (cover art, video, shader effects) costs nothing here.
 *
 * If OpenGL cannot start or keeps failing, [FoliaBackdropView.reportFailure] runs and the page
 * falls back to its own web background.
 */
internal class BackdropState {
    /** 0 = nothing (the web background draws), 1 = Folia "latent" colour mesh, 2 = Folia "common" fluid. */
    @Volatile var kind = 0
    @Volatile var meshColors = floatArrayOf(
        0.05f, 0.07f, 0.12f, 0.10f, 0.12f, 0.20f, 0.14f, 0.16f, 0.26f,
        0.08f, 0.10f, 0.16f, 0.05f, 0.07f, 0.12f, 0.90f, 0.77f, 0.25f
    )
    @Volatile var themeBg = floatArrayOf(0.04f, 0.06f, 0.10f)
    @Volatile var ditherBack = floatArrayOf(0f, 0f, 0f)
    @Volatile var ditherFront = floatArrayOf(1f, 1f, 1f)
    // Latent tuning (mirrors Folia's LatentBackgroundTuning defaults).
    @Volatile var meshSpeed = 0.3f
    @Volatile var meshAudioSpeed = 2f
    @Volatile var ditheringSpeed = 0.1f
    @Volatile var ditheringAudioSpeed = 1.2f
    @Volatile var ditheringSize = 2.5f
    @Volatile var ditheringOpacity = 0.55f
    @Volatile var meshDistortion = 0.8f
    @Volatile var meshSwirl = 0.1f
    @Volatile var overlayOpacity = 0.35f
    @Volatile var overlayEnabled = true
    @Volatile var showMesh = true
    @Volatile var showDither = true
    @Volatile var enhancedBeatResponse = true
    // Common (fluid) tuning.
    @Volatile var overlayPrimary = floatArrayOf(1f, 1f, 1f)
    @Volatile var overlaySecondary = floatArrayOf(0.4f, 0.45f, 0.55f)
    @Volatile var bgOpacity = 0.75f
    @Volatile var vignette = true
    @Volatile var useCoverColorBg = false
    @Volatile var hasCover = false
    @Volatile var coverJpeg: ByteArray? = null
    @Volatile var coverVersion = 0
    /** The live bands and the playing state, set by the controller on every change. */
    @Volatile var drive: AudioDrive? = null
    @Volatile var playing = false

    /** Parses what the page sent through AndroidHost.onBackdrop. */
    fun parse(json: String) {
        runCatching {
            val o = JSONObject(json)
            when (o.optString("kind", "none")) {
                "latent" -> {
                    kind = 1
                    val arr = o.optJSONArray("colors")
                    if (arr != null && arr.length() >= 6) {
                        val mesh = FloatArray(18)
                        for (i in 0 until 6) {
                            val rgb = hexToRgb(arr.optString(i, "#000000"))
                            mesh[i * 3] = rgb[0]; mesh[i * 3 + 1] = rgb[1]; mesh[i * 3 + 2] = rgb[2]
                        }
                        meshColors = mesh
                    }
                    themeBg = hexToRgb(o.optString("themeBg", "#000000"))
                    ditherBack = hexToRgb(o.optString("ditherBack", "#000000"))
                    ditherFront = hexToRgb(o.optString("ditherFront", "#ffffff"))
                    val t = o.optJSONObject("tuning") ?: JSONObject()
                    meshSpeed = t.optDouble("meshSpeed", 0.3).toFloat().coerceIn(0f, 2f)
                    meshAudioSpeed = t.optDouble("meshAudioSpeed", 2.0).toFloat().coerceIn(0f, 2f)
                    ditheringSpeed = t.optDouble("ditheringSpeed", 0.1).toFloat().coerceIn(0f, 2f)
                    ditheringAudioSpeed = t.optDouble("ditheringAudioSpeed", 1.2).toFloat().coerceIn(0f, 2f)
                    ditheringSize = t.optDouble("ditheringSize", 2.5).toFloat().coerceIn(0.5f, 8f)
                    ditheringOpacity = t.optDouble("ditheringOpacity", 0.55).toFloat().coerceIn(0f, 1f)
                    meshDistortion = t.optDouble("meshDistortion", 0.8).toFloat().coerceIn(0f, 2f)
                    meshSwirl = t.optDouble("meshSwirl", 0.1).toFloat().coerceIn(0f, 1f)
                    overlayOpacity = t.optDouble("overlayOpacity", 0.35).toFloat().coerceIn(0f, 1f)
                    overlayEnabled = t.optBoolean("overlayEnabled", true)
                    showMesh = t.optString("displayMode", "both") != "dithering"
                    showDither = t.optString("displayMode", "both") != "mesh"
                    enhancedBeatResponse = t.optBoolean("enhancedBeatResponse", true)
                }
                "common" -> {
                    kind = 2
                    themeBg = hexToRgb(o.optString("themeBg", "#000000"))
                    overlayPrimary = hexToRgb(o.optString("overlayPrimary", "#ffffff"))
                    overlaySecondary = hexToRgb(o.optString("overlaySecondary", "#667788"))
                    bgOpacity = o.optDouble("bgOpacity", 0.75).toFloat().coerceIn(0f, 1f)
                    vignette = o.optBoolean("vignette", true)
                    useCoverColorBg = o.optBoolean("useCoverColorBg", false)
                    hasCover = o.optBoolean("hasCover", false)
                }
                else -> kind = 0
            }
        }.onFailure { kind = 0 }
    }

    private fun hexToRgb(hex: String): FloatArray {
        val h = hex.removePrefix("#")
        return try {
            val v = h.take(6).toLong(16)
            floatArrayOf(((v shr 16) and 0xFF) / 255f, ((v shr 8) and 0xFF) / 255f, (v and 0xFF) / 255f)
        } catch (e: Exception) {
            floatArrayOf(0f, 0f, 0f)
        }
    }
}

/**
 * The GL surface. Draws at a small fixed size (a third of the screen per side, capped) — the
 * compositor scales it up, which for a soft colour mesh is free and looks the same. [setTargetFps]
 * follows the same frame cap the page runs at; [start]/[stop] pair with the app lifecycle.
 */
internal class FoliaBackdropView(context: Context, private val state: BackdropState, private val onFailure: (String) -> Unit) :
    GLSurfaceView(context) {

    private val main = Handler(Looper.getMainLooper())
    private var running = false
    private var vsyncCount = 0L
    private var divider = 2
    private var choreographer: Choreographer? = null
    /** Set once the GL thread has a surface; a start without it within four seconds falls back. */
    @Volatile var glReady = false
    private var readyCheckPosted = false

    private val frameCallback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!running) return
            choreographer?.postFrameCallback(this)
            vsyncCount += 1
            if (divider <= 1 || vsyncCount % divider == 0L) requestRender()
        }
    }

    init {
        setEGLContextClientVersion(2)
        preserveEGLContextOnPause = true
        setRenderer(BackdropRenderer(state, this))
        renderMode = RENDERMODE_WHEN_DIRTY
    }

    /** Small surface: a third of the screen per side, capped. */
    fun useSmallSurface() {
        val dm = resources.displayMetrics
        val w = max(120, min(dm.widthPixels / 3, 480))
        val h = max(240, min(dm.heightPixels / 3, 1040))
        holder.setFixedSize(w, h)
    }

    fun setTargetFps(fps: Int) {
        val refresh = display?.refreshRate ?: 60f
        divider = if (fps <= 0) 1 else max(1, (refresh / fps).roundToInt())
    }

    fun start() {
        if (running) return
        running = true
        onResume()
        choreographer = Choreographer.getInstance().also { it.postFrameCallback(frameCallback) }
        if (!glReady && !readyCheckPosted) {
            readyCheckPosted = true
            main.postDelayed({
                readyCheckPosted = false
                if (running && !glReady && state.kind > 0) {
                    running = false
                    reportFailure("The native background could not start OpenGL; using the page background.")
                }
            }, 4000L)
        }
    }

    fun stop() {
        running = false
        choreographer?.removeFrameCallback(frameCallback)
        onPause()
    }

    internal fun reportFailure(message: String) {
        onFailure(message)
    }

    internal fun noteGlReady() {
        glReady = true
    }
}

/** Draws the active background kind with the audio bands shaped the same way the page receives them. */
internal class BackdropRenderer(private val state: BackdropState, private val owner: FoliaBackdropView) :
    GLSurfaceView.Renderer {

    private var latentProgram = -1
    private var commonProgram = -1
    private var quad: FloatBuffer? = null
    private var coverTexture = -1
    private var coverLoadedVersion = -1
    private var lastFrameNanos = 0L
    private var meshTime = 0f
    private var ditherTime = 0f
    // The audio smoothing, with the same constants Folia's LatentBackground uses.
    private var smoothedPower = 0f
    private var smoothedBass = 0f
    private var smoothedMid = 0f
    private var smoothedBeatSpeed = 0f
    private var previousBeatEnergy = 0f
    private var onsetPulse = 0f
    private var failures = 0
    private var width = 1
    private var height = 1

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        latentProgram = compileProgram(LATENT_VERTEX, LATENT_FRAGMENT)
        commonProgram = compileProgram(COMMON_VERTEX, COMMON_FRAGMENT)
        val bb = ByteBuffer.allocateDirect(8 * 4)
        bb.order(ByteOrder.nativeOrder())
        quad = bb.asFloatBuffer().apply {
            put(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f))
            position(0)
        }
        coverTexture = -1
        coverLoadedVersion = -1
        failures = 0
        if (latentProgram == -1 || commonProgram == -1) {
            reportFailure("The native background shaders failed to compile; using the page background.")
        } else {
            owner.noteGlReady()
        }
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        this.width = max(1, width)
        this.height = max(1, height)
        GLES20.glViewport(0, 0, this.width, this.height)
    }

    override fun onDrawFrame(gl: GL10?) {
        if (latentProgram == -1 || commonProgram == -1) return
        try {
            val now = System.nanoTime()
            val dt = if (lastFrameNanos == 0L) 0.016f else ((now - lastFrameNanos) / 1_000_000_000f).coerceIn(0.001f, 0.1f)
            lastFrameNanos = now
            when (state.kind) {
                1 -> drawLatent(dt)
                2 -> drawCommon()
                else -> GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
            }
            failures = 0
        } catch (e: Exception) {
            failures += 1
            if (failures == 12) reportFailure("The native background stopped drawing (" + (e.message ?: "error") + "); using the page background.")
        }
    }

    private fun reportFailure(message: String) {
        Handler(Looper.getMainLooper()).post { owner.reportFailure(message) }
    }

    // The band shaping mirrors Folia's own (pow boosts on a 0..255 contract, divided back to 0..1)
    // so the mesh reacts exactly like the page's copy of the same background.
    private fun drive(): FloatArray {
        val d = state.drive ?: return FloatArray(6)
        val b = d.bass.toDouble().pow(1.8).toFloat()
        val lm = ((d.bass + d.mid) * 0.5).toDouble().pow(2.0).toFloat()
        val m = d.mid.toDouble().pow(2.0).toFloat()
        val v = d.vocal.toDouble().pow(1.5).toFloat()
        val t = d.treble.toDouble().pow(2.0).toFloat()
        val power = ((d.bass + d.mid) * 0.5).toDouble().pow(3.0).toFloat()
        return floatArrayOf(b, lm, m, v, t, power)
    }

    private fun drawLatent(dt: Float) {
        val q = quad ?: return
        val band = drive()
        val playing = state.playing
        smoothedPower += ((if (playing) band[5] else 0f) - smoothedPower) * 0.12f
        smoothedBass += ((if (playing) band[0] else 0f) - smoothedBass) * 0.16f
        smoothedMid += ((if (playing) max(band[2], band[3]) else 0f) - smoothedMid) * 0.13f
        val energy = 0.22f * band[0] + 0.18f * band[1] + 0.22f * band[2] + 0.28f * band[3] + 0.1f * band[4]
        onsetPulse = max(onsetPulse * 0.84f, ((energy - previousBeatEnergy) * 7f).coerceIn(0f, 1f))
        previousBeatEnergy = energy
        val target = if (playing) {
            if (state.enhancedBeatResponse) (energy * 0.42f + onsetPulse * 0.85f).coerceIn(0f, 1f) else energy.coerceIn(0f, 1f)
        } else 0f
        smoothedBeatSpeed += (target - smoothedBeatSpeed) * (if (target > smoothedBeatSpeed) 0.42f else 0.14f)
        // The web layer eases the speed between the base and the audio target by the smoothed beat
        // response, and scales the result down while paused; the same here.
        val pauseScale = if (playing) 1f else 0.12f
        val meshSpeed = (state.meshSpeed + (state.meshAudioSpeed - state.meshSpeed) * smoothedBeatSpeed) * pauseScale
        val ditherSpeed = (state.ditheringSpeed + (state.ditheringAudioSpeed - state.ditheringSpeed) * smoothedBeatSpeed) * pauseScale
        meshTime += dt * meshSpeed
        ditherTime += dt * ditherSpeed

        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        val p = latentProgram
        GLES20.glUseProgram(p)
        val pos = GLES20.glGetAttribLocation(p, "a_pos")
        GLES20.glEnableVertexAttribArray(pos)
        GLES20.glVertexAttribPointer(pos, 2, GLES20.GL_FLOAT, false, 0, q)
        GLES20.glUniform2f(GLES20.glGetUniformLocation(p, "u_res"), width.toFloat(), height.toFloat())
        val meshLoc = GLES20.glGetUniformLocation(p, "u_mesh[0]")
        if (meshLoc >= 0) GLES20.glUniform3fv(meshLoc, 6, state.meshColors, 0)
        GLES20.glUniform3f(GLES20.glGetUniformLocation(p, "u_dback"), state.ditherBack[0], state.ditherBack[1], state.ditherBack[2])
        GLES20.glUniform3f(GLES20.glGetUniformLocation(p, "u_dfront"), state.ditherFront[0], state.ditherFront[1], state.ditherFront[2])
        GLES20.glUniform3f(GLES20.glGetUniformLocation(p, "u_overlay"), state.themeBg[0], state.themeBg[1], state.themeBg[2])
        GLES20.glUniform1f(GLES20.glGetUniformLocation(p, "u_time"), meshTime)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(p, "u_dtime"), ditherTime)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(p, "u_dist"), state.meshDistortion + smoothedPower * 0.62f)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(p, "u_swirl"), state.meshSwirl + smoothedMid * 0.38f)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(p, "u_px"), max(0.5f, state.ditheringSize - smoothedBass * state.ditheringSize * 0.34f))
        GLES20.glUniform1f(GLES20.glGetUniformLocation(p, "u_dopacity"), state.ditheringOpacity)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(p, "u_showmesh"), if (state.showMesh) 1f else 0f)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(p, "u_showdither"), if (state.showDither) 1f else 0f)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(p, "u_overlayop"), if (state.overlayEnabled) state.overlayOpacity else 0f)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(p, "u_sat"), 1.04f + smoothedMid * 0.34f)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(p, "u_bright"), 0.94f + smoothedPower * 0.16f)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(p, "u_scale"), 1.025f + smoothedPower * 0.018f)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(pos)
    }

    private fun drawCommon() {
        val q = quad ?: return
        val band = drive()
        val playing = state.playing
        smoothedPower += ((if (playing) band[5] else 0f) - smoothedPower) * 0.12f
        smoothedBass += ((if (playing) band[0] else 0f) - smoothedBass) * 0.16f

        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        val p = commonProgram
        GLES20.glUseProgram(p)
        val wantCover = state.useCoverColorBg && state.hasCover
        if (wantCover) ensureCoverTexture()
        val pos = GLES20.glGetAttribLocation(p, "a_pos")
        GLES20.glEnableVertexAttribArray(pos)
        GLES20.glVertexAttribPointer(pos, 2, GLES20.GL_FLOAT, false, 0, q)
        GLES20.glUniform2f(GLES20.glGetUniformLocation(p, "u_res"), width.toFloat(), height.toFloat())
        GLES20.glUniform3f(GLES20.glGetUniformLocation(p, "u_theme"), state.themeBg[0], state.themeBg[1], state.themeBg[2])
        GLES20.glUniform3f(GLES20.glGetUniformLocation(p, "u_ovprimary"), state.overlayPrimary[0], state.overlayPrimary[1], state.overlayPrimary[2])
        GLES20.glUniform3f(GLES20.glGetUniformLocation(p, "u_ovsecondary"), state.overlaySecondary[0], state.overlaySecondary[1], state.overlaySecondary[2])
        GLES20.glUniform1f(GLES20.glGetUniformLocation(p, "u_bgop"), if (state.useCoverColorBg) state.bgOpacity else 1f)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(p, "u_hascover"), if (wantCover && coverTexture != -1) 1f else 0f)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(p, "u_vignette"), if (state.vignette) 1f else 0f)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(p, "u_bass"), smoothedBass)
        if (wantCover && coverTexture != -1) {
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, coverTexture)
            GLES20.glUniform1i(GLES20.glGetUniformLocation(p, "u_cover"), 0)
        }
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(pos)
    }

    /** Uploads the cover (the host already keeps a small JPEG) as one tiny texture; its upscale is the blur. */
    private fun ensureCoverTexture() {
        val bytes = state.coverJpeg
        if (bytes == null || coverLoadedVersion == state.coverVersion) return
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > 96) sample *= 2
        val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample }) ?: return
        val small = Bitmap.createScaledBitmap(bitmap, max(8, bitmap.width / 2), max(8, bitmap.height / 2), true)
        if (coverTexture == -1) {
            val tex = IntArray(1)
            GLES20.glGenTextures(1, tex, 0)
            coverTexture = tex[0]
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, coverTexture)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        }
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, coverTexture)
        android.opengl.GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, small, 0)
        if (small !== bitmap) bitmap.recycle()
        coverLoadedVersion = state.coverVersion
    }

    private fun compileProgram(vertexSrc: String, fragmentSrc: String): Int {
        val vs = GLES20.glCreateShader(GLES20.GL_VERTEX_SHADER)
        GLES20.glShaderSource(vs, vertexSrc)
        GLES20.glCompileShader(vs)
        val fs = GLES20.glCreateShader(GLES20.GL_FRAGMENT_SHADER)
        GLES20.glShaderSource(fs, fragmentSrc)
        GLES20.glCompileShader(fs)
        val status = IntArray(1)
        GLES20.glGetShaderiv(vs, GLES20.GL_COMPILE_STATUS, status, 0)
        if (status[0] == 0) return -1
        GLES20.glGetShaderiv(fs, GLES20.GL_COMPILE_STATUS, status, 0)
        if (status[0] == 0) return -1
        val program = GLES20.glCreateProgram()
        GLES20.glAttachShader(program, vs)
        GLES20.glAttachShader(program, fs)
        GLES20.glLinkProgram(program)
        GLES20.glGetProgramiv(program, GLES20.GL_LINK_STATUS, status, 0)
        return if (status[0] == 0) -1 else program
    }

    private companion object {
        const val LATENT_VERTEX = """
            attribute vec2 a_pos;
            varying vec2 v_uv;
            void main() {
                v_uv = a_pos * 0.5 + 0.5;
                gl_Position = vec4(a_pos, 0.0, 1.0);
            }
        """

        // A colour-mesh approximation of Folia's latent background: six moving colour wells warped by
        // the same distortion/swirl values its uniforms carry, plus the 4x4 warp-dither and the theme
        // colour overlay, blended the way the web layers blend them (soft-light, then a normal mix).
        const val LATENT_FRAGMENT = """
            precision mediump float;
            varying vec2 v_uv;
            uniform vec2 u_res;
            uniform float u_time;
            uniform float u_dtime;
            uniform vec3 u_mesh[6];
            uniform vec3 u_dback;
            uniform vec3 u_dfront;
            uniform vec3 u_overlay;
            uniform float u_dist;
            uniform float u_swirl;
            uniform float u_px;
            uniform float u_dopacity;
            uniform float u_showmesh;
            uniform float u_showdither;
            uniform float u_overlayop;
            uniform float u_sat;
            uniform float u_bright;
            uniform float u_scale;

            float bayer(vec2 f) {
                float x = mod(f.x, 4.0);
                float y = mod(f.y, 4.0);
                float m2 = 2.0 * mod(x, 2.0) + 3.0 * mod(y, 2.0) - 4.0 * mod(x, 2.0) * mod(y, 2.0);
                float n2 = 2.0 * mod(floor(x / 2.0), 2.0) + 3.0 * mod(floor(y / 2.0), 2.0) - 4.0 * mod(floor(x / 2.0), 2.0) * mod(floor(y / 2.0), 2.0);
                return (4.0 * m2 + n2) / 16.0;
            }

            vec3 softLight(vec3 back, vec3 front, float alpha) {
                vec3 lt = back - (1.0 - 2.0 * front) * back * (1.0 - back);
                vec3 gt = back + (2.0 * front - 1.0) * (sqrt(max(back, vec3(0.0))) - back);
                vec3 d = mix(lt, gt, step(0.5, front));
                return mix(back, d, alpha);
            }

            void main() {
                vec2 uv = (v_uv - 0.5) / max(u_scale, 0.01) + 0.5;
                vec3 col = u_mesh[0];
                if (u_showmesh > 0.5) {
                    vec2 q = uv * 2.0 - 1.0;
                    float ang = u_swirl * (0.6 + 0.4 * sin(u_time * 0.7)) * length(q);
                    float ca = cos(ang);
                    float sa = sin(ang);
                    q = mat2(ca, -sa, sa, ca) * q;
                    vec3 acc = vec3(0.0);
                    float wsum = 0.0001;
                    for (int i = 0; i < 6; i++) {
                        float fi = float(i);
                        vec2 c = vec2(sin(u_time * 0.11 + fi * 1.05), cos(u_time * 0.09 + fi * 1.7)) * (0.35 + 0.45 * u_dist);
                        float d = distance(q * 1.2, c);
                        float w = exp(-d * d * 2.2);
                        acc += u_mesh[i] * w;
                        wsum += w;
                    }
                    col = acc / wsum;
                } else {
                    col = u_overlay;
                }
                if (u_showdither > 0.5) {
                    vec2 sp = uv * u_res;
                    vec2 cell = sp / max(u_px, 0.5);
                    vec2 wq = cell + vec2(sin(u_dtime * 0.6 + cell.y * 0.35), cos(u_dtime * 0.5 + cell.x * 0.35)) * 1.4;
                    float val = 0.5 + 0.5 * sin(wq.x * 0.7 + wq.y * 0.9 + u_dtime * 1.3);
                    float b = bayer(floor(mod(cell, 4096.0)));
                    float m = smoothstep(b - 0.08, b + 0.08, val);
                    vec3 dith = mix(u_dback, u_dfront, m);
                    float alpha = u_showmesh > 0.5 ? u_dopacity : 1.0;
                    col = softLight(col, dith, alpha);
                }
                float lum = dot(col, vec3(0.2126, 0.7152, 0.0722));
                col = mix(vec3(lum), col, u_sat) * u_bright;
                col = mix(col, u_overlay, u_overlayop);
                gl_FragColor = vec4(col, 1.0);
            }
        """

        const val COMMON_VERTEX = LATENT_VERTEX

        // Folia's "common" fluid background: the theme colour base, the blurred cover (the small
        // texture upscaled is the blur), the diagonal primary/secondary gradient in overlay blend,
        // and the vignette. Only used when the page says the geometric shapes are off.
        const val COMMON_FRAGMENT = """
            precision mediump float;
            varying vec2 v_uv;
            uniform vec2 u_res;
            uniform vec3 u_theme;
            uniform vec3 u_ovprimary;
            uniform vec3 u_ovsecondary;
            uniform float u_bgop;
            uniform float u_hascover;
            uniform float u_vignette;
            uniform float u_bass;
            uniform sampler2D u_cover;

            vec3 overlayBlend(vec3 back, vec3 src) {
                vec3 lt = 2.0 * back * src;
                vec3 gt = 1.0 - 2.0 * (1.0 - back) * (1.0 - src);
                return mix(lt, gt, step(0.5, back));
            }

            void main() {
                vec2 uv = v_uv;
                vec3 col = mix(vec3(0.0), u_theme, 0.8);
                float t = clamp(dot(uv - vec2(0.5), vec2(0.7071, 0.7071)) + 0.5, 0.0, 1.0);
                float alpha = 1.0 - abs(2.0 * t - 1.0);
                vec3 src = t < 0.5 ? u_ovprimary : u_ovsecondary;
                if (u_hascover > 0.5) {
                    vec3 cover = texture2D(u_cover, uv).rgb;
                    cover = mix(cover, overlayBlend(cover, src), alpha * 0.4);
                    col = mix(col, cover, 0.3 + u_bass * 0.05);
                    col = mix(col, u_theme, u_bgop);
                } else {
                    col = mix(col, u_theme, 1.0);
                    col = mix(col, overlayBlend(col, src), alpha * 0.4);
                }
                if (u_vignette > 0.5) {
                    float r = clamp(length(uv - vec2(0.5)) / 0.7071, 0.0, 1.0);
                    col *= 1.0 - 0.6 * smoothstep(0.4, 1.0, r);
                }
                gl_FragColor = vec4(col, 1.0);
            }
        """
    }
}

package com.ella.music.ui.vis

import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioManager
import androidx.compose.runtime.mutableLongStateOf
import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.UnstableApi
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Real-time drum/bass detection from the player's own PCM.
 *
 * A small [AudioProcessor] ([VisAudioTee]) sits in Halcyon's audio sink (added by PlaybackService,
 * in both the primary and the crossfade-secondary player). It passes every buffer through
 * untouched and, while the visualizer page is open, taps a mono mixdown into a ring. A detector
 * coroutine runs the same spectral-flux front end the offline analyzer uses ([FluxExtractor]) and
 * picks kick/snare/hat hits with Folia's own semantics (drumHitPicking.ts: bands <150 Hz, <4 kHz,
 * >6 kHz; the rise of a frame over its local base; strength as a share of the band's loud rises;
 * HIT_ONSET_FLOOR 0.15; MIN_HIT_GAP 0.09 s). The hits carry their player-clock time exactly,
 * because the tee's sample counter is re-anchored to the player position on every clock anchor.
 *
 * What the hits are used for:
 *  - live band levels feed [AudioDrive], replacing the android Visualizer (which needed the
 *    RECORD_AUDIO permission and lags the output), so no permission is needed;
 *  - each hit that matches an offline analysis hit of the same kind measures the offline-vs-real
 *    bias; the median of the recent differences corrects the offline (predictive) stream the page
 *    consumes, so the beat effects land where the real hits are;
 *  - hits the offline analysis missed stay unmatched and are appended to the drum list with an
 *    `until` marker (Folia's own streaming semantic, consumed by the drum-source beat effects).
 *
 * The tap sits before the sink buffer, so on Bluetooth the extras reach the page before they are
 * heard; on wired output they trail by roughly 100 ms (the offline-corrected stream carries the
 * timing there). Cost while the page is open: about 86 FFTs per second of 2048 points, well under
 * 1 % of one CPU core (~0.1 s CPU per minute of playback). With the page closed the tap only
 * copies its input through, and no analysis runs.
 */
internal object VisLiveAudio {
    data class Hit(val ms: Long, val kind: Byte, val strength: Float, val matched: Boolean = false)

    data class Snapshot(val playheadMs: Long = -1, val healthy: Boolean = false, val kicksPerSec: Float = 0f)

    /** Diagnostics for the Tune sheet. */
    @Volatile var diag: String = "live drums: idle"
        private set

    /** Set on every live kick; the calibration flash in the Tune sheet reads it. */
    val flashTick = mutableLongStateOf(0L)

    /** The measured offline-vs-real bias (ms): offline time + bias = real hit time. */
    @Volatile var biasMs: Long = 0
        private set

    @Volatile private var enabled = false
    @Volatile private var offline: BeatMap? = null
    @Volatile private var driveRef: AudioDrive? = null
    @Volatile private var latest = Snapshot()
    private val tees = ArrayList<VisAudioTee>()
    private val deltas = ArrayDeque<Long>()
    private val picker = VisLivePicker { hit -> onLiveHit(hit) }
    private var sessionJob: Job? = null

    fun registerTee(tee: VisAudioTee) {
        synchronized(tees) { if (!tees.contains(tee)) tees.add(tee) }
    }

    /** Page open/closed: the tap only taps while the page is open. */
    fun setEnabled(value: Boolean) {
        enabled = value
        if (!value) {
            diag = "live drums: idle"
            latest = Snapshot()
        }
    }

    /** Song change: fresh session state; the offline map is the bias reference. */
    fun resetForSong(key: String, map: BeatMap?) {
        synchronized(deltas) { deltas.clear() }
        biasMs = 0
        offline = map
        latest = Snapshot()
        picker.reset()
        resetDriveSmoothers()
    }

    fun setOffline(map: BeatMap?) {
        offline = map
    }

    /**
     * Re-anchors every tee's sample clock to the player position (audio ms, the analysis time
     * base). Called from the clock-anchor loop while the page is open.
     */
    fun reanchor(playerMs: Long) {
        synchronized(tees) { for (t in tees) t.reanchor(playerMs) }
    }

    /** Whether a tee is alive and producing PCM right now (bands then come from it, not Visualizer). */
    fun teeHealthy(): Boolean = latest.healthy

    /** The current detector snapshot for the beat sender. */
    fun snapshot(): Snapshot = latest

    /**
     * The device's typical output latency beyond the player clock, by output type. Bluetooth
     * stacks add codec and radio latency after the mixer clock the player position follows; wired
     * and built-in outputs add little. The Timing slider fine-tunes this per device.
     */
    fun defaultOutputLatencyMs(context: Context): Int {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return 25
        return runCatching {
            var best = 25
            for (d in am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)) {
                val ms = when (d.type) {
                    AudioDeviceInfo.TYPE_BLUETOOTH_A2DP,
                    AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> 190
                    AudioDeviceInfo.TYPE_BLE_HEADSET,
                    AudioDeviceInfo.TYPE_BLE_SPEAKER -> 170
                    AudioDeviceInfo.TYPE_USB_DEVICE,
                    AudioDeviceInfo.TYPE_USB_HEADSET,
                    AudioDeviceInfo.TYPE_USB_ACCESSORY -> 40
                    AudioDeviceInfo.TYPE_WIRED_HEADSET,
                    AudioDeviceInfo.TYPE_WIRED_HEADPHONES -> 35
                    AudioDeviceInfo.TYPE_HDMI,
                    AudioDeviceInfo.TYPE_HDMI_ARC -> 50
                    else -> 0
                }
                if (ms > best) best = ms
            }
            best
        }.getOrDefault(25)
    }

    /** Starts the detector for the open page. */
    fun startSession(drive: AudioDrive, positionProvider: () -> Long, scope: CoroutineScope, key: String, map: BeatMap?) {
        resetForSong(key, map)
        driveRef = drive
        sessionJob?.cancel()
        sessionJob = scope.launch(Dispatchers.Default) { detectorLoop(positionProvider) }
    }

    fun stopSession() {
        sessionJob?.cancel()
        sessionJob = null
        driveRef = null
        latest = Snapshot()
        diag = "live drums: idle"
    }

    internal fun enabled(): Boolean = enabled

    /** The live hits the sender appends (unmatched tee hits), oldest first. */
    fun pendingExtras(): List<Hit> = picker.pendingUnmatched()

    private suspend fun detectorLoop(positionProvider: () -> Long) {
        var flux: FluxExtractor? = null
        var fluxStartMs = -1L
        var fluxRate = 0
        var framesDone = 0L
        var hopMs = 11.6f
        var offsetMs = 34.8f
        var lastSelfAnchor = 0L
        while (isActive) {
            if (!enabled) {
                delay(200L)
                continue
            }
            val tee = pickTee()
            if (tee == null) {
                flux = null
                latest = Snapshot()
                delay(80L)
                continue
            }
            if (tee.takeFlush()) {
                flux = null
                picker.reset()
            }
            val rate = tee.sampleRate
            if (rate <= 0) { delay(40L); continue }
            if (flux == null || fluxRate != rate) {
                val created = FluxExtractor(rate) { all, low, mid, high, ma, ml, mm, mh ->
                    val tPeak = fluxStartMs + (framesDone * hopMs).toLong() + offsetMs.toLong()
                    framesDone += 1
                    for (hit in picker.onFrame(tPeak, low, mid, high)) onLiveHit(hit)
                    feedDrive(ma, ml, mm, mh)
                }
                flux = created
                fluxRate = rate
                fluxStartMs = -1L
                framesDone = 0
                hopMs = created.hopMs
                offsetMs = created.frameOffsetMs
                picker.setHopMs(hopMs)
            }
            val chunk = tee.take(4096)
            if (chunk == null) {
                delay(8L)
            } else {
                if (fluxStartMs < 0) fluxStartMs = tee.playerTimeAtFrames(chunk.first)
                for (s in chunk.second) flux.add(s)
                val playhead = tee.playerTimeMs()
                if (playhead > 0) {
                    latest = Snapshot(playheadMs = playhead, healthy = true, kicksPerSec = picker.recentKicksPerSec())
                    diag = String.format(
                        Locale.US,
                        "live drums: %.1f kicks/s, bias %+d ms, tap %+.0f ms ahead of the page",
                        picker.recentKicksPerSec(), biasMs,
                        (tee.framesTotal - tee.framesConsumed()) * 1000.0 / rate,
                    )
                }
            }
            val now = System.nanoTime()
            if (now - lastSelfAnchor > 2_000_000_000L) {
                lastSelfAnchor = now
                reanchor(positionProvider())
            }
            delay(2L)
        }
    }

    /** Whether a tee is alive and producing PCM right now. */
    private fun pickTee(): VisAudioTee? {
        val now = System.nanoTime()
        var best: VisAudioTee? = null
        var bestSize = 0
        synchronized(tees) {
            for (t in tees) {
                if (t.sampleRate <= 0) continue
                if (now - t.lastPushNanos > 3_000_000_000L) continue
                val size = t.pendingSize()
                if (size > bestSize) { bestSize = size; best = t }
            }
        }
        return best
    }

    // Live band levels into AudioDrive, with VisBands' attack/decay constants and a peak-following
    // normalizer, so the reactive visuals behave like they did under the Visualizer.
    private var peakAll = 1e-4f
    private var peakLow = 1e-4f
    private var peakMid = 1e-4f
    private var peakHigh = 1e-4f
    private var smLow = 0f
    private var smMid = 0f
    private var smVocal = 0f
    private var smHigh = 0f

    private fun resetDriveSmoothers() {
        peakAll = 1e-4f; peakLow = 1e-4f; peakMid = 1e-4f; peakHigh = 1e-4f
        smLow = 0f; smMid = 0f; smVocal = 0f; smHigh = 0f
    }

    private fun feedDrive(ma: Float, ml: Float, mm: Float, mh: Float) {
        val drive = driveRef ?: return
        peakAll = max(peakAll * 0.997f, ma).coerceAtLeast(1e-4f)
        peakLow = max(peakLow * 0.997f, ml).coerceAtLeast(1e-4f)
        peakMid = max(peakMid * 0.997f, mm).coerceAtLeast(1e-4f)
        peakHigh = max(peakHigh * 0.997f, mh).coerceAtLeast(1e-4f)
        val gate = 0.12f
        val nb = ((ml / peakLow) - gate).coerceIn(0f, 1f) / (1f - gate)
        val nm = ((mm / peakMid) - gate).coerceIn(0f, 1f) / (1f - gate)
        val nv = ((ma / peakAll) - gate).coerceIn(0f, 1f) / (1f - gate)
        val nt = ((mh / peakHigh) - gate).coerceIn(0f, 1f) / (1f - gate)
        smLow += (nb - smLow) * (if (nb > smLow) 0.65f else 0.18f)
        smMid += (nm - smMid) * (if (nm > smMid) 0.55f else 0.16f)
        smVocal += (nv - smVocal) * (if (nv > smVocal) 0.5f else 0.14f)
        smHigh += (nt - smHigh) * (if (nt > smHigh) 0.6f else 0.2f)
        drive.bass = smLow
        drive.mid = smMid
        drive.vocal = smVocal
        drive.treble = smHigh
        drive.hasLiveBands = true
    }

    /**
     * One detected hit: measures the offline-vs-real bias against a same-kind offline hit nearby,
     * drives the calibration flash and the native engine's kick impulse on kicks. The picker keeps
     * the hit and its matched flag (the sender reads the unmatched ones as extras).
     */
    private fun onLiveHit(hit: Hit) {
        if (hit.kind == 0.toByte()) {
            flashTick.value = System.nanoTime() / 1_000_000L
            driveRef?.let { d -> d.liveKickImpulse = max(d.liveKickImpulse, hit.strength.coerceIn(0.35f, 1f)) }
        }
        val map = offline ?: return
        val tol = 120L + abs(biasMs)
        val best = if (hit.kind == 0.toByte()) {
            nearestIn(map.kicksMs, hit.ms - biasMs, tol)
        } else {
            var found = Long.MAX_VALUE
            for (i in map.drumMs.indices) {
                if (map.drumKinds[i] == hit.kind) {
                    val d = hit.ms - biasMs - map.drumMs[i]
                    if (abs(d) <= tol && abs(d) < abs(found)) found = d
                }
            }
            found
        }
        if (best != Long.MAX_VALUE) {
            picker.markHit(hit)
            synchronized(deltas) {
                deltas.addLast(best)
                while (deltas.size > 32) deltas.removeFirst()
                biasMs = median(deltas)
            }
        }
    }

    private fun nearestIn(sorted: IntArray, target: Long, tol: Long): Long {
        var lo = 0
        var hi = sorted.size - 1
        var best = Long.MAX_VALUE
        while (lo <= hi) {
            val mid = (lo + hi) ushr 1
            val d = target - sorted[mid]
            if (abs(d) <= tol && abs(d) < abs(best)) best = d
            when {
                d > 0 -> lo = mid + 1
                d < 0 -> hi = mid - 1
                else -> break
            }
        }
        return best
    }

    private fun median(values: ArrayDeque<Long>): Long {
        if (values.isEmpty()) return 0
        return values.toMutableList().sorted()[values.size / 2]
    }
}

/**
 * The tap itself. Passes audio through untouched (the same alias-safe pattern
 * WaveformLevelAudioProcessor uses) and, while the page is open, taps a mono mixdown into a ring
 * whose sample counter maps to player time through anchors.
 */
@UnstableApi
internal class VisAudioTee : BaseAudioProcessor() {

    @Volatile var sampleRate = 0
        private set
    @Volatile var framesTotal = 0L
        private set
    @Volatile var lastPushNanos = 0L
        private set
    private var anchorPlayerMs = -1L
    private var anchorFrames = 0L
    private var flushed = false
    private var encoding = C.ENCODING_INVALID
    private var channels = 0
    private var scratch = FloatArray(4096)
    private val ring = FloatArray(2 * 48000)
    private var ringHead = 0
    private var ringSize = 0
    private val lock = Any()
    private var aliasCopy = ByteArray(0)

    init {
        VisLiveAudio.registerTee(this)
    }

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        encoding = inputAudioFormat.encoding
        channels = inputAudioFormat.channelCount
        sampleRate = inputAudioFormat.sampleRate
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        // BaseAudioProcessor may hand back the very ByteBuffer instance a previous pass returned;
        // copying through a scratch array avoids the "The source buffer is this buffer" alias
        // error (see WaveformLevelAudioProcessor, which documents the same trap).
        val input = inputBuffer.duplicate()
        val byteCount = input.remaining()
        if (VisLiveAudio.enabled() && channels > 0 && sampleRate > 0) {
            val mono = decodeMono(input, encoding, channels)
            if (mono.isNotEmpty()) push(mono)
        }
        val output = replaceOutputBuffer(byteCount)
        if (output === inputBuffer) {
            if (aliasCopy.size < byteCount) aliasCopy = ByteArray(byteCount)
            input.get(aliasCopy, 0, byteCount)
            output.put(aliasCopy, 0, byteCount)
        } else {
            output.put(input)
        }
        inputBuffer.position(inputBuffer.limit())
        output.flip()
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onFlush() {
        synchronized(lock) {
            ringSize = 0
            ringHead = 0
            framesTotal = 0
            anchorFrames = 0
            anchorPlayerMs = -1
            flushed = true
        }
    }

    override fun onReset() {
        synchronized(lock) {
            ringSize = 0
            framesTotal = 0
            anchorFrames = 0
            anchorPlayerMs = -1
        }
        encoding = C.ENCODING_INVALID
        sampleRate = 0
    }

    private fun push(mono: FloatArray) {
        synchronized(lock) {
            for (s in mono) {
                ring[ringHead] = s
                ringHead = (ringHead + 1) % ring.size
                if (ringSize < ring.size) ringSize++
            }
            framesTotal += mono.size
            lastPushNanos = System.nanoTime()
        }
    }

    fun pendingSize(): Int = synchronized(lock) { ringSize }

    fun framesConsumed(): Long = synchronized(lock) { framesTotal - ringSize }

    /** Player time (audio ms) of the sample at consumed-frame index [at]; -1 before the first anchor. */
    fun playerTimeAtFrames(at: Long): Long = synchronized(lock) {
        if (anchorPlayerMs < 0 || sampleRate <= 0) -1L
        else anchorPlayerMs + ((at - anchorFrames) * 1000.0 / sampleRate).toLong()
    }

    fun playerTimeMs(): Long = playerTimeAtFrames(framesTotal)

    fun reanchor(playerMs: Long) {
        synchronized(lock) {
            if (framesTotal > 0) {
                anchorPlayerMs = playerMs
                anchorFrames = framesTotal
            }
        }
    }

    /** Consumes up to [max] mono samples: (consumed-frame index of the first sample, samples). */
    fun take(max: Int): Pair<Long, FloatArray>? = synchronized(lock) {
        if (ringSize == 0) return@synchronized null
        val n = min(max, ringSize)
        val out = FloatArray(n)
        var start = (ringHead - ringSize + ring.size) % ring.size
        for (i in 0 until n) {
            out[i] = ring[start]
            start = (start + 1) % ring.size
        }
        val consumedBefore = framesTotal - ringSize
        ringSize -= n
        consumedBefore to out
    }

    /** One-shot flush flag the detector polls (a seek resets the sample clock). */
    fun takeFlush(): Boolean = synchronized(lock) {
        val was = flushed
        flushed = false
        was
    }

    /** Downmixes the buffer to mono floats in [-1, 1]; one producer thread, scratch reused. */
    private fun decodeMono(buffer: ByteBuffer, encoding: Int, channels: Int): FloatArray {
        val dup = buffer.duplicate().order(ByteOrder.LITTLE_ENDIAN)
        val bytesPerFrame = when (encoding) {
            C.ENCODING_PCM_FLOAT, C.ENCODING_PCM_32BIT -> 4
            C.ENCODING_PCM_24BIT -> 3
            C.ENCODING_PCM_16BIT -> 2
            C.ENCODING_PCM_8BIT -> 1
            else -> 0
        }
        if (bytesPerFrame == 0) return FloatArray(0)
        val frames = dup.remaining() / (bytesPerFrame * channels)
        if (frames <= 0) return FloatArray(0)
        if (scratch.size < frames) scratch = FloatArray(max(frames, 4096))
        when (encoding) {
            C.ENCODING_PCM_FLOAT -> {
                var i = 0
                while (i < frames) {
                    var s = 0f
                    for (c in 0 until channels) s += dup.float
                    scratch[i] = s / channels
                    i++
                }
            }
            C.ENCODING_PCM_16BIT -> {
                var i = 0
                while (i < frames) {
                    var s = 0
                    for (c in 0 until channels) s += dup.short.toInt()
                    scratch[i] = s / (32768f * channels)
                    i++
                }
            }
            C.ENCODING_PCM_24BIT -> {
                var i = 0
                while (i < frames) {
                    var s = 0
                    for (c in 0 until channels) {
                        val raw = (dup.get().toInt() and 0xff) or ((dup.get().toInt() and 0xff) shl 8) or (dup.get().toInt() shl 16)
                        s += raw
                    }
                    scratch[i] = s / (8_388_608f * channels)
                    i++
                }
            }
            C.ENCODING_PCM_32BIT -> {
                var i = 0
                while (i < frames) {
                    var s = 0L
                    for (c in 0 until channels) s += dup.int.toLong()
                    scratch[i] = (s / channels).toFloat() / 2_147_483_648f
                    i++
                }
            }
            else -> {
                var i = 0
                while (i < frames) {
                    var s = 0
                    for (c in 0 until channels) s += (dup.get().toInt() and 0xff) - 128
                    scratch[i] = s / (128f * channels)
                    i++
                }
            }
        }
        return scratch.copyOf(frames)
    }
}

/**
 * The online pick: Folia's drumHitPicking.ts semantics on the streaming flux. Per band the rise
 * (the peak over [f-1, f+2] minus the base over [f-6, f-2]), normalized by the band's loud rises
 * over a recent window (the HIT_TOP share); a hit where the largest band share crosses
 * HIT_ONSET_FLOOR (0.15) as a local maximum over +-3 frames, MIN_HIT_GAP (0.09 s) apart, filed
 * under the band that rose most. A hit is decided five flux frames (~58 ms) after its frame, which
 * keeps Folia's "the next peak wins" behaviour intact; the returned timestamp is still the hit
 * frame's own peak time.
 */
internal class VisLivePicker(private val onHit: (VisLiveAudio.Hit) -> Unit) {

    private val ringFrames = 768
    private val flux = Array(3) { FloatArray(ringFrames) }
    private val rise = Array(3) { FloatArray(ringFrames) }
    private var head = 0          // ring index the next frame is written to
    private var count = 0         // absolute frame number the next write gets
    private val pending = ArrayDeque<VisLiveAudio.Hit>()
    private var lastHitFrame = IntArray(3) { Int.MIN_VALUE / 2 }
    private var topCache = FloatArray(3) { 1f }
    private var sinceTop = Int.MAX_VALUE
    private val kickTimes = ArrayDeque<Long>()
    private var hopMs = 11.6f

    fun reset() {
        synchronized(pending) { pending.clear() }
        synchronized(kickTimes) { kickTimes.clear() }
        head = 0
        count = 0
        java.util.Arrays.fill(lastHitFrame, Int.MIN_VALUE / 2)
        topCache = FloatArray(3) { 1f }
        sinceTop = Int.MAX_VALUE
    }

    /** Lets the detector pass the real hop time once per extractor. */
    fun setHopMs(ms: Float) { hopMs = ms }

    /** Called per completed flux frame with the frame's peak time in player ms; returns new hits. */
    fun onFrame(tPeakMs: Long, low: Float, mid: Float, high: Float): List<VisLiveAudio.Hit> {
        decided.clear()
        val values = floatArrayOf(low, mid, high)
        for (b in 0..2) flux[b][head] = values[b]
        // The rise of the frame two back becomes computable now (it looks two frames ahead).
        val g = count - 2
        // Warm-up: the HIT_TOP normaliser needs a few seconds of rises before shares mean anything
        // (Folia normalises over the whole track; online the window grows for the first ~3 s).
        if (count >= 8 && count < 256) sinceTop = Int.MAX_VALUE
        if (count >= 256 && g >= 0) {
            for (b in 0..2) rise[b][idx(g)] = riseAt(b, g)
            sinceTop++
            if (sinceTop >= 8) { sinceTop = 0; recomputeTop() }
            // Decide the hit five frames back: its +-3 rise neighbourhood is all in by now.
            val h = g - 3
            if (h >= 0) pickAt(h, tPeakMs - (5 * hopMs).toLong())
        }
        head = (head + 1) % ringFrames
        count++
        return decided
    }

    private val decided = ArrayList<VisLiveAudio.Hit>(4)

    private fun idx(f: Int): Int {
        val m = f % ringFrames
        return if (m < 0) m + ringFrames else m
    }

    private fun valueAt(b: Int, f: Int): Float = flux[b][idx(f)]

    private fun riseAt(b: Int, f: Int): Float {
        var peak = 0f
        for (at in f - 1..f + 2) peak = max(peak, valueAt(b, at))
        var base = 0f
        var n = 0
        for (at in f - 6..f - 2) { base += valueAt(b, at); n++ }
        return max(0f, peak - base / max(1, n))
    }

    private fun recomputeTop() {
        for (b in 0..2) {
            val rises = ArrayList<Float>(256)
            for (i in 0 until min(count, ringFrames)) {
                val v = rise[b][idx(count - 1 - i)]
                if (v > 0f) rises.add(v)
            }
            if (rises.size >= 8) {
                rises.sort()
                topCache[b] = max(1e-6f, rises[Math.min(rises.size - 1, (rises.size * 0.99f).toInt())])
            }
        }
    }

    /** The per-frame top share (max over the bands' own normalizations) at an absolute frame. */
    private fun topShareAt(f: Int): Float {
        var top = 0f
        for (b in 0..2) {
            val share = rise[b][idx(f)] / topCache[b]
            if (share > top) top = share
        }
        return top
    }

    private fun pickAt(f: Int, tPeakMs: Long) {
        var top = 0f
        var kind = 0
        for (b in 0..2) {
            val share = rise[b][idx(f)] / topCache[b]
            if (share > top) { top = share; kind = b }
        }
        if (top < 0.15f) return
        for (at in f - 3..f + 3) {
            if (at == f) continue
            if (topShareAt(at) > top) return
        }
        if (f - lastHitFrame[kind] < 8) return
        lastHitFrame[kind] = f
        val hit = VisLiveAudio.Hit(tPeakMs.coerceAtLeast(0L), kind.toByte(), top.coerceIn(0f, 1f))
        synchronized(pending) {
            pending.addLast(hit)
            while (pending.size > 256) pending.removeFirst()
        }
        if (kind == 0) {
            synchronized(kickTimes) {
                kickTimes.addLast(tPeakMs)
                while (kickTimes.size > 64) kickTimes.removeFirst()
            }
        }
        decided.add(hit)
        onHit(hit)
    }

    fun pendingUnmatched(): List<VisLiveAudio.Hit> = synchronized(pending) {
        pending.filter { !it.matched }
    }

    fun markHit(hit: VisLiveAudio.Hit) {
        synchronized(pending) {
            for (i in pending.indices) {
                val h = pending.elementAt(i)
                if (h.ms == hit.ms && h.kind == hit.kind) {
                    pending.removeAt(i)
                    pending.addLast(VisLiveAudio.Hit(h.ms, h.kind, h.strength, matched = true))
                    return
                }
            }
        }
    }

    fun recentKicksPerSec(): Float = synchronized(kickTimes) {
        if (kickTimes.size < 2) return@synchronized 0f
        val span = (kickTimes.last() - kickTimes.first()).coerceAtLeast(1L)
        (kickTimes.size - 1) * 1000f / span
    }
}

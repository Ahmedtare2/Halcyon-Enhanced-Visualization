package com.ella.music.ui.vis

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.UnstableApi
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Pass-through Media3 [AudioProcessor] that peeks at decoded PCM (aligned to the playback clock)
 * and picks kick / snare / hat onsets in real time. Audio is never modified — same pattern as
 * Halcyon's [com.ella.music.player.WaveformLevelAudioProcessor].
 *
 * Wired into [com.ella.music.player.EllaRenderersFactory] via apply.py so every sink path (AudioTrack
 * and Oboe) sees it. No RECORD_AUDIO required; does not affect gapless / ReplayGain / FFmpeg.
 *
 * Unverified on device in this sandbox (no Android SDK).
 */
@UnstableApi
internal class VisPcmTap : BaseAudioProcessor() {

    private var encoding: Int = C.ENCODING_INVALID
    private var sampleRate: Int = 44_100
    private var channelCount: Int = 2
    private var aliasCopyBuffer = ByteArray(0)

    private var framesSinceFlush = 0L
    private val flux = LiveFlux(2_048, 512)

    /** Audio-position (ms) at the last flush / stream start; set from the player. */
    private val basePositionMs = AtomicLong(0)

    /** When false, analysis is idle (visualizer closed) — still pass-through. */
    private val enabled = AtomicBoolean(false)

    private val latestHits = AtomicReference(LiveHits.EMPTY)

    fun setEnabled(on: Boolean) {
        enabled.set(on)
        if (!on) latestHits.set(LiveHits.EMPTY)
    }

    fun setBasePositionMs(ms: Long) {
        basePositionMs.set(ms)
        framesSinceFlush = 0
        flux.reset()
    }

    fun snapshotHits(): LiveHits = latestHits.get()

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val input = inputBuffer.duplicate()
        val byteCount = input.remaining()
        if (enabled.get() && byteCount > 0) {
            analyse(input.duplicate().order(ByteOrder.nativeOrder()))
        }
        val output = replaceOutputBuffer(byteCount)
        if (output === inputBuffer) {
            if (aliasCopyBuffer.size < byteCount) aliasCopyBuffer = ByteArray(byteCount)
            input.get(aliasCopyBuffer, 0, byteCount)
            output.put(aliasCopyBuffer, 0, byteCount)
        } else {
            output.put(input)
        }
        inputBuffer.position(inputBuffer.limit())
        output.flip()
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onFlush() {
        encoding = inputAudioFormat.encoding
        sampleRate = inputAudioFormat.sampleRate.coerceAtLeast(8_000)
        channelCount = inputAudioFormat.channelCount.coerceAtLeast(1)
        framesSinceFlush = 0
        flux.reset()
        flux.configure(sampleRate)
    }

    override fun onReset() {
        framesSinceFlush = 0
        flux.reset()
        encoding = C.ENCODING_INVALID
        aliasCopyBuffer = ByteArray(0)
        latestHits.set(LiveHits.EMPTY)
    }

    private fun analyse(buf: ByteBuffer) {
        val ch = channelCount
        val enc = encoding
        var frames = 0
        when (enc) {
            C.ENCODING_PCM_FLOAT -> {
                while (buf.remaining() >= 4 * ch) {
                    var s = 0f
                    for (c in 0 until ch) s += buf.float
                    flux.add(s / ch)
                    frames++
                }
            }
            C.ENCODING_PCM_16BIT -> {
                while (buf.remaining() >= 2 * ch) {
                    var s = 0
                    for (c in 0 until ch) s += buf.short.toInt()
                    flux.add(s / (32768f * ch))
                    frames++
                }
            }
            else -> return // unsupported encodings: skip analysis, audio still passes
        }
        framesSinceFlush += frames
        val hits = flux.drainHits(basePositionMs.get() + framesSinceFlush * 1000L / sampleRate)
        if (hits.timesMs.isNotEmpty()) {
            val prev = latestHits.get()
            latestHits.set(prev.merge(hits, keepMs = 8_000))
        }
    }

    companion object {
        /** Single instance so the visualizer and the renderers factory share state. */
        val instance: VisPcmTap by lazy { VisPcmTap() }
    }
}

/** Recent live drum hits in audio time (ms). kinds: 0 kick, 1 snare, 2 hat. */
internal class LiveHits(
    val timesMs: IntArray,
    val kinds: ByteArray,
    val strengths: FloatArray,
) {
    fun merge(more: LiveHits, keepMs: Int): LiveHits {
        if (more.timesMs.isEmpty()) return this
        if (timesMs.isEmpty()) return more
        val cutoff = more.timesMs.last() - keepMs
        val kept = timesMs.indices.filter { timesMs[it] >= cutoff }
        val n = kept.size + more.timesMs.size
        val t = IntArray(n)
        val k = ByteArray(n)
        val s = FloatArray(n)
        var w = 0
        for (i in kept) {
            t[w] = timesMs[i]; k[w] = kinds[i]; s[w] = strengths[i]; w++
        }
        for (i in more.timesMs.indices) {
            t[w] = more.timesMs[i]; k[w] = more.kinds[i]; s[w] = more.strengths[i]; w++
        }
        return LiveHits(t, k, s)
    }

    companion object {
        val EMPTY = LiveHits(IntArray(0), ByteArray(0), FloatArray(0))
    }
}

/**
 * Lightweight real-time spectral flux for three drum bands (Folia: kick <150 Hz, snare <4 kHz,
 * hat >6 kHz). Uses a short FFT hop so onsets land within ~10–15 ms of the true transient.
 */
private class LiveFlux(private val n: Int, private val hop: Int) {
    private val ring = FloatArray(n)
    private var pos = 0
    private var count = 0
    private var filled = 0
    private val window = FloatArray(n) { i -> (0.5 - 0.5 * kotlin.math.cos(2.0 * Math.PI * i / (n - 1))).toFloat() }
    private val fft = Fft(n)
    private val re = FloatArray(n)
    private val im = FloatArray(n)
    private val prev = FloatArray(n / 2)
    private var sampleRate = 44_100
    private var hopMs = hop * 1000f / 44_100f
    private var frameOffsetMs = n * 0.5f * 1000f / 44_100f // centre of window (less lag than 0.75·N)
    private var kLowMin = 1
    private var kLowMax = 8
    private var kMidMax = 180
    private var kHighMin = 270
    private var kHighMax = 500
    private var frameIndex = 0
    private val pending = ArrayList<Hit>(8)

    // Adaptive thresholds
    private var meanL = 0.01f
    private var meanM = 0.01f
    private var meanH = 0.01f
    private var lastKickFrame = -100
    private var lastSnareFrame = -100
    private var lastHatFrame = -100
    private val minGapFrames: Int get() = max(2, (90f / hopMs).toInt()) // Folia MIN_HIT_GAP ≈ 0.09 s

    fun configure(sr: Int) {
        sampleRate = sr
        hopMs = hop * 1000f / sr
        frameOffsetMs = n * 0.5f * 1000f / sr
        val binHz = sr.toDouble() / n
        kLowMin = max(1, (30.0 / binHz).toInt())
        kLowMax = max(kLowMin + 1, (150.0 / binHz).toInt())
        kMidMax = min(n / 2 - 1, (4000.0 / binHz).toInt())
        kHighMin = (6000.0 / binHz).toInt()
        kHighMax = min(n / 2 - 1, (12000.0 / binHz).toInt())
    }

    fun reset() {
        pos = 0; count = 0; filled = 0; frameIndex = 0
        prev.fill(0f); meanL = 0.01f; meanM = 0.01f; meanH = 0.01f
        lastKickFrame = -100; lastSnareFrame = -100; lastHatFrame = -100
        pending.clear()
    }

    fun add(x: Float) {
        ring[pos] = x
        pos = (pos + 1) % n
        if (filled < n) filled++
        count++
        if (count >= hop && filled >= n) {
            count = 0
            frame()
        }
    }

    fun drainHits(audioTimeAtRingEndMs: Long): LiveHits {
        if (pending.isEmpty()) return LiveHits.EMPTY
        // Ring end is ~now; a frame at index f ended at audioTime - (frameIndex-f)*hopMs roughly.
        // Each pending hit stores its frame index; convert with centre offset.
        val t = IntArray(pending.size)
        val k = ByteArray(pending.size)
        val s = FloatArray(pending.size)
        for (i in pending.indices) {
            val h = pending[i]
            val ageFrames = frameIndex - h.frame
            val timeMs = (audioTimeAtRingEndMs - ageFrames * hopMs + frameOffsetMs - n * 0.5f * 1000f / sampleRate).toInt()
            t[i] = timeMs
            k[i] = h.kind
            s[i] = h.strength
        }
        pending.clear()
        return LiveHits(t, k, s)
    }

    private fun frame() {
        for (i in 0 until n) {
            re[i] = ring[(pos + i) % n] * window[i]
            im[i] = 0f
        }
        fft.transform(re, im)
        var fl = 0f; var fm = 0f; var fh = 0f
        val scale = 1f / (n / 8f)
        val top = max(kMidMax, kHighMax)
        for (bin in 1..top) {
            val mag = sqrt(re[bin] * re[bin] + im[bin] * im[bin]) * scale
            val lm = ln(1f + 30f * mag)
            val d = lm - prev[bin]
            if (d > 0f) {
                if (bin in kLowMin..kLowMax) fl += d
                else if (bin in (kLowMax + 1)..kMidMax) fm += d
                if (bin in kHighMin..kHighMax) fh += d
            }
            prev[bin] = lm
        }
        meanL = meanL * 0.98f + fl * 0.02f
        meanM = meanM * 0.98f + fm * 0.02f
        meanH = meanH * 0.98f + fh * 0.02f
        // Folia-ish onset floor ~0.15 of a strong local peak; we use mean * k.
        maybeHit(fl, meanL, 2.2f, 0, frameIndex, minGapFrames) { lastKickFrame = it }
        maybeHit(fm, meanM, 2.6f, 1, frameIndex, minGapFrames) { lastSnareFrame = it }
        maybeHit(fh, meanH, 2.8f, 2, frameIndex, minGapFrames) { lastHatFrame = it }
        frameIndex++
    }

    private fun maybeHit(v: Float, mean: Float, k: Float, kind: Int, frame: Int, gap: Int, mark: (Int) -> Unit) {
        val thr = mean * k + 1e-4f
        if (v < thr) return
        val last = when (kind) {
            0 -> lastKickFrame
            1 -> lastSnareFrame
            else -> lastHatFrame
        }
        if (frame - last < gap) return
        // Strength normalised like Folia HIT_TOP share, clamped.
        val strength = (0.25f + 0.75f * (v / (mean * 4f + 1e-4f)).coerceIn(0f, 1f))
        if (strength < 0.15f) return // HIT_ONSET_FLOOR
        pending.add(Hit(frame, kind.toByte(), strength))
        mark(frame)
    }

    private class Hit(val frame: Int, val kind: Byte, val strength: Float)
}

import type { Line, Word } from '../types';

// src/halcyon/arabic.ts
// Arabic for styles that lay text out strictly left to right, one glyph at a time.
// Every Arabic word is turned into Arabic Presentation Forms (the joined shapes are chosen here, so
// a letter drawn on its own still looks right), written in visual order (right-most letter last)
// and wrapped in a left-to-right override so no text engine reorders it again. The words of the
// line are put in visual order too. Each word keeps its own timing.

const LRO = '\u202D';
const PDF = '\u202C';

// [isolated, final, initial, medial] - 0 when the form does not exist.
const FORMS: Record<number, [number, number, number, number]> = {
    0x0621: [0xFE80, 0, 0, 0],
    0x0622: [0xFE81, 0xFE82, 0, 0],
    0x0623: [0xFE83, 0xFE84, 0, 0],
    0x0624: [0xFE85, 0xFE86, 0, 0],
    0x0625: [0xFE87, 0xFE88, 0, 0],
    0x0626: [0xFE89, 0xFE8A, 0xFE8B, 0xFE8C],
    0x0627: [0xFE8D, 0xFE8E, 0, 0],
    0x0628: [0xFE8F, 0xFE90, 0xFE91, 0xFE92],
    0x0629: [0xFE93, 0xFE94, 0, 0],
    0x062A: [0xFE95, 0xFE96, 0xFE97, 0xFE98],
    0x062B: [0xFE99, 0xFE9A, 0xFE9B, 0xFE9C],
    0x062C: [0xFE9D, 0xFE9E, 0xFE9F, 0xFEA0],
    0x062D: [0xFEA1, 0xFEA2, 0xFEA3, 0xFEA4],
    0x062E: [0xFEA5, 0xFEA6, 0xFEA7, 0xFEA8],
    0x062F: [0xFEA9, 0xFEAA, 0, 0],
    0x0630: [0xFEAB, 0xFEAC, 0, 0],
    0x0631: [0xFEAD, 0xFEAE, 0, 0],
    0x0632: [0xFEAF, 0xFEB0, 0, 0],
    0x0633: [0xFEB1, 0xFEB2, 0xFEB3, 0xFEB4],
    0x0634: [0xFEB5, 0xFEB6, 0xFEB7, 0xFEB8],
    0x0635: [0xFEB9, 0xFEBA, 0xFEBB, 0xFEBC],
    0x0636: [0xFEBD, 0xFEBE, 0xFEBF, 0xFEC0],
    0x0637: [0xFEC1, 0xFEC2, 0xFEC3, 0xFEC4],
    0x0638: [0xFEC5, 0xFEC6, 0xFEC7, 0xFEC8],
    0x0639: [0xFEC9, 0xFECA, 0xFECB, 0xFECC],
    0x063A: [0xFECD, 0xFECE, 0xFECF, 0xFED0],
    0x0641: [0xFED1, 0xFED2, 0xFED3, 0xFED4],
    0x0642: [0xFED5, 0xFED6, 0xFED7, 0xFED8],
    0x0643: [0xFED9, 0xFEDA, 0xFEDB, 0xFEDC],
    0x0644: [0xFEDD, 0xFEDE, 0xFEDF, 0xFEE0],
    0x0645: [0xFEE1, 0xFEE2, 0xFEE3, 0xFEE4],
    0x0646: [0xFEE5, 0xFEE6, 0xFEE7, 0xFEE8],
    0x0647: [0xFEE9, 0xFEEA, 0xFEEB, 0xFEEC],
    0x0648: [0xFEED, 0xFEEE, 0, 0],
    0x0649: [0xFEEF, 0xFEF0, 0xFEF3, 0xFEF4],
    0x064A: [0xFEF1, 0xFEF2, 0xFEF3, 0xFEF4],
};

// lam + alef ligatures: [isolated, final]
const LAM_ALEF: Record<number, [number, number]> = {
    0x0622: [0xFEF5, 0xFEF6],
    0x0623: [0xFEF7, 0xFEF8],
    0x0625: [0xFEF9, 0xFEFA],
    0x0627: [0xFEFB, 0xFEFC],
};

const TATWEEL = 0x0640;
const ARABIC_LETTER = /[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF]/;
const LATIN_LETTER = /[A-Za-z]/;
const DIGIT = /[0-9\u0660-\u0669]/;

const isMark = (cp: number) =>
    (cp >= 0x064B && cp <= 0x065F) || cp === 0x0670 || (cp >= 0x06D6 && cp <= 0x06ED) || cp === 0x200C || cp === 0x200D;

/** Shapes Arabic text into presentation-form clusters, in logical order. Marks are dropped. */
export const shapeArabic = (text: string): string[] => {
    const items: { ch: string; cp: number }[] = [];
    for (const ch of Array.from(text)) {
        const cp = ch.codePointAt(0) ?? 0;
        if (isMark(cp)) continue;
        items.push({ ch, cp });
    }
    const joinsFromRight = (cp: number | undefined) =>
        cp !== undefined && (cp === TATWEEL || (FORMS[cp] !== undefined && FORMS[cp][1] !== 0));
    const out: string[] = [];
    let prevConnects = false;
    for (let i = 0; i < items.length; i += 1) {
        const { ch, cp } = items[i];
        const forms = FORMS[cp];
        if (forms) {
            const next = items[i + 1]?.cp;
            if (cp === 0x0644 && next !== undefined && LAM_ALEF[next]) {
                const lig = LAM_ALEF[next];
                out.push(String.fromCodePoint(prevConnects ? lig[1] : lig[0]));
                prevConnects = false;
                i += 1;
                continue;
            }
            const connectsNext = forms[2] !== 0 && joinsFromRight(next);
            let glyph: number;
            if (prevConnects) glyph = connectsNext ? (forms[3] || forms[1]) : (forms[1] || forms[0]);
            else glyph = connectsNext ? forms[2] : forms[0];
            out.push(String.fromCodePoint(glyph || forms[0]));
            prevConnects = connectsNext;
        } else if (cp === TATWEEL) {
            out.push(ch);
            prevConnects = true;
        } else {
            out.push(ch);
            prevConnects = false;
        }
    }
    // Digit runs stay in their own order.
    const clusters: string[] = [];
    for (const glyph of out) {
        const last = clusters[clusters.length - 1];
        if (last !== undefined && DIGIT.test(glyph) && DIGIT.test(last[last.length - 1])) clusters[clusters.length - 1] = last + glyph;
        else clusters.push(glyph);
    }
    return clusters;
};

interface Prepared { word: Word; clusters: string[] | null }

const prepareWord = (word: Word): Prepared => {
    const body = word.text.trim();
    if (!body || !ARABIC_LETTER.test(body) || LATIN_LETTER.test(body)) return { word: { ...word, text: body || word.text }, clusters: null };
    return { word, clusters: shapeArabic(body).reverse() };
};

/** The line with its words in visual order and Arabic words as visual-order presentation forms. */
export const arabicVisualLine = (line: Line): Line => {
    const prepared = line.words.map(prepareWord).reverse();
    const words: Word[] = prepared.map((item, index) => {
        const last = index === prepared.length - 1;
        const gap = last ? '' : ' ';
        if (!item.clusters) {
            return { ...item.word, text: item.word.text.trim() + gap };
        }
        const clusters = item.clusters;
        const count = clusters.length;
        const span = Math.max(item.word.endTime - item.word.startTime, 0);
        const slice = span / count;
        // The right-most letter is the first one sung, so it gets the earliest slot.
        const syllables = clusters.map((cluster, k) => {
            const slot = count - 1 - k;
            return {
                text: (k === 0 ? LRO : '') + cluster + (k === count - 1 ? PDF : ''),
                startTime: item.word.startTime + slice * slot,
                endTime: item.word.startTime + slice * (slot + 1),
            };
        });
        return {
            ...item.word,
            text: LRO + clusters.join('') + PDF + gap,
            syllables: syllables as Word['syllables'],
        };
    });
    return { ...line, words, fullText: words.map(word => word.text).join('') };
};

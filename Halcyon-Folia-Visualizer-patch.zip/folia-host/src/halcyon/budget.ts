// src/halcyon/budget.ts
// Pure numbers only: no imports, so the Folia background files that read them cannot form an import cycle.
// GPU budget of the Halcyon host page. The Android app loads the page with ?profile=normal|battery
// (the Battery chip in Tune sets "battery"); changing it reloads the page, so these values are
// read once. Nothing here changes how a style or background is drawn at normal quality: the
// "normal" numbers only cap the work that is hidden behind blur and upscaling.

export type HalcyonProfile = 'normal' | 'battery';

const query = new URLSearchParams(typeof location !== 'undefined' ? location.search : '');

export const HALCYON_PROFILE: HalcyonProfile = query.get('profile') === 'battery' ? 'battery' : 'normal';

/**
 * Pixels the Latent background's mesh gradient is allowed to draw. The mesh is a smooth, slowly
 * moving colour field (no fine detail), so it is drawn small and stretched by the compositor.
 * Folia's own limit is 1280 x 720; at the page's render scale that was never reached on a phone.
 */
export const LATENT_MESH_MAX_PIXELS = HALCYON_PROFILE === 'battery' ? 98304 : 160000;

/** Pixel cap for the Nomand image shaders (halftone, flutes, lens ...). Normal quality = Folia's own cap. */
export const nomandMaxPixels = (): number => {
    const folia = 1920 * 1080;
    if (HALCYON_PROFILE !== 'battery') return folia;
    const css = Math.round((window.innerWidth || 360) * (window.innerHeight || 640));
    return Math.min(folia, Math.max(150000, css));
};

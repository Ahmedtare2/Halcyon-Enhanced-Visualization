import { useVisualizerSettingsStore } from '../stores/useVisualizerSettingsStore';
import { getHostState, subscribeHost } from './hostApi';
import { HALCYON_PROFILE } from './budget';

// src/halcyon/profile.ts
// Applies the page's profile (see budget.ts) to Folia's own settings and reports the result to Android.

const SCALE_MARK = 'halcyon_battery_prev_scale';

/**
 * Battery profile = Folia's own global "render scale" (Performance settings) at 0.75, on top of the
 * lower page render scale and frame rate the Android side already picks. The player's own choice
 * is remembered and put back when the page is opened in the normal profile again.
 */
export const applyHalcyonProfile = () => {
    try {
        const store = useVisualizerSettingsStore.getState();
        const current = store.lyricRenderQuality.scale;
        const marked = localStorage.getItem(SCALE_MARK);
        if (HALCYON_PROFILE === 'battery') {
            if (marked === null) localStorage.setItem(SCALE_MARK, String(current));
            if (current !== 0.75) store.handleSetLyricRenderQuality({ scale: 0.75 });
        } else if (marked !== null) {
            const previous = Number(marked);
            localStorage.removeItem(SCALE_MARK);
            if (previous === 0.5 || previous === 0.75 || previous === 1 || previous === 1.5 || previous === 2) {
                store.handleSetLyricRenderQuality({ scale: previous });
            } else {
                store.handleSetLyricRenderQuality({ scale: 1 });
            }
        }
    } catch (error) {
        console.warn('[HalcyonHost] profile not applied', error);
    }
};

type AndroidInfo = { onInfo?: (message: string) => void };

const describeCanvases = (): string => {
    const sizes: string[] = [];
    document.querySelectorAll('canvas').forEach(canvas => {
        const rect = canvas.getBoundingClientRect();
        if (rect.width < 8 || rect.height < 8) return;
        sizes.push(`${canvas.width}x${canvas.height}px (shown ${Math.round(rect.width)}x${Math.round(rect.height)})`);
    });
    return sizes.length ? sizes.join(', ') : 'none';
};

/** Writes the active budget and every canvas size into Folia diagnostics (Tune), a few seconds after a style or background change. */
export const startBudgetReport = () => {
    const android = (window as unknown as { AndroidHost?: AndroidInfo }).AndroidHost;
    if (!android || !android.onInfo) return;
    let timer = 0;
    let lastKey = '';
    const report = () => {
        const state = getHostState();
        const scale = useVisualizerSettingsStore.getState().lyricRenderQuality.scale;
        try {
            android.onInfo?.(
                `budget profile=${HALCYON_PROFILE} dpr=${window.devicePixelRatio} renderScale=${scale} ` +
                `mode=${state.mode} bg=${state.background ?? 'default'} canvases: ${describeCanvases()}`,
            );
        } catch { /* the bridge is optional */ }
    };
    const schedule = () => {
        const state = getHostState();
        const key = `${state.mode}|${state.background ?? ''}`;
        if (key === lastKey) return;
        lastKey = key;
        window.clearTimeout(timer);
        timer = window.setTimeout(report, 3500);
    };
    subscribeHost(schedule);
    schedule();
};
